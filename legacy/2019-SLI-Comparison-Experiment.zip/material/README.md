# Outline of material

- SchemEX-extended-with-FLuID contains the source code
  + Generate property statistics: `-stat /path/to/dataset/ /path/to/PropertyStats.csv`
  + Generate type statistics: `-stat2 /path/to/dataset/ /path/to/Typestats.csv`
  + Build the schema graph: `-d /path/to/dataset/ -o /location/to/store/it/ -bsg /path/to/PropertyStats.csv /path/to/Typestats.csv`
  + Start schema computation: `-d /path/to/dataset/ -o /path/to/index/`
  + For detailed run configurations of schema computation, please consult the help menu `-h`
  + load the generated index into a RDF database, e.g., sesame
  + Start the evaluation: `-eval goldstandard-repository approximative-repository`

- The detailed dataset statistics generated with `-stat3 /path/to/dataset/ /path/to/Dataset.csv`
