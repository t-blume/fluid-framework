package de.uni_kiel.schemex.implementation.required;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.required.IQuintSourceListener;

/**
 * Logs the Quads which generate errors in at least one version 1.2.3 of the
 * nxparser
 * 
 * @author Bastian
 *
 */
public class InvalidLogger implements IQuintSourceListener {

	private PrintWriter out;

	private long errors;
	private long n;

	/**
	 * Creates an InvalidLogger writing its results in the specified file
	 * 
	 * @param file
	 *            The output file
	 * @throws IOException
	 */
	public InvalidLogger(String file) throws IOException {

		Path p = Paths.get(file);

		out = new PrintWriter(
				Files.newBufferedWriter(p, StandardCharsets.UTF_8));

		n = 0;
		errors = 0;
	}

	@Override
	public void pushedQuint(IQuint quint) {

		boolean subjectValid = true;
		boolean predicateValid = true;
		boolean objectValid = true;
		boolean contextValid = true;

		String s, p, o, c;
		try {
			s = quint.getSubject().toString();
		} catch (Exception e) {
			subjectValid = false;
			s = "";
		}

		try {
			p = quint.getPredicate().toString();
		} catch (Exception e) {
			predicateValid = false;
			p = "";
		}

		try {
			o = quint.getObject().toString();
		} catch (Exception e) {
			objectValid = false;
			o = "";
		}

		try {
			c = quint.getContext().toString();
		} catch (Exception e) {
			contextValid = false;
			c = "";
		}

		// Error
		if (!subjectValid || !predicateValid || !objectValid || !contextValid) {
			out.println("Error on quad number " + n);
			out.println("Subject: " + s);
			out.println("Predicate: " + p);
			out.println("Object: " + o);
			out.println("Context: " + c);
			out.println("--------------------------------------------------------");
			errors++;
		}

		n++;
	}

	@Override
	public void sourceClosed() {

		if (out != null) {
			out.close();
		}
		System.out.println("Number of quads: " + n);
		System.out.println("Number of errors: " + errors);
	}

	@Override
	public void sourceStarted() {

	}

}
