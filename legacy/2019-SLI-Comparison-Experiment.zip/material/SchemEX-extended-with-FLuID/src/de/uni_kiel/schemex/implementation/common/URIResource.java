package de.uni_kiel.schemex.implementation.common;

import java.net.URI;

import de.uni_kiel.schemex.common.IResource;

/**
 * A Resource specified by a {@link URI}
 * 
 * @author Bastian
 *
 */
public class URIResource implements IResource {

	private URI uri;

	/**
	 * Constructor
	 * 
	 * @param uri
	 *            The resource's URI
	 */
	public URIResource(URI uri) {
		this.uri = uri;
	}

	/**
	 * Getter for the internal {@link URI} object
	 * 
	 * @return The uri
	 */
	URI getURI() {
		return uri;
	}

	@Override
	public boolean equals(Object obj) {

		if (!(obj instanceof URIResource)) {
			return false;
		}

		URIResource other = (URIResource) obj;

		return uri.equals(other.uri);
	}

	@Override
	public int hashCode() {
		return uri.hashCode();
	}

	@Override
	public String toString() {
		return uri.toString();
	}

	@Override
	public String toN3() {
		return "\"" + uri.toString() + "\"";
	}
}
