package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ISchemaElement;
import de.uni_kiel.schemex.utils.Hash;
import org.semanticweb.yars.nx.Resource;
import org.semanticweb.yars.nx.namespace.XSD;

import java.util.*;

/**
 * A typecluster. Typeclusters are sets of types. Instances are sorted into
 * these clusters based on their types
 *
 * @author Bastian
 */
public class TypeCluster implements ISchemaElement {

    Set<IPayloadElement> payloadElements = new HashSet<>();
    /**
     * TypeCluster for unresolved literals:
     * For real unresolved TC see @TypeClusterResourceUnresolved
     */
    public static TypeCluster TC_UNRESOLVED_LITERAL;

    public static TypeCluster TC_EMPTY;

    // Numerical Types
    /**
     * Typecluster for integers
     */
    public static TypeCluster TC_INTEGER;
    /**
     * Typecluster for decimals
     */
    public static TypeCluster TC_DECIMAL;
    /**
     * Typecluster for floats
     */
    public static TypeCluster TC_FLOAT;
    /**
     * Typecluster for double floating points
     */
    public static TypeCluster TC_DOUBLE;

    /**
     * Typecluster for bytes
     */
    public static TypeCluster TC_BYTE;

    /**
     * Typecluster for long integers
     */
    public static TypeCluster TC_LONG;

    /**
     * Typecluster for short integers
     */
    public static TypeCluster TC_SHORT;

    /**
     * Typecluster for booleans
     */
    public static TypeCluster TC_BOOLEAN;

    /**
     * Typecluster for unsigned bytes
     */
    public static TypeCluster TC_UNSIGNEDBYTE;
    /**
     * Typecluster for unsigned integers
     */
    public static TypeCluster TC_UNSIGNEDINT;
    /**
     * Typecluster for unsigned short integers
     */
    public static TypeCluster TC_UNSIGNEDSHORT;
    /**
     * Typecluster for unsigned long integers
     */
    public static TypeCluster TC_UNSIGNEDLONG;

    /**
     * Typecluster for positive integers
     */
    public static TypeCluster TC_POSITIVEINTEGER;
    /**
     * Typecluster for negative integers
     */
    public static TypeCluster TC_NEGATIVEINTEGER;

    /**
     * Typecluster for non-positive integers
     */
    public static TypeCluster TC_NONPOSITIVEINTEGER;

    /**
     * Typecluster for non-negative integers
     */
    public static TypeCluster TC_NONNEGATIVEINTEGER;

    // Other

    /**
     * Typecluster for strings
     */
    public static TypeCluster TC_STRING;
    /**
     * Typecluster for datetimes
     */
    public static TypeCluster TC_DATETIME;

    /**
     * Typecluster for dates
     */
    public static TypeCluster TC_DATE;

    /**
     * Typecluster for times
     */
    public static TypeCluster TC_TIME;

    // Mapping

    /**
     * Mapping from {@link Resource}s describing supported XSD datatypes to
     * matching typeclusters
     */
    public static Map<Resource, TypeCluster> DATATYPE_MAP;

    static {

        TC_UNRESOLVED_LITERAL = new TypeCluster(new TreeSet<>());
        TC_UNRESOLVED_LITERAL.resource = TypeClusterResource.TC_NOT_RESOLVED_LITERAL;

        TC_EMPTY = createEmptyTypeCluster();

        // Numerical Types
        Set<String> s = new TreeSet<>();
        s.add(XSD.INTEGER.toString());
        TC_INTEGER = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.DECIMAL.toString());
        TC_DECIMAL = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.FLOAT.toString());
        TC_FLOAT = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.DOUBLE.toString());
        TC_DOUBLE = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.BYTE.toString());
        TC_BYTE = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.LONG.toString());
        TC_LONG = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.SHORT.toString());
        TC_SHORT = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.BOOLEAN.toString());
        TC_BOOLEAN = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.UNSIGNEDBYTE.toString());
        TC_UNSIGNEDBYTE = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.UNSIGNEDINT.toString());
        TC_UNSIGNEDINT = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.UNSIGNEDSHORT.toString());
        TC_UNSIGNEDSHORT = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.UNSIGNEDLONG.toString());
        TC_UNSIGNEDLONG = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.POSITIVEINTEGER.toString());
        TC_POSITIVEINTEGER = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.NEGATIVEINTEGER.toString());
        TC_NEGATIVEINTEGER = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.NONPOSITIVEINTEGER.toString());
        TC_NONPOSITIVEINTEGER = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.NONNEGATIVEINTEGER.toString());
        TC_NONNEGATIVEINTEGER = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.STRING.toString());
        TC_STRING = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.DATETIME.toString());
        TC_DATETIME = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.DATE.toString());
        TC_DATE = new TypeCluster(s);

        s = new TreeSet<>();
        s.add(XSD.TIME.toString());
        TC_TIME = new TypeCluster(s);

        // Set up map
        DATATYPE_MAP = new HashMap<>();

        DATATYPE_MAP.put(XSD.INTEGER, TC_INTEGER);
        DATATYPE_MAP.put(XSD.DECIMAL, TC_DECIMAL);
        DATATYPE_MAP.put(XSD.FLOAT, TC_FLOAT);
        DATATYPE_MAP.put(XSD.DOUBLE, TC_DOUBLE);
        DATATYPE_MAP.put(XSD.BYTE, TC_BYTE);
        DATATYPE_MAP.put(XSD.LONG, TC_LONG);
        DATATYPE_MAP.put(XSD.SHORT, TC_SHORT);
        DATATYPE_MAP.put(XSD.BOOLEAN, TC_BOOLEAN);
        DATATYPE_MAP.put(XSD.UNSIGNEDBYTE, TC_UNSIGNEDBYTE);
        DATATYPE_MAP.put(XSD.UNSIGNEDINT, TC_UNSIGNEDINT);
        DATATYPE_MAP.put(XSD.UNSIGNEDSHORT, TC_UNSIGNEDSHORT);
        DATATYPE_MAP.put(XSD.UNSIGNEDLONG, TC_UNSIGNEDLONG);
        DATATYPE_MAP.put(XSD.POSITIVEINTEGER, TC_POSITIVEINTEGER);
        DATATYPE_MAP.put(XSD.NEGATIVEINTEGER, TC_NEGATIVEINTEGER);
        DATATYPE_MAP.put(XSD.NONPOSITIVEINTEGER, TC_NONPOSITIVEINTEGER);
        DATATYPE_MAP.put(XSD.NONNEGATIVEINTEGER, TC_NONNEGATIVEINTEGER);

        DATATYPE_MAP.put(XSD.STRING, TC_STRING);
        DATATYPE_MAP.put(XSD.DATETIME, TC_DATETIME);
        DATATYPE_MAP.put(XSD.DATE, TC_DATE);
        DATATYPE_MAP.put(XSD.TIME, TC_TIME);

    }

    /**
     * Create an TC whose identifier is a hashed URI to enable later updates when instance information is known
     *
     * @param URI
     * @return
     */
    public static TypeCluster createTentativeObjectCluster(IResource URI) {
        return new TypeCluster(URI);
    }

    /**
     * Create an TC whose identifier is a hashed URI to enable later updates when instance information is known
     *
     * @return
     */
    public static TypeCluster createEmptyTypeCluster() {
        return new TypeCluster(new HashSet<>());
    }

    /**
     * Set of types that make the type cluster.
     */
    protected Set<String> types;
    /**
     * Equivalence classes that belong to this type cluster.
     */
    protected Map<Integer, EquivalenceClass> eqcs;

    public Set<IResource> getEQC_Locators() {
        return EQC_Locators;
    }

    public void addEQC_Locators(IResource EQC_Locator) {
        this.EQC_Locators.add(EQC_Locator);
    }

    /**
     * Equivalence classes that belong to this type cluster.
     */
    protected Set<IResource> EQC_Locators;

    /**
     * instance count for this type cluster
     */
    protected int instance_count;

    protected TypeClusterResource resource;

    /**
     * Creates a type cluster with an URI and a set of types
     *
     * @param _types set of types that belong to this type cluster
     */

    public TypeCluster(Set<String> _types) {
        types = _types;
        eqcs = new HashMap<>();
        EQC_Locators = new HashSet<>();
        instance_count = 1;
        resource = new TypeClusterResource(_types);
    }

    private TypeCluster(IResource URI) {
        types = null;
        eqcs = new HashMap<>();
        instance_count = 1;
        resource = new TypeClusterResourceUnresolved(URI);
    }

    /**
     * Adds a equivalence class to the type cluster
     *
     * @param _eq_class Equivalence class that should be added to type cluster
     * @return the previous value associated with key, or null if there was no
     * mapping for key. (A null return can also indicate that the map
     * previously associated null with key.)
     */
    public EquivalenceClass addEqClass(EquivalenceClass _eq_class) {
        return eqcs.put(_eq_class.hashCode(), _eq_class);
    }

    /**
     * Checks, if a proper equivalence class is already contained by the schema
     *
     * @param _eq_class_hash The URI of the EQ class
     * @return <code>true</code>, if the EQ class is already in the schema
     */
    public boolean containsEqClass(int _eq_class_hash) {
        return eqcs.containsKey(_eq_class_hash);
    }

    /**
     * removes a equivalence class from a type cluster
     *
     * @param _eq_class equivalence class to be removed
     * @return the previous value associated with key, or null if there was no
     * mapping for key. (A null return can also indicate that the map
     * previously associated null with key.)
     */
    public EquivalenceClass flushEqClass(EquivalenceClass _eq_class) {
        return eqcs.remove(_eq_class.hashCode());
    }

    /**
     * Returns the equivalence class by the given URI
     *
     * @param _eq_class_hash The URI of the EQ class
     * @return the equivalence class of the given URI
     */
    public EquivalenceClass getEqClass(int _eq_class_hash) {
        return eqcs.get(_eq_class_hash);
    }

    /**
     * Returns the number of eq classes in this type cluster
     *
     * @return number of eq classes
     */
    public int getEqClassCount() {
        return eqcs.size();
    }

    /**
     * Creates a MD5 hash value based on the footprint / signature of the types
     * that are attached to an type-cluster.
     *
     * @return MD5 hash value
     */
    protected String getTypeClusterHash() {
        return Hash.md5(Integer.toString(types.hashCode()));
    }

    /**
     * Increments the instance count by 1
     *
     * @return instance count
     */
    public int incInstanceCount() {
        return instance_count++;
    }

    /**
     * Returns the number of instances assigned to this type cluster
     *
     * @return instance count
     */
    public int getInstanceCount() {
        return instance_count;
    }

    /**
     * Returns the type / class count for this type cluster
     *
     * @return type /class count
     */
    public int getTypeCount() {
        return types.size();
    }

    // getter and setter

    public Set<String> getTypes() {
        return types;
    }

    public Map<Integer, EquivalenceClass> getEqClasses() {
        return eqcs;
    }

    @Override
    public String toString() {
        return resource.toString();
    }

    @Override
    public IResource getLocator() {
        return resource;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof TypeCluster))
            return false;
        TypeCluster r = (TypeCluster) obj;

        if (resource.equals(r.resource))
            return types.equals(r.types);
        else
            return false;

    }

    @Override
    public int hashCode() {
        return resource.hashCode();
    }


    @Override
    public void addPayload(IPayloadElement payloadElement) {
        payloadElements.add(payloadElement);
    }

    @Override
    public Set<IPayloadElement> getPayloadElements() {
        return payloadElements;
    }

    @Override
    public ISchemaElement clone() {
        TypeCluster typeCluster = new TypeCluster(types);
        for (EquivalenceClass eqc : this.getEqClasses().values())
            typeCluster.addEqClass(eqc);

        return typeCluster;
    }
}
