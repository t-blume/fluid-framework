package de.uni_kiel.schemex.interfaces.required;

import de.uni_kiel.schemex.interfaces.provided.IElementCache;

/**
 * Listens for instance which are flushed out of a {@link IElementCache}. The
 * method is called for each instance leaving the cache.
 * 
 * @author Bastian
 * 
 */
public interface IElementCacheListener<T> {

	/**
	 * Callback function for instances leaving the cache
	 * 
	 * @param instance
	 *            The instance
	 */
	void elementFlushed(T instance);

	/**
	 * Signals that no more instances will follow
	 */
	void finished();
}
