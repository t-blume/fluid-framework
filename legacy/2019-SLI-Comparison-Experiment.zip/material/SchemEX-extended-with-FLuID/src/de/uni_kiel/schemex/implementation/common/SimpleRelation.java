package de.uni_kiel.schemex.implementation.common;

import de.uni_kiel.schemex.common.IRelation;
import de.uni_kiel.schemex.common.IResource;

/**
 * A simple relation from one {@link IResource} to another
 * 
 * @author Bastian
 *
 */
public class SimpleRelation implements IRelation {

	private IResource source;
	private IResource target;


	/**
	 * Constructor
	 * 
	 * @param source
	 *            The source
	 * @param target
	 *            The target
	 */
	public SimpleRelation(IResource source, IResource target) {
		this.source = source;
		this.target = target;
	}

	@Override
	public IResource getSource() {
		return source;
	}

	@Override
	public void setSource(IResource resource) {
		this.source = resource;
	}

	@Override
	public IResource getTarget() {
		return target;
	}

	@Override
	public int hashCode() {
		return source.hashCode() + 17 * target.hashCode();
	}

	@Override
	public boolean equals(Object obj) {

		if (!(obj instanceof SimpleRelation)) {
			return false;
		}
		SimpleRelation r = (SimpleRelation) obj;
		return source.equals(r.source) && target.equals(r.target);
	}
}
