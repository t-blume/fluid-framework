/**
 * This package contains implementations for required interfaces used in schemex, such as writers or schema generators
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.implementation.schemex.required;