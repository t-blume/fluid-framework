package de.uni_kiel.schemex.implementation.schemex.required.computation;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.implementation.common.NamedRelation;
import de.uni_kiel.schemex.implementation.schemex.common.PseudoBlankNode;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;
import de.uni_kiel.schemex.interfaces.required.IExtractor;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Created by Blume Till on 20.09.2016.
 */
public class DatasourcePayloadGenerator implements IPayloadGenerator {
    //mandatory
    IExtractor contextExtractor;


    public DatasourcePayloadGenerator(IExtractor contextExtractor) {
        this.contextExtractor = contextExtractor;
    }


    public Set<IPayloadElement> createPayload(IResource schemaElementLocator, IInstanceElement instance, IRelationsCache payloadCache) {
        Set<IPayloadElement> elements = new HashSet<>();
        //context is mandatory
        Map<IResource, IPayloadElement> contexts = contextExtractor.extract(instance);
        if (contexts != null) {
            elements.addAll(contexts.values());
            contexts.forEach((CLoc, C) -> {
                PseudoBlankNode payloadSchemaElement = new PseudoBlankNode(schemaElementLocator, CLoc);
                if (!payloadCache.contains(payloadSchemaElement.getLocator()))
                    elements.add(payloadSchemaElement);

                payloadCache.add(new NamedRelation(schemaElementLocator, payloadSchemaElement.getLocator(), "pseudo"));
                payloadCache.add(new NamedRelation(payloadSchemaElement.getLocator(), CLoc, "context"));
            });
        }
        return elements;
    }
}
