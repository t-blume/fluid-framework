package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.ILocatable;
import de.uni_kiel.schemex.common.IResource;

import java.util.HashMap;

/**
 * Reduced instance data to be used in a backward-cache. It only contains
 * resource and typecluster information, but nothing about the specific types
 *
 * Also includes reference from Instance to the corresponding Schema Element
 * @author Bastian
 * @editor Till
 *
 */
public class BackwardInstance implements ILocatable {

	//Instance Identifier
	private IResource resource;
	//TypeCluster Identifier
	private IResource tc;
	//EquivalenceClass Identifier
	private HashMap<Integer,IResource> eqcs;


	/**
	 * Constructor
	 *
	 * @param resource
	 *            The resource
	 * @param tc
	 *            The resource's TypeCluster
	 */
	public BackwardInstance(IResource resource, IResource tc) {
		this.resource = resource;
		this.tc = tc;
		this.eqcs = new HashMap<>();
	}

	/**
	 * Getter for the TypeCluster
	 * 
	 * @return The TypeCluster
	 */
	public IResource getTypeClusterResource() {
		return tc;
	}

	/**
	 * Getter for the EquivalenceClass
	 *
	 * @return The EquivalenceClass
	 */
	public HashMap<Integer,IResource> getTentativeEquivalanceClassResources(){
		return eqcs;
	}

	public void addTentativeEquivalenceClassResource(int bisimulationDepth, IResource tentativeEquivalanceClassResource){
		eqcs.put(bisimulationDepth, tentativeEquivalanceClassResource);
	}

	@Override
	public IResource getLocator() {
		return resource;
	}

}
