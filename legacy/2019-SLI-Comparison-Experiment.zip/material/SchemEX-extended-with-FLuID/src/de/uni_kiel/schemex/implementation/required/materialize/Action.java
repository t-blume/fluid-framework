package de.uni_kiel.schemex.implementation.required.materialize;

public interface Action {
	public void execute() throws Exception;
}
