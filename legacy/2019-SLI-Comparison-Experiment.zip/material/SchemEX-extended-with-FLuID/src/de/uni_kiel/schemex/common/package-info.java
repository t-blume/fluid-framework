/**
 * 
 * Common model interfaces to be used by the framework
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.common;