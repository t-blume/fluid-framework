package de.uni_kiel.schemex.implementation.schemex.required;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.interfaces.required.IElementCacheListener;
import de.uni_kiel.schemex.utils.Constants;
import org.semanticweb.yars.nx.Resource;

import de.uni_kiel.schemex.implementation.schemex.common.TypeCluster;
import de.uni_kiel.schemex.implementation.schemex.required.writer.utils.WriterVocabulary;

/**
 * Schema validator for the 2012 simple schema of schemex. It will try to find
 * matching type clusters and equivalence classes and check, whether any
 * differences besides literal typeclusters
 * 
 * @author Bastian
 *
 */
public class SchemexValidator implements
		IElementCacheListener<IInstanceElement> {

	Map<String, TypeClusterInformation> tc1, tc2, currentTc;
	Map<String, EqcInformation> eqc1, eqc2, currentEqc;
	Map<String, String> tcCorrespondences;
	Map<String, String> eqcCorrespondences;
	Map<String, String> dsCorrespondences;
	Map<String, DatasourceInformation> ds1, ds2, currentDs;
	Map<String, Set<String>> snippets1, snippets2, currentSnippets;

	private class TypeClusterInformation {
		public int count;
		public Map<String, EqcInformation> eqcs;
		public Set<String> types;

		public TypeClusterInformation() {
			count = 0;
			eqcs = new HashMap<String, EqcInformation>();
			types = new HashSet<String>();
			tcCorrespondences = new HashMap<String, String>();
			eqcCorrespondences = new HashMap<String, String>();
			dsCorrespondences = new HashMap<String, String>();
		}

		@Override
		public boolean equals(Object obj) {

			if (!(obj instanceof TypeClusterInformation)) {
				return false;
			}

			TypeClusterInformation o = (TypeClusterInformation) obj;
			return count == o.count && types.equals(o.types)
					&& eqcs.equals(o.eqcs);
		}

		@Override
		public int hashCode() {
			return 17 + 31 * count + 31 * 31 * types.hashCode() + 31 * 31 * 31
					* eqcs.hashCode();
		}
	}

	private class EqcInformation {
		public int count;

		public Map<String, Set<String>> connections;

		public String typeCluster;

		public Set<String> linksets;

		public EqcInformation() {
			count = 0;
			connections = new HashMap<String, Set<String>>();
			typeCluster = "";
			linksets = new HashSet<String>();
		}
	}

	private class DatasourceInformation {

		public int count;

		public Set<String> exampleResources;

		public Set<String> contexts;
		public String eqc;

		public DatasourceInformation() {
			exampleResources = new HashSet<String>();
			contexts = new HashSet<String>();
			count = 0;
			eqc = "";
		}
	}

	boolean finished1;

	WriterVocabulary wv;

	public SchemexValidator(IElementCache<IInstanceElement> schemaSource1,
							IElementCache<IInstanceElement> schemaSource2, WriterVocabulary wv) {

		this.wv = wv;
		finished1 = false;
		tc1 = new HashMap<String, TypeClusterInformation>();
		tc2 = new HashMap<String, TypeClusterInformation>();
		eqc1 = new HashMap<String, EqcInformation>();
		eqc2 = new HashMap<String, EqcInformation>();
		ds1 = new HashMap<String, DatasourceInformation>();
		ds2 = new HashMap<String, DatasourceInformation>();
		snippets1 = new HashMap<String, Set<String>>();
		snippets2 = new HashMap<String, Set<String>>();

		currentSnippets = snippets1;
		currentTc = tc1;
		currentEqc = eqc1;
		currentDs = ds1;
		schemaSource1.registerCacheListener(this);
		schemaSource2.registerCacheListener(this);

	}

	private void matchEqcs() {
		Set<String> datatypes = new HashSet<String>();

		for (Resource r : TypeCluster.DATATYPE_MAP.keySet()) {
			datatypes.add(r.toString());
		}
		Set<String> eqc2Keys = new HashSet<String>();
		Set<String> eqc1Keys = new HashSet<String>();

		for (Entry<String, EqcInformation> e1 : eqc1.entrySet()) {

			EqcInformation e1i = e1.getValue();
			for (Entry<String, EqcInformation> e2 : eqc2.entrySet()) {

				EqcInformation e2i = e2.getValue();
				if (e1i.count != e2i.count) {
					continue;
				}

				if (!e1i.connections.keySet().equals(e2i.connections.keySet())) {
					continue;
				}

				boolean correct = true;
				if (!tcCorrespondences.containsKey(e1i.typeCluster)) {
					continue;
				}
				if (!tcCorrespondences.get(e1i.typeCluster).equals(
						e2i.typeCluster)) {
					continue;

				}

				Map<String, Set<String>> ec2m = e2i.connections;
				for (Entry<String, Set<String>> ec1 : e1i.connections
						.entrySet()) {
					Set<String> p2 = ec2m.get(ec1.getKey());

					// Check if property is there
					if (p2 == null) {
						correct = false;
						break;
					}

					Set<String> typeClusters1 = ec1.getValue();

					Set<String> typeClusters1To2 = new HashSet<String>();
					for (String s : typeClusters1) {

						String tc2 = tcCorrespondences.get(s);
						if (tc2 != null) {
							typeClusters1To2.add(tc2);
						}
					}

					Set<String> typeClusters2 = p2;
					correct = correct
							&& (typeClusters1To2.containsAll(typeClusters2));
					correct = correct
							&& (typeClusters2.containsAll(typeClusters1To2));
					// // Check if the sets are equal
					// for (String s : ec1.getValue()) {
					// String cors = tcCorrespondences.get(s);
					// if (cors == null) {
					// correct = false;
					// break;
					// }
					//
					// if (!p2.contains(cors)) {
					// correct = false;
					// break;
					// }
					// }
					//
					// // Check other direction
					// for (String s : p2) {
					//
					// boolean found = false;
					// for (String s2 : ec1.getValue()) {
					// String cors = tcCorrespondences.get(s2);
					// if (cors == null) {
					// continue;
					// }
					// if (cors.equals(s2)) {
					// found = true;
					// break;
					// }
					// }
					//
					// }
					if (!correct) {
						break;
					}

				}

				if (correct) {
					eqcCorrespondences.put(e1.getKey(), e2.getKey());
					eqc1Keys.add(e1.getKey());
					eqc2Keys.add(e2.getKey());
				}

			}
		}

		Set<String> eqc1Leftovers = new HashSet<String>(eqc1.keySet());
		eqc1Leftovers.removeAll(eqc1Keys);
		Set<String> eqc2Leftovers = new HashSet<String>(eqc2.keySet());
		eqc2Leftovers.removeAll(eqc2Keys);

		System.out.println();
		System.out.println("-----------------------------------------");
		System.out.println("Equivalence classes matching results: ");
		System.out.println("Matched equivalence classes : "
				+ eqcCorrespondences.size());
		// System.out.println("Equivalence classes only found in first schema: ");
		// for (String s : eqc1Leftovers) {
		// printEqc(s, eqc1, tc1, 0);
		// }
		// System.out
		// .println("\nEquivalence classes only found in second schema: ");
		// for (String s : eqc2Leftovers) {
		// printEqc(s, eqc2, tc2, 0);
		// }

		Iterator<String> it = eqc1Leftovers.iterator();
		while (it.hasNext()) {
			String s = it.next();
			EqcInformation ei = eqc1.get(s);

			TypeClusterInformation ti = tc1.get(ei.typeCluster);

			// Pure datatype eqcs
			if (datatypes.containsAll(ti.types)) {
				it.remove();
				continue;
			}
		}

		it = eqc2Leftovers.iterator();
		while (it.hasNext()) {
			String s = it.next();
			EqcInformation ei = eqc2.get(s);

			TypeClusterInformation ti = tc2.get(ei.typeCluster);

			// Pure datatype eqcs
			if (datatypes.containsAll(ti.types)) {
				it.remove();
				continue;
			}
		}

		System.out
				.println("Equivalence classes matching results without pure datatype eqcs: ");
		System.out.println("Equivalence classes only found in first schema: ");
		for (String s : eqc1Leftovers) {
			printEqc(s, eqc1, tc1, 0);
		}
		System.out
				.println("\nEquivalence classes only found in second schema: ");
		for (String s : eqc2Leftovers) {
			printEqc(s, eqc2, tc2, 0);
		}
		System.out.println();
		System.out.println("-----------------------------------------");
		System.out.println();

	}

	private void matchTypeclusters() {

		Set<String> tc2Keys = new HashSet<String>();
		Set<String> tc1Keys = new HashSet<String>();

		Set<String> datatypes = new HashSet<String>();

		for (Resource r : TypeCluster.DATATYPE_MAP.keySet()) {
			datatypes.add(r.toString());
		}
		for (Entry<String, TypeClusterInformation> e : tc1.entrySet()) {

			String id = null;
			for (Entry<String, TypeClusterInformation> e2 : tc2.entrySet()) {
				if (e.getValue().types.equals(e2.getValue().types)) {
					id = e.getKey();
					break;
				}
			}

			if (id != null) {
				tc1Keys.add(e.getKey());
				tc2Keys.add(id);
				tcCorrespondences.put(e.getKey(), id);
			}
		}

		Set<String> tc1Leftovers = new HashSet<String>(tc1.keySet());
		tc1Leftovers.removeAll(tc1Keys);
		Set<String> tc2Leftovers = new HashSet<String>(tc2.keySet());
		tc2Leftovers.removeAll(tc2Keys);

		System.out.println();
		System.out.println("-----------------------------------------");

		// Remove pure datatypes
		System.out.println("Type cluster matching results: ");
		System.out.println("Matched typeclusters: " + tcCorrespondences.size());
		// System.out.println("Type clusters only found in first schema: ");
		// for (String s : tc1Leftovers) {
		// printTc(s, tc1, 0);
		// }
		// System.out.println("\nType clusters only found in second schema: ");
		// for (String s : tc2Leftovers) {
		// printTc(s, tc2, 0);
		// }

		Iterator<String> it = tc1Leftovers.iterator();
		while (it.hasNext()) {
			String s = it.next();

			Set<String> types = new HashSet<String>(tc1.get(s).types);
			types.removeAll(datatypes);
			if (types.size() == 0) {
				it.remove();
			}
		}

		it = tc2Leftovers.iterator();
		while (it.hasNext()) {
			String s = it.next();
			Set<String> types = new HashSet<String>(tc2.get(s).types);
			types.removeAll(datatypes);
			if (types.size() == 0) {
				it.remove();
			}
		}

		System.out.println();
		System.out.println("Type clusters disregarding datatype clusters:");
		System.out.println("Type clusters only found in first schema: ");
		for (String s : tc1Leftovers) {
			printTc(s, tc1, 0);
		}
		System.out.println("\nType clusters only found in second schema: ");
		for (String s : tc2Leftovers) {
			printTc(s, tc2, 0);
		}
		System.out.println();
		System.out.println("-----------------------------------------");
		System.out.println();

	}

	private void processTC(IInstanceElement i,
			Map<String, TypeClusterInformation> tcm,
			Map<String, EqcInformation> eqm,
			Map<String, DatasourceInformation> dsm) {
		String id = i.getLocator().toString();

		TypeClusterInformation tci = new TypeClusterInformation();

		for (IQuint q : i.getOutgoingQuints()) {
			if (q.getPredicate().toString()
					.contains(wv.getEntry(WriterVocabulary.COUNT_PROPERTY))) {
				int c = Integer.parseInt(q.getObject().toString());
				tci.count = c;
			} else if (q
					.getPredicate()
					.toString()
					.contains(wv.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE))) {
				tci.types.add(q.getObject().toString());
			} else if (q.getPredicate().toString()
					.contains(wv.getEntry(WriterVocabulary.TYPECLUSTER_TO_EQC))) {

				EqcInformation ei = new EqcInformation();
				if (eqm.containsKey(q.getObject().toString())) {
					ei = eqm.get(q.getObject().toString());
				} else {

					eqm.put(q.getObject().toString(), ei);
				}
				tci.eqcs.put(q.getObject().toString(), ei);
				ei.typeCluster = q.getSubject().toString();
			}
		}

		tcm.put(id, tci);
	}

	private void processEqc(IInstanceElement i,
			Map<String, TypeClusterInformation> tcm,
			Map<String, EqcInformation> eqm,
			Map<String, DatasourceInformation> dsm) {
		String id = i.getLocator().toString();

		EqcInformation eci = new EqcInformation();
		if (eqm.containsKey(id)) {
			eci = eqm.get(id);
		}

		for (IQuint q : i.getOutgoingQuints()) {

			String p = q.getPredicate().toString();
			if (p.contains(wv.getEntry(WriterVocabulary.COUNT_PROPERTY))) {
				int c = Integer.parseInt(q.getObject().toString());
				eci.count = c;
			} else if (p.contains(Constants.RDF_TYPE)) {

			} else if (p.contains(wv
					.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET))) {

				eci.linksets.add(q.getObject().toString());
				DatasourceInformation dsi = new DatasourceInformation();
				if (!dsm.containsKey(q.getObject().toString())) {
					dsm.put(q.getObject().toString(), dsi);

				} else {
					dsi = dsm.get(q.getObject().toString());
				}

				dsi.eqc = id;

			} else {
				if (eci.connections.containsKey(p)) {
					eci.connections.get(p).add(q.getObject().toString());
				} else {
					Set<String> c = new HashSet<String>();
					c.add(q.getObject().toString());

					eci.connections.put(p, c);

				}
			}

		}

	}

	private void processLinkset(IInstanceElement i,
			Map<String, TypeClusterInformation> tcm,
			Map<String, EqcInformation> eqm,
			Map<String, DatasourceInformation> dsm) {
		String id = i.getLocator().toString();

		DatasourceInformation dsi = new DatasourceInformation();
		if (dsm.containsKey(id)) {
			dsi = dsm.get(id);
		} else {
			dsm.put(id, dsi);
		}

		for (IQuint q : i.getOutgoingQuints()) {
			String p = q.getPredicate().toString();

			if (p.contains(wv.getEntry(WriterVocabulary.COUNT_PROPERTY))) {
				dsi.count = Integer.parseInt(q.getObject().toString());
			} else if (p.contains(wv
					.getEntry(WriterVocabulary.LINKSET_TO_CONTEXT))) {
				dsi.contexts.add(q.getObject().toString());
			} else if (p.contains(wv
					.getEntry(WriterVocabulary.EXAMPLE_RESOURCE_PROPERTY))) {
				dsi.exampleResources.add(q.getObject().toString());
			}
		}

	}

	void processPayload(IInstanceElement i) {

		String id = i.getLocator().toString();

		for (IQuint q : i.getOutgoingQuints()) {
			if (q.getPredicate().toString()
					.contains(wv.getEntry(WriterVocabulary.TO_SNIPPET))) {

				Set<String> sn = null;
				if (currentSnippets.containsKey(id)) {
					sn = currentSnippets.get(id);
				}

				else {
					sn = new HashSet<String>();
					currentSnippets.put(id, sn);
				}

				sn.add(q.getObject().toString());
			}
		}

	}

	@Override
	public void elementFlushed(IInstanceElement instance) {

		String id = instance.getLocator().toString();
		if (id.startsWith(wv.getEntry(WriterVocabulary.TYPECLUSTER_PREFIX))) {
			processTC(instance, currentTc, currentEqc, currentDs);
		} else if (id.startsWith(wv
				.getEntry(WriterVocabulary.EQUIVALENCECLASS_PREFIX))) {
			processEqc(instance, currentTc, currentEqc, currentDs);

		} else if (id.startsWith(wv.getEntry(WriterVocabulary.LINKSET_PREFIX))) {
			processLinkset(instance, currentTc, currentEqc, currentDs);
		} else {
			processPayload(instance);
		}
		// TypeClusterInformation tci = new TypeClusterInformation();
		//
		// for (IQuint q : instance.getOutgoingQuints()) {
		// if (q.getPredicate().toString()
		// .contains(wv.getEntry(WriterVocabulary.COUNT_PROPERTY))) {
		// int c = Integer.parseInt(q.getObject().toString());
		// tci.count = c;
		// } else if (q
		// .getPredicate()
		// .toString()
		// .contains(wv.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE))) {
		// tci.types.add(q.getObject().toString());
		// } else if (q.getPredicate().toString()
		// .contains(wv.getEntry(WriterVocabulary.TYPECLUSTER_TO_EQC))) {
		//
		// EqcInformation ei = new EqcInformation();
		// if (eqc1.containsKey(q.getObject().toString())) {
		// ei = eqc1.get(q.getObject().toString());
		// }
		// eqc1.put(q.getObject().toString(), ei);
		// tci.eqcs.put(q.getObject().toString(), ei);
		// }
		// }
		//
		// tc1.put(id, tci);

	}

	@Override
	public void finished() {

		if (!finished1) {
			finished1 = true;
			currentEqc = eqc2;
			currentTc = tc2;
			currentDs = ds2;
			currentSnippets = snippets2;
		} else {
			matchTypeclusters();
			matchEqcs();
			matchDs();
		}
		// for (Entry<String, TypeClusterInformation> e : tc1.entrySet()) {
		// System.out.println("------------------\n");
		// System.out.println("Information for tc: " + e.getKey());
		// System.out.println("Count: " + e.getValue().count);
		// System.out.println();
		// System.out.println("Types:");
		// for (String t : e.getValue().types) {
		// System.out.println(t);
		// }
		// System.out.println();
		// System.out.println("Eqcs:");
		// for (Entry<String, EqcInformation> t : e.getValue().eqcs.entrySet())
		// {
		// System.out.println(t.getKey());
		// }
		// System.out.println("------------------\n");
		// }
		//
		// System.out.println("\n\nEquivalenceClasses");
		// for (Entry<String, EqcInformation> e : eqc1.entrySet()) {
		// System.out.println("------------------\n");
		// System.out.println("Information for eqc: " + e.getKey());
		// System.out.println("Count: " + e.getValue().count);
		// System.out.println();
		//
		// System.out.println("------------------\n");
		// }
		// System.out.println("tc1: " + tc1.size());
		// System.out.println("tc2: " + tc2.size());
		// System.out.println("eqc1: " + eqc1.size());
		// System.out.println("eqc2: " + eqc2.size());
	}

	void printEqc(String eqc, Map<String, EqcInformation> eqcs,
			Map<String, TypeClusterInformation> tcs, int tab) {

		String t = "";
		for (int i = 0; i < tab; i++) {
			t += "\t";
		}

		EqcInformation ei = eqcs.get(eqc);
		System.out.println(t + "Eqc: " + eqc);
		System.out.println(t + "Count: " + ei.count);
		for (Entry<String, Set<String>> e : ei.connections.entrySet()) {
			System.out.println(t + "Property: " + e.getKey());
			for (String s : e.getValue()) {
				printTc(s, tcs, tab + 1);
			}
		}
	}

	void printTc(String tc, Map<String, TypeClusterInformation> tcs, int tab) {

		String t = "";
		for (int i = 0; i < tab; i++) {
			t += "\t";
		}

		TypeClusterInformation ti = tcs.get(tc);
		if (ti == null) {
			return;
		}
		System.out.println(t + "Tc: " + tc);
		System.out.println(t + "Count: " + ti.count);
		System.out.println(t + "Types:");
		for (String s : ti.types) {
			System.out.println(t + "\t" + s);
		}
	}

	private void matchDs() {

		Set<String> ds2Keys = new HashSet<String>();
		Set<String> ds1Keys = new HashSet<String>();

		for (Entry<String, DatasourceInformation> e1 : ds1.entrySet()) {

			String id1 = e1.getKey();
			DatasourceInformation dsi1 = e1.getValue();

			for (Entry<String, DatasourceInformation> e2 : ds2.entrySet()) {

				String id2 = e2.getKey();
				DatasourceInformation dsi2 = e2.getValue();

				if (dsi1.count != dsi2.count) {
					continue;
				}
				if (!dsi1.contexts.equals(dsi2.contexts)) {
					continue;
				}
				if (!dsi1.exampleResources.equals(dsi2.exampleResources)) {
					continue;
				}

				if (!eqcCorrespondences.containsKey(dsi1.eqc)) {
					continue;
				}

				String eqcds1 = eqcCorrespondences.get(dsi1.eqc);
				if (!eqcds1.equals(dsi2.eqc)) {
					continue;
				}
				dsCorrespondences.put(id1, id2);
				ds1Keys.add(id1);
				ds2Keys.add(id2);
				break;
			}
		}

		Set<String> ds1left = new HashSet<String>(ds1.keySet());
		Set<String> ds2left = new HashSet<String>(ds2.keySet());

		ds1left.removeAll(ds1Keys);
		ds2left.removeAll(ds2Keys);
		System.out.println();
		System.out.println("-----------------------------------------");
		System.out.println("Matched linksets: " + dsCorrespondences.size());
		System.out.println("Linksets only found in first schema");
		for (String s : ds1left) {
			System.out.println(s);
			DatasourceInformation ds = ds1.get(s);
			System.out.println("\tCount: " + ds.count);
			printEqc(ds.eqc, eqc1, tc1, 1);
			System.out.println("\tExamples: ");

			for (String s2 : ds.exampleResources) {
				System.out.println("\t\t" + s2);
			}
			System.out.println("\tContexts");
			for (String s2 : ds.contexts) {
				System.out.println("\t\t" + s2);
			}
		}

		System.out.println("\nLinksets only found in second schema");
		for (String s : ds2left) {
			System.out.println(s);
			DatasourceInformation ds = ds2.get(s);
			System.out.println("\tCount: " + ds.count);
			printEqc(ds.eqc, eqc2, tc2, 1);
			System.out.println("\tExamples: ");

			for (String s2 : ds.exampleResources) {
				System.out.println("\t\t" + s2);
			}
			System.out.println("\tContexts");
			for (String s2 : ds.contexts) {
				System.out.println("\t\t" + s2);
			}
		}
		System.out.println();
		System.out.println("-----------------------------------------");
		System.out.println();
		// System.out.println("Correspondences:");
		// System.out.println(dsCorrespondences);
	}
}
