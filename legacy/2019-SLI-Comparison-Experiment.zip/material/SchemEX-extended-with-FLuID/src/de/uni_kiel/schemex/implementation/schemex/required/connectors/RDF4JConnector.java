package de.uni_kiel.schemex.implementation.schemex.required.connectors;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.required.IConnector;
import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.ValueFactory;
import org.eclipse.rdf4j.repository.Repository;
import org.eclipse.rdf4j.repository.RepositoryConnection;
import org.eclipse.rdf4j.repository.RepositoryException;
import org.eclipse.rdf4j.repository.http.HTTPRepository;
import org.eclipse.rdf4j.rio.ParserConfig;
import org.eclipse.rdf4j.rio.RDFFormat;
import org.eclipse.rdf4j.rio.RDFParser;
import org.eclipse.rdf4j.rio.Rio;
import org.eclipse.rdf4j.rio.helpers.NTriplesParserSettings;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by Blume Till on 25.08.2016.
 */
public class RDF4JConnector implements IConnector {

    private final String server_uri;
    private final String repository_id;
    private final Repository repository;
    private final ValueFactory valueFactory;
    private final RepositoryConnection connection;

    //stream writing
    private final int BUFF_SIZE = 10000;
    private final int MAX_STRING_LENGTH = 1000;
    private final StringBuffer sbf = new StringBuffer(BUFF_SIZE * MAX_STRING_LENGTH);

    private long addCount = 0;
    private long min = BUFF_SIZE * MAX_STRING_LENGTH;
    ///////////////


    public RDF4JConnector(String serverUri, String repositoryId) throws RepositoryException {
        server_uri = serverUri;
        repository_id = repositoryId;
        repository = new HTTPRepository(server_uri, repository_id);
        repository.initialize();
        valueFactory = repository.getValueFactory();
        connection = repository.getConnection();

        RDFParser parser = Rio.createParser(RDFFormat.NTRIPLES);
        ParserConfig config = parser.getParserConfig();
        config.addNonFatalError(NTriplesParserSettings.FAIL_ON_NTRIPLES_INVALID_LINES);
        connection.setParserConfig(config);
    }

    ///////////////////////////////////////////////////////////////////////////////
    ////////////////    Public Interface Methods    ///////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////

    @Override
    public void clear() {
        connection.clear();
    }

    @Override
    public void close() {
        connection.close();
    }

    @Override
    public boolean addQuint(IQuint quint) {
        return addStream(quint.getSubject().toString(), quint.getPredicate().toString(), quint.getObject().toString());
    }

    @Override
    public boolean addTriple(String subject, String predicate, String object) {
        return addStream(subject, predicate, object);
    }

    ///////////////////////////////////////////////////////////////////////////////
    /////////////////////    Dirty Little Helper    ///////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////
    private boolean add(String subject, String predicate, String object) {
        try {
            // create some resources and literals to make statements out of
            IRI subjectIRI = valueFactory.createIRI(subject);
            IRI predicateIRI = valueFactory.createIRI(predicate);
            IRI objectIRI = valueFactory.createIRI(object);

            connection.add(subjectIRI, predicateIRI, objectIRI);
            return true;
        } catch (RepositoryException e) {
            // handle exception
            System.out.println(e);
            return false;
        }
    }

    private boolean addStream(String subject, String predicate, String object) {
        StringBuilder sb = new StringBuilder();
        sb.append(subject + " " + " " + predicate + " " + object + " .\n");
        sbf.append(sb);
        int len = BUFF_SIZE * MAX_STRING_LENGTH - sbf.length();
        min = Math.min(min, len);
        if (addCount % BUFF_SIZE == 0) {
            InputStream in = new ByteArrayInputStream(sbf.toString().getBytes());
            try {
                connection.begin();
                connection.add(in, null, RDFFormat.NTRIPLES);
                connection.commit();
            } catch (RepositoryException | IOException e) {
                System.out.println("printTriple() Exception thrown  :" + e);
                System.out.println(sbf.toString());
                System.exit(-1);
            }
            // reset stream
            sbf.setLength(0);
        }
        return true;
    }


    ///////////////////////////////////////////////////////////////////////////////
    ///////////////////    Fast Connection Stuff    ///////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////

    private class RDF4JAddThread extends Thread {
        private final String subject;
        private final String predicate;
        private final String object;

        public RDF4JAddThread(String subject, String predicate, String object) {
            this.subject = subject;
            this.predicate = predicate;
            this.object = object;
        }

        public void run() {
            RepositoryConnection connection = repository.getConnection();
            //------> Taken from SchemEXSesameWriter
            RDFParser parser = Rio.createParser(RDFFormat.NTRIPLES);
            ParserConfig config = parser.getParserConfig();
            config.addNonFatalError(NTriplesParserSettings.FAIL_ON_NTRIPLES_INVALID_LINES);
            connection.setParserConfig(config);
            ///<-------
            try {
                StringBuilder sb = new StringBuilder();
                sb.append("<" + subject + ">");
                sb.append(" ");
                sb.append("<" + predicate + ">");
                sb.append(" ");
                sb.append("<" + object + ">");
                sb.append(" .\n");
                sbf.append(sb);

                int len = BUFF_SIZE * MAX_STRING_LENGTH - sbf.length();
                min = Math.min(min, len);

                if (addCount % BUFF_SIZE == 0) {
                    InputStream in = new ByteArrayInputStream(sbf.toString().getBytes());
                    try {
                        connection.begin();
                        connection.add(in, null, RDFFormat.NTRIPLES);
                        connection.commit();
                    } catch (RepositoryException | IOException e) {
                        System.out.println("printTriple() Exception thrown  :" + e);
                        System.out.println(sbf.toString());
                        System.exit(-1);
                    }
                    // reset stream
                    sbf.setLength(0);
                }
            } finally {
                connection.close();
            }
        }
    }
}
