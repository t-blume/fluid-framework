package de.uni_kiel.schemex.implementation.common;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.interfaces.required.IQuintSourceListener;
import de.uni_kiel.schemex.utils.BasicUtils;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class StatsProperty implements IQuintSourceListener {

    private String outFile = "out/propertyStats.csv";
    private Map<IResource, Integer> propertyMap = new HashMap<>();


    public StatsProperty(){
    }
    public StatsProperty(String outFile){
        this.outFile = outFile;
    }
    @Override
    public void pushedQuint(IQuint quint) {
        propertyMap.merge(quint.getPredicate(), 1, (OLD,NEW) -> OLD + NEW);
    }

    @Override
    public void sourceClosed() {
        File out = BasicUtils.createFile(outFile);
        FileOutputStream fos = null;
        System.out.println("Exporting properties to: " + outFile);
        try {
            fos = new FileOutputStream(out);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

            propertyMap.forEach((K,V) -> {
                try {
                    bw.write(K + "," + V);
                    bw.newLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            bw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sourceStarted() {
        System.out.println("Tracking Properties.. ");
    }
}
