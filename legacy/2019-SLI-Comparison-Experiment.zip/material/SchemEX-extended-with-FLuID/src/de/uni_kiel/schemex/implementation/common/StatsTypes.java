package de.uni_kiel.schemex.implementation.common;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.interfaces.required.IQuintSourceListener;
import de.uni_kiel.schemex.utils.BasicUtils;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class StatsTypes implements IQuintSourceListener {

    private String outFile = "out/typesStats.csv";
    private Map<IResource, Integer> typeMap = new HashMap<>();


    public StatsTypes() {
    }

    public StatsTypes(String outFile) {
        this.outFile = outFile;
    }

    @Override
    public void pushedQuint(IQuint quint) {
        if (quint.getPredicate().toString().equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"))
            typeMap.merge(quint.getObject(), 1, (OLD, NEW) -> OLD + NEW);
    }

    @Override
    public void sourceClosed() {
        File out = BasicUtils.createFile(outFile);
        FileOutputStream fos = null;
        System.out.println("Exporting properties to: " + outFile);
        try {
            fos = new FileOutputStream(out);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));

            typeMap.forEach((K, V) -> {
                try {
                    bw.write(K + "," + V);
                    bw.newLine();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            bw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sourceStarted() {
        System.out.println("Tracking Properties.. ");
    }
}
