package de.uni_kiel.schemex.implementation.provided;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.provided.IQuintProcessor;
import zbw.cau.gotham.schema.SchemaGraphInferencing;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Created by Blume Till on 16.11.2016.
 */
public class RDFSGraphFilter implements IQuintProcessor {

    public void setSchemaGraph(SchemaGraphInferencing schemaGraph) {
        this.schemaGraph = schemaGraph;
    }

    private SchemaGraphInferencing schemaGraph;
    private Set<String> filterProperties;

    public SchemaGraphInferencing getSchemaGraph(){
        return schemaGraph;
    }
    public RDFSGraphFilter(Set<String> filterProperties){
        this.schemaGraph = new SchemaGraphInferencing();
        this.filterProperties = filterProperties;
    }
    @Override
    public List<IQuint> processQuint(IQuint q) {
        //filter properties (like QuintFilter)
        if (!filterProperties.contains(q.getPredicate().toString())) {
            List<IQuint> l = new ArrayList<>();
            l.add(q);
            return l;
        } else {
            //but add them to SchemaGraph instead of plain deletion
            schemaGraph.add(q);
            return new ArrayList<>();
        }
    }
}
