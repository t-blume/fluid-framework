package de.uni_kiel.schemex.implementation.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.provided.IQuintProcessor;

/**
 * A filter for quads, which won't forward any quints which contain a predicate
 * matching a filter string
 * 
 * @author Bastian
 *
 */
public class QuintFilter implements IQuintProcessor {

	private Set<String> filters;

	/**
	 * Contructor
	 * 
	 * @param filters
	 *            The strings by which the quints' predicates will be filtered
	 */
	public QuintFilter(Set<String> filters) {
		this.filters = filters;
	}

	@Override
	public List<IQuint> processQuint(IQuint q) {

		if (!filters.contains(q.getPredicate().toString())) {
			List<IQuint> l = new ArrayList<IQuint>();
			l.add(q);
			return l;
		} else {
			// System.out.println("Filtered: " + q.toString());
			return new ArrayList<>();
		}
	}

}
