package de.uni_kiel.schemex.implementation.common;

import java.net.URI;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ITimestamp;

/**
 * Quad representation based on {@link URIResource}s. The timestamp is generated
 * on creation time
 * 
 * @author Bastian
 *
 */
public class URIQuad implements IQuint {

	private URIResource subject;
	private URIResource predicate;
	private URIResource object;
	private URIResource context;

	private ITimestamp time;
	private int hash;

	/**
	 * Constructor with missing context. Context will be initialized with NULL
	 * 
	 * @param subject
	 *            The subject
	 * @param predicate
	 *            The predicate
	 * @param object
	 *            The object
	 */
	public URIQuad(URI subject, URI predicate, URI object) {
		this(subject, predicate, object, null);
	}

	/**
	 * Constructor
	 * 
	 * @param subject
	 *            The subject
	 * @param predicate
	 *            The predicate
	 * @param object
	 *            The object
	 * @param context
	 *            The context
	 */
	public URIQuad(URI subject, URI predicate, URI object, URI context) {
		this.subject = new URIResource(subject);
		this.predicate = new URIResource(predicate);
		this.object = new URIResource(object);
		if (context == null) {
			this.context = null;
		} else
			this.context = new URIResource(context);

		// precompute hash, since quad is immutable
		hash = 17;
		hash = 31 * hash + this.subject.hashCode();
		hash = 31 * hash + this.predicate.hashCode();
		hash = 31 * hash + this.object.hashCode();

		if (this.context == null) {

			hash = 31 * hash;
		} else {
			hash = 31 * hash + this.context.hashCode();
		}

		this.time = new DateTimestamp();
	}

	@Override
	public IResource getSubject() {
		return subject;
	}

	@Override
	public IResource getPredicate() {
		return predicate;
	}

	@Override
	public IResource getObject() {
		return object;
	}

	@Override
	public IResource getContext() {
		return context;
	}

	@Override
	public ITimestamp getTimestamp() {
		return time;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof URIQuad)) {
			return false;
		}
		URIQuad other = (URIQuad) obj;

		return subject.equals(other.subject)
				&& predicate.equals(other.predicate)
				&& object.equals(other.object) && context.equals(other.context);
	}

	@Override
	public int hashCode() {
		return hash;
	}

}
