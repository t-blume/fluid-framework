package de.uni_kiel.schemex.interfaces.required;

import de.uni_kiel.schemex.common.IRelation;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;
import org.openrdf.repository.RepositoryException;

import java.util.Set;

/**
 * Listens for schema elements which are flushed out of a {@link IRelationsCache}.
 * The method is called for each schema element with its relations removed from
 * the cache.
 *
 * @author Bastian
 */
public interface IRelationListener {

    /**
     * Callback method for flushed schema elements
     *
     * @param element   The element flushed
     * @param relations The relations associated with the element
     */
    void schemaElementFlushed(IResource element, Set<IRelation> relations,
                              IRelationsCache looupCache);

    /**
     * Signals that no more schema elements will follow
     *
     * @throws RepositoryException
     */
    void finished(IRelationsCache cache);
}
