/**
 * This is an implementation only package
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.implementation;