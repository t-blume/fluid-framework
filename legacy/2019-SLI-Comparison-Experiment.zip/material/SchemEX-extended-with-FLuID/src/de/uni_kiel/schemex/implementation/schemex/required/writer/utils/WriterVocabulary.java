package de.uni_kiel.schemex.implementation.schemex.required.writer.utils;

import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.implementation.common.NodeResource;
import de.uni_kiel.schemex.implementation.schemex.common.TypeCluster;
import de.uni_kiel.schemex.implementation.schemex.required.writer.UniversalWriter;
import org.semanticweb.yars.nx.Resource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * The vocabulary used by a {@link UniversalWriter}, i.e., the prefixes etc. used
 * for writing the schema.
 *
 * @author Bastian
 */
public class WriterVocabulary {

    // TC
    /**
     * String used in the vocabulary file to specify the type of a typecluster
     */
    public static String TYPECLUSTER_TYPE = "TypeClusterType";
    /**
     * String used in the vocabulary file to specify the name of the property
     * from a typecluster to its types
     */
    public static String TYPECLUSTER_TO_TYPE = "TypeClusterToType";
    /**
     * String used in the vocabulary file to specify the name of an unresolved
     * TypeCluster
     */
    public static String TYPECLUSTER_UNRESOLVED = "TypeClusterUnresolved";
    /**
     * String used in the vocabulary file to specify the name of the property
     * from a typecluster to its equivalence class
     */
    public static String TYPECLUSTER_TO_EQC = "TypeClusterToEQC";
    /**
     * String used in the vocabulary file to specify the prefix of a typecluster
     */
    public static String TYPECLUSTER_PREFIX = "TypeClusterPrefix";
    /**
     * String used in the vocabulary file to specify the postfix of a
     * typecluster
     */
    public static String TYPECLUSTER_POSTFIX = "TypeClusterPostfix";

    // EQC
    /**
     * String used in the vocabulary file to specify the type of an equivalence
     * class
     */
    public static String EQUIVALENCECLASS_TYPE = "EquivalenceClassType";
    /**
     * String used in the vocabulary file to specify the prefix of an
     * equivalence class
     */
    public static String EQUIVALENCECLASS_PREFIX = "EquivalenceClassPrefix";
    /**
     * String used in the vocabulary file to specify the postfix of an
     * equivalence class
     */
    public static String EQUIVALENCECLASS_POSTFIX = "EquivalenceClassPostfix";

    /**
     * String used in the vocabulary file to specify the name of the property
     * from an equivalence class to an instance
     */
    public static String EQUIVALENCECLASS_TO_INSTANCE = "EquivalenceClassToInstance";
    /**
     * String used in the vocabulary file to specify the name of the property
     * from an equivalence class to a linkset
     */
    public static String EQUIVALENCECLASS_TO_LINKSET = "EquivalenceClassToLinkset";

    // Instance
    /**
     * String used in the vocabulary file to specify the name of the property
     * from an instance class to its context
     */
    public static String INSTANCE_TO_CONTEXT = "InstanceToContext";

    /**
     * String used in the vocabulary file to specify the name of the property to
     * a snippet
     */
    public static String TO_SNIPPET = "ToSnippet";
    /**
     * String used in the vocabulary file to specify the name of the property to
     * an example resource
     */
    public static String EXAMPLE_RESOURCE_PROPERTY = "ExampleResourceProperty";

    /**
     * String used in the vocabulary file to specify the name of the property to
     * a count
     */
    public static String COUNT_PROPERTY = "CountProperty";

    /**
     * String used in the vocabulary file to specify the prefix of a linkset
     */
    public static String LINKSET_PREFIX = "LinksetPrefix";
    /**
     * String used in the vocabulary file to specify the postfix of a linkset
     */
    public static String LINKSET_POSTFIX = "LinksetPostfix";

    /**
     * String used in the vocabulary file to specify the name of the property
     * from a linkset to a context
     */
    public static String LINKSET_TO_CONTEXT = "LinksetToContext";

    /**
     * String used in the vocabulary file to specify the type of a linkset
     */
    public static String LINKSET_TYPE = "LinksetType";

    /**
     * String used in the vocabulary file to specify the namespace
     */
    public static String NAMESPACE = "Namespace";
    private Map<String, String> vocab;

    /**
     * Default vocabulary
     */
    static public WriterVocabulary DEFAULT;

    static {
        Map<String, String> v = new HashMap<String, String>();

        v.put(WriterVocabulary.TYPECLUSTER_TYPE,
                "http://schemex.west.uni-koblenz.de/TypeCluster");
        v.put(WriterVocabulary.TYPECLUSTER_TO_TYPE,
                "http://schemex.west.uni-koblenz.de/hasClass");
        v.put(WriterVocabulary.TYPECLUSTER_TO_EQC,
                "http://schemex.west.uni-koblenz.de/hasSubset");
        v.put(WriterVocabulary.TYPECLUSTER_PREFIX,
                "http://schemex.west.uni-koblenz.de/tc");
        v.put(WriterVocabulary.TYPECLUSTER_POSTFIX, "");

        v.put(WriterVocabulary.EQUIVALENCECLASS_TYPE,
                "http://schemex.west.uni-koblenz.de/EquivalenceClass");
        v.put(WriterVocabulary.EQUIVALENCECLASS_PREFIX,
                "http://schemex.west.uni-koblenz.de/eq");
        v.put(WriterVocabulary.EQUIVALENCECLASS_POSTFIX, "");
        v.put(WriterVocabulary.EQUIVALENCECLASS_TO_INSTANCE,
                "http://rdfs.org/ns/void#uriLookupEndpoint");
        v.put(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET,
                "http://schemex.west.uni-koblenz.de/hasDataset");

        v.put(WriterVocabulary.LINKSET_PREFIX,
                "http://schemex.west.uni-koblenz.de/lseq");
        v.put(WriterVocabulary.LINKSET_POSTFIX, "");
        v.put(WriterVocabulary.LINKSET_TO_CONTEXT,
                "http://rdfs.org/ns/void#uriLookupEndpoint");
        v.put(WriterVocabulary.LINKSET_TYPE, "http://rdfs.org/ns/void#Dataset");

        v.put(WriterVocabulary.COUNT_PROPERTY,
                "http://schemex.west.uni-koblenz.de/entityCount");
        v.put(WriterVocabulary.EXAMPLE_RESOURCE_PROPERTY,
                "http://schemex.west.uni-koblenz.de/exampleResource");
        v.put(WriterVocabulary.TO_SNIPPET,
                "http://www.w3.org/2000/01/rdf-schema#label");

        v.put(WriterVocabulary.NAMESPACE, "http://schemex.west.uni-koblenz.de/");

        v.put(WriterVocabulary.TYPECLUSTER_UNRESOLVED,
                "http://schemex.west.uni-koblenz.de/NotResolved");

        DEFAULT = new WriterVocabulary(v);
    }

    protected WriterVocabulary(Map<String, String> vocabulary) {
        vocab = vocabulary;

    }

    /**
     * Factory method for creating a Writervocabulary from a file
     *
     * @param filename The vocabulary's file
     * @return A {@link WriterVocabulary} object containing the entries
     * specified in the file
     * @throws IOException
     */
    public static WriterVocabulary fromFile(String filename) throws IOException {
        Properties p = new Properties();

        InputStream in = Files.newInputStream(Paths.get(filename));
        p.load(in);

        Map<String, String> v = new HashMap<String, String>();
        for (String k : p.stringPropertyNames()) {
            v.put(k, p.getProperty(k));
        }

        in.close();
        return new WriterVocabulary(v);
    }

    /**
     * Returns the value of an entry
     *
     * @param entryName The name of the entry
     * @return The value of the entry, if it is contained, <code>null</code>
     * otherwise
     */
    public String getEntry(String entryName) {
        return vocab.get(entryName);
    }


    public String createEQCTriplePart(String eqc) {
        StringBuilder sb = new StringBuilder();
        sb.append("<");
        sb.append(getEntry(WriterVocabulary.EQUIVALENCECLASS_PREFIX));
        sb.append(eqc);
        sb.append(getEntry(WriterVocabulary.EQUIVALENCECLASS_POSTFIX));
        sb.append(">");
        return sb.toString();
    }

    public IResource removeEQCTriplePart(String eqc) {
        String newString = eqc.replace(getEntry(WriterVocabulary.EQUIVALENCECLASS_PREFIX), "");
        newString = newString.replace(getEntry(WriterVocabulary.EQUIVALENCECLASS_POSTFIX), "");
        return new NodeResource(new Resource(newString));
    }

    /**
     * @param tc
     * @return
     */
    public String createTCTriplePart(String tc) {
        //TODO: resolve TC here from SC
        StringBuilder sb = new StringBuilder();
        sb.append("<");
        sb.append(getEntry(WriterVocabulary.TYPECLUSTER_PREFIX));
        if (tc.equals(TypeCluster.TC_UNRESOLVED_LITERAL.getLocator().toString())) {
            sb.append("NotResolvable");
        } else if (tc.equals(TypeCluster.createEmptyTypeCluster().getLocator().toString())) {
            sb.append("NoTypes");
        } else {
            sb.append(tc);
        }
        sb.append(getEntry(WriterVocabulary.TYPECLUSTER_POSTFIX));
        sb.append(">");

        return sb.toString();
    }

    public IResource removeTCTriplePart(String tc) {
        if (tc.contains("NotResolvable"))
            return TypeCluster.TC_UNRESOLVED_LITERAL.getLocator();
        else if (tc.contains("NoTypes"))
            return TypeCluster.createEmptyTypeCluster().getLocator();
        else {
            String newString = tc.replace(getEntry(WriterVocabulary.TYPECLUSTER_PREFIX), "");
            newString = newString.replace(getEntry(WriterVocabulary.TYPECLUSTER_POSTFIX), "");
            return new NodeResource(new Resource(newString));
        }
    }

    public String createPseudoBlankNodeTriplePart(IResource node) {
        StringBuilder sb = new StringBuilder();
        sb.append("<");
        sb.append(getEntry(WriterVocabulary.LINKSET_PREFIX));
        sb.append(node.toString());
        sb.append(getEntry(WriterVocabulary.LINKSET_POSTFIX));
        sb.append(">");
        return sb.toString();
    }

    public IResource removePseudoBlankNodeTriplePart(String pbn) {
        String newString = pbn.replace(getEntry(WriterVocabulary.LINKSET_PREFIX), "");
        newString = newString.replace(getEntry(WriterVocabulary.LINKSET_POSTFIX), "");
        return new NodeResource(new Resource(newString));
    }
}
