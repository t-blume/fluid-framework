package de.uni_kiel.schemex.interfaces.required;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;

import java.util.Map;


/**
 * Created by Blume Till on 20.09.2016.
 */
public interface IExtractor {

    Map<IResource, IPayloadElement> extract(IInstanceElement instance);
}
