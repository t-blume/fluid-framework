/**
 * This package contains implementations of provided interfaces used by schemex
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.implementation.schemex.provided;