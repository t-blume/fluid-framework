package de.uni_kiel.schemex.implementation.required.materialize;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import org.semanticweb.yars.nx.Node;
import org.semanticweb.yars.nx.parser.NxParser;

public class CreateRDFSemanticMap implements Action {

	private static boolean inputFilterAcceptor(String input) {
		final String classString = "http://www.w3.org/2000/01/rdf-schema#Class";
		final String resourceString = "http://www.w3.org/2000/01/rdf-schema#Resource";

		switch (input) {
		case resourceString:
		case classString:
			return false;
		default:
			return true;
		}
	}

	private final String typeString = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type";
	private final String typeStringShort = "rdf:type";
	private final String subclass = "http://www.w3.org/2000/01/rdf-schema#subClassOf";
	private final String subclassShort = "rdfs:subClassOf";
	private final String subproperty = "http://www.w3.org/2000/01/rdf-schema#subPropertyOf";
	private final String subpropertyShort = "rdfs:subPropertyOf";
	private final String domain = "http://www.w3.org/2000/01/rdf-schema#domain";
	private final String domainShort = "rdfs:domain";
	private final String range = "http://www.w3.org/2000/01/rdf-schema#range";
	private final String rangeShort = "rdfs:range";
	private final String owlSameAs = "http://www.w3.org/2002/07/owl#sameAs";
	private final String owlSameAsShort = "owl:sameAs";

	public Map<String, List<String>> subclassMap = new HashMap<String, List<String>>();
	public Map<String, List<String>> subpropertyMap = new HashMap<String, List<String>>();
	public Map<String, List<String>> superclassMap = new HashMap<String, List<String>>();
	public Map<String, List<String>> superpropertyMap = new HashMap<String, List<String>>();
	public Map<String, List<String>> domainMap = new HashMap<String, List<String>>();
	public Map<String, List<String>> rangeMap = new HashMap<String, List<String>>();
	public Map<String, List<String>> sameAsMap = new HashMap<String, List<String>>();
	private File[] files;

	private BufferedReader reader = null;

	/**
	 * @param files
	 */
	public CreateRDFSemanticMap(File[] files) {
		this.files = files;
	}

	private boolean addToMap(String key, String value,
			Map<String, List<String>> currentMap) {
		if ((inputFilterAcceptor(key)) && (inputFilterAcceptor(value))) {
			if (currentMap.containsKey(key)) {
				List<String> currentList = currentMap.get(key);
				if (currentList == null) {
					currentList = new LinkedList<String>();
				}
				if (!currentList.contains(value)) {
					currentList.add(value);
				}
				currentMap.put(key, currentList);
			} else {
				List<String> currentList = new LinkedList<String>();
				if (!currentList.contains(value)) {
					currentList.add(value);
				}
				currentMap.put(key, currentList);
			}
			return true;
		} else {
			return false;
		}

	}

	private void parseSemanticInfo() throws IOException {
		// generate maps for stated semantic infos
		System.out
				.println("[CreateRDFSemanticMap] Creating SemanticMap - Pass 1");
		String line;
		int fileCounter = 0;

		if (files.length > 0) {
			String name = files[fileCounter].getName();

			if (name.contains(".tar.gz") || name.contains(".zip")
					|| name.contains(".bz") || name.contains(".gz")) {
				reader = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(
								files[fileCounter]))));
				System.out.println("File: " + files[fileCounter]);
			} else {

				reader = new BufferedReader(new FileReader(files[fileCounter]));
				System.out.println("File: " + files[fileCounter]);
			}

		}
		while (reader != null) {
			NxParser p = new NxParser(reader);
			while (p.hasNext()) {
				Node[] nodes = null;
				String[] parts = null;
				try {

					nodes = p.next();
					parts = new String[nodes.length];
					for (int i = 0; i < nodes.length; i++) {
						parts[i] = nodes[i].toString();
					}

				} catch (Exception e) {
					System.out.println("[WARNING]\n" + e.getMessage());
					continue;
				}

				// String[] parts = RDFFormater.formatRDFline(line);
				Map<String, List<String>> currentMap = null;
				// skip not well partitioned input
				if (parts.length < 3) {
					System.out.println("Skipping Line: " + nodes);
					continue;
				}

				if (subclass.equals(parts[1]) || subclassShort.equals(parts[1])) {
					currentMap = subclassMap;
					addToMap(parts[2], parts[0], superclassMap);
				}

				if (subproperty.equals(parts[1])
						|| subpropertyShort.equals(parts[1])) {
					currentMap = subpropertyMap;
					addToMap(parts[2], parts[0], superpropertyMap);
				}

				if (domain.equals(parts[1]) || domainShort.equals(parts[1])) {
					currentMap = domainMap;
				}

				if (range.equals(parts[1]) || rangeShort.equals(parts[1])) {
					currentMap = rangeMap;
				}

				if (owlSameAs.equals(parts[1])
						|| owlSameAsShort.equals(parts[1])) {
					currentMap = sameAsMap;

					// reverse direction
					addToMap(parts[2], parts[0], currentMap);

				}

				if (currentMap == null) {
					continue;
				}

				addToMap(parts[0], parts[2], currentMap);
				// System.out.println("[CreateRDFSemanticMap] addingToMap:\t"+parts[0]+"\t"+parts[1]+"\t"+parts[2]);
			}
			if ((++fileCounter) < this.files.length) {
				reader.close();
				String name = files[fileCounter].getName();

				if (name.contains(".tar.gz") || name.contains(".zip")
						|| name.contains(".bz") || name.contains(".gz")) {
					reader = new BufferedReader(new InputStreamReader(
							new GZIPInputStream(new FileInputStream(
									files[fileCounter]))));
					System.out.println("File: " + files[fileCounter]);
				} else {

					reader = new BufferedReader(new FileReader(
							files[fileCounter]));
					System.out.println("File: " + files[fileCounter]);
				}

			} else
				reader = null;
		}
	}

	private void parseImpliedSemantics() throws IOException {
		// find super- and subclasses implied by domain and range
		System.out
				.println("[CreateRDFSemanticMap] Creating SemanticMap - Pass 2");
		String line;
		int fileCounter = 0;

		if (files.length > 0) {
			String name = files[fileCounter].getName();

			if (name.contains(".tar.gz") || name.contains(".zip")
					|| name.contains(".bz") || name.contains(".gz")) {
				reader = new BufferedReader(new InputStreamReader(
						new GZIPInputStream(new FileInputStream(
								files[fileCounter]))));
			} else {

				reader = new BufferedReader(new FileReader(files[fileCounter]));
			}
		}

		while (reader != null) {
			NxParser p = new NxParser(reader);
			while (p.hasNext()) {
				Node[] nodes = null;
				String[] parts = null;
				try {

					nodes = p.next();
					nodes = p.next();
					parts = new String[nodes.length];
					for (int i = 0; i < nodes.length; i++) {
						parts[i] = nodes[i].toString();
					}

				} catch (Exception e) {
					System.out.println("[WARNING]\n" + e.getMessage());
					continue;
				}
				// String[] parts = RDFFormater.formatRDFline(line);

				Map<String, List<String>> currentMap = null;
				if (domain.equals(parts[1]) || domainShort.equals(parts[1])) {
					currentMap = domainMap;
				}

				if (range.equals(parts[1]) || rangeShort.equals(parts[1])) {
					currentMap = rangeMap;
				}

				if (currentMap != null) {
					List<String> superProperties = new ArrayList<String>();
					superProperties.add(parts[0]);
					CreateRDFSemanticMap.materialize(superProperties,
							subpropertyMap);
					superProperties.remove(0);

					for (String property : superProperties) {
						if (currentMap.containsKey(property)) {
							List<String> superClasses = currentMap
									.get(property);
							if (superClasses != null) {
								for (String superClass : superClasses) {
									addToMap(parts[2], superClass, subclassMap);

									addToMap(superClass, parts[2],
											superclassMap);
								}
							}
						}
					}
				}

				// System.out.println("[CreateRDFSemanticMap] addingToMap:\t"+parts[0]+"\t"+parts[1]+"\t"+parts[2]);
			}
			if ((++fileCounter) < this.files.length) {
				String name = files[fileCounter].getName();

				if (name.contains(".tar.gz") || name.contains(".zip")
						|| name.contains(".bz") || name.contains(".gz")) {
					reader = new BufferedReader(new InputStreamReader(
							new GZIPInputStream(new FileInputStream(
									files[fileCounter]))));
				} else {

					reader = new BufferedReader(new FileReader(
							files[fileCounter]));
				}

			} else
				reader = null;
		}
	}

	@Override
	public void execute() throws Exception {
		// TODO Auto-generated method stub
		parseSemanticInfo();
		parseImpliedSemantics();
	}

	public static void materialize(List<String> alternates,
			Map<String, List<String>> map) {
		int start = 0;
		int end = alternates.size();

		while (start != end) {
			for (int i = start; i < end; i++) {
				if (map.containsKey(alternates.get(i))) {
					List<String> newAlternates = map.get(alternates.get(i));
					for (String s : newAlternates) {
						if (!alternates.contains(s)) {
							alternates.add(s);
						}
					}
				}
			}
			start = end;
			end = alternates.size();
		}
	}
}
