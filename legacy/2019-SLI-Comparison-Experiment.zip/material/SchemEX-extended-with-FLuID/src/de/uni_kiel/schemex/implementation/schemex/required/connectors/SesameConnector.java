package de.uni_kiel.schemex.implementation.schemex.required.connectors;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.required.IConnector;
import org.openrdf.OpenRDFException;
import org.openrdf.model.IRI;
import org.openrdf.model.ValueFactory;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.http.HTTPRepository;
import org.openrdf.rio.*;
import org.openrdf.rio.helpers.NTriplesParserSettings;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by Blume Till on 25.08.2016.
 */
public class SesameConnector implements IConnector {
    private final int maxPredicates = 10;
    private final String server_uri;
    private final String repository_id;
    private final Repository repository;
    private final RepositoryConnection con;
    private final ValueFactory valueFactory;


    //stream writing
    private final int BUFF_SIZE = 10000;
    private final int MAX_STRING_LENGTH = 1000;
    private final StringBuffer sbf = new StringBuffer(BUFF_SIZE * MAX_STRING_LENGTH);

    private long addCount = 0;
    private long min = BUFF_SIZE * MAX_STRING_LENGTH;
    ///////////////

    public SesameConnector(String serverUri, String repositoryId) throws RepositoryException {
        server_uri = serverUri;
        repository_id = repositoryId;
        repository = new HTTPRepository(server_uri, repository_id);
        repository.initialize();
        valueFactory = repository.getValueFactory();
        con = repository.getConnection();

        //taken from SchemEXSesameWriter
        RDFParser parser = Rio.createParser(RDFFormat.NTRIPLES);
        ParserConfig config = parser.getParserConfig();
        config.addNonFatalError(NTriplesParserSettings.FAIL_ON_NTRIPLES_INVALID_LINES);
        con.setParserConfig(config);
        ///END
    }

    @Override
    public void clear() {
        con.clear();
    }

    @Override
    public void close() {
        con.close();
    }


    @Override
    public boolean addQuint(IQuint quint) {
        return addStream(quint.getSubject().toString(), quint.getPredicate().toString(), quint.getObject().toString());
    }

    @Override
    public boolean addTriple(String subject, String predicate, String object) {
        return addStream(subject, predicate, object);
    }


    private boolean add(String subject, String predicate, String object){
        try {
            // create some resources and literals to make statements out of
            IRI subjectIRI = valueFactory.createIRI(subject);
            IRI predicateIRI = valueFactory.createIRI(predicate);
            IRI objectIRI = valueFactory.createIRI(object);
            con.begin();
            con.add(subjectIRI, predicateIRI, objectIRI);
            con.commit();
            return true;
        } catch(OpenRDFException e){
            // handle exception
            System.out.println(e);
            return false;
        }
    }
    private boolean addStream(String subject, String predicate, String object){
        // InputStream method
        StringBuilder sb = new StringBuilder();
        sb.append("<" + subject + ">");
        sb.append(" ");
        sb.append("<" + predicate + ">");
        sb.append(" ");
        sb.append("<" + object + ">");
        sb.append(" .\n");
        sbf.append(sb);

        int len = BUFF_SIZE * MAX_STRING_LENGTH - sbf.length();
        min = Math.min(min, len);

        if (addCount % BUFF_SIZE == 0) {
            InputStream in = new ByteArrayInputStream(sbf.toString().getBytes());
            try {
                con.begin();
                con.add(in, null, RDFFormat.NTRIPLES);
                con.commit();
            } catch (RDFParseException | RepositoryException | IOException e) {
                System.out.println("printTriple() Exception thrown  :" + e);
                System.out.println(sbf.toString());
                System.exit(-1);
            }
            // reset stream
            sbf.setLength(0);
        }
        return true;
    }
}
