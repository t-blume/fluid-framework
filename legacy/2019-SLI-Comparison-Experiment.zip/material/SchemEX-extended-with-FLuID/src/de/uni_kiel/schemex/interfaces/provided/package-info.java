/**
 * Common interfaces for various elements involved in processing data
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.interfaces.provided;