package de.uni_kiel.schemex.implementation.schemex.required.computation;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;

import java.util.Set;

/**
 * Created by Blume Till on 10.01.2017.
 */
public interface IPayloadGenerator {

    Set<IPayloadElement> createPayload(IResource schemaElementLocator, IInstanceElement instance, IRelationsCache payloadCache);
}
