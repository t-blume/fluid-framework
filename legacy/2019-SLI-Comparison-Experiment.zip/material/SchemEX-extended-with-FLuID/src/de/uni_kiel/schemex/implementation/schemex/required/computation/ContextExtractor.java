package de.uni_kiel.schemex.implementation.schemex.required.computation;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.implementation.schemex.common.DatasourcePayload;
import de.uni_kiel.schemex.interfaces.required.IExtractor;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Blume Till on 20.09.2016.
 */
public class ContextExtractor implements IExtractor {

    @Override
    public Map<IResource, IPayloadElement> extract(IInstanceElement instance) {
        Map<IResource, IPayloadElement> payloadElementMap = new HashMap<>();
        for (IQuint q : instance.getOutgoingQuints()) {
            DatasourcePayload con = new DatasourcePayload(q.getContext());
            payloadElementMap.put(con.getLocator(), con);
        }
        return payloadElementMap;
    }
}
