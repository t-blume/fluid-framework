package de.uni_kiel.schemex.implementation.required;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import de.uni_kiel.schemex.common.ISchemaElement;
import de.uni_kiel.schemex.interfaces.provided.ISchemaElementEmitter;
import de.uni_kiel.schemex.interfaces.required.ISchemaElementListener;

/**
 * General purpose simple statistics Counts the number of schema elements and
 * lists them in a file called "schema_statistics.txt" in a given directory
 * 
 * @author Bastian
 *
 */
public class SchemaStatisticsWriter implements ISchemaElementListener {

	Map<String, Integer> histogram;

	PrintStream pw;

	/**
	 * Creates a SchemaStatisticsWriter which will write its result in a file
	 * located in the given directory
	 * 
	 * @param dir
	 *            The directory
	 */
	public SchemaStatisticsWriter(String dir) {
		histogram = new TreeMap<>();

		try {
			pw = new PrintStream(new FileOutputStream(dir + File.separator + "schema_statistics.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Creates a SchemaStatisticsWriter which will write its result in a file
	 * located in the current directory
	 */
	public SchemaStatisticsWriter() {
		this(".");
	}

	@Override
	public void elementEmitted(ISchemaElement el) {
		String name = el.getClass().getSimpleName();

		if (histogram.containsKey(name)) {
			histogram.put(name, histogram.get(name) + 1);
		} else {
			histogram.put(name, 1);
		}

	}

	@Override
	public void finished(ISchemaElementEmitter emitter) {
		pw.println("------------------------- Statistics -------------------");
		for (Entry<String, Integer> entry : histogram.entrySet()) {
			pw.println(entry.getKey() + ": " + entry.getValue());
		}

	}

}
