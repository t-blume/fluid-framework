package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.utils.Hash;


/**
 * A TypeCluster that can be identified via the Instance URI, but when
 * written as a SchemaElement it will be written as plain UnresolvedTypeCluster
 * <p>
 * Created by Blume Till on 31.10.2016.
 */
public class TypeClusterResourceUnresolved extends TypeClusterResource {
    public static String TC_NOT_RESOLVED_DUMMY = "UNIFIED-ID-FOR-UNRESOLVED_TC";

    public TypeClusterResourceUnresolved(IResource URI) {
        super(Hash.md5(Integer.toString(URI.hashCode())), URI.hashCode());
    }
}
