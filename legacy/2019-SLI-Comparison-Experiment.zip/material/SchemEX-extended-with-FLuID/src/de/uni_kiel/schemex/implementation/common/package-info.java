/**
 * 
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.implementation.common;