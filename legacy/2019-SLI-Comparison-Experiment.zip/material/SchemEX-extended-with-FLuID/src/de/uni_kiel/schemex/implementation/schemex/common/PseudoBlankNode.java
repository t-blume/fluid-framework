package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.implementation.common.StringResource;
import de.uni_kiel.schemex.implementation.common.TypedResource;
import de.uni_kiel.schemex.utils.Hash;

/**
 * Pseudo node between equivalence classes and context
 * 
 * @author Bastian
 *
 */
public class PseudoBlankNode implements IPayloadElement {

	private IResource eqc;
	private IResource context;
	private IResource locator;


	/**
	 * Constructor
	 * 
	 * @param eqc
	 *            The equivalence class
	 * @param context
	 *            The context
	 */
	public PseudoBlankNode(IResource eqc, IResource context) {

		this.eqc = eqc;
		this.context = context;

		IResource r = new StringResource(eqc + "-"
				+ Hash.md5(context.toString()));
		locator = new TypedResource(r, PseudoBlankNode.class.getName());
	}

	@Override
	public IResource getLocator() {
		return locator;
	}

	/**
	 * Getter for the equivalence class
	 * 
	 * @return The equivalence class
	 */
	public IResource getEqc() {
		return eqc;
	}

	/**
	 * Getter for the context
	 * 
	 * @return The context
	 */
	public IResource getContext() {
		return context;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof PseudoBlankNode))
			return false;

		PseudoBlankNode other = (PseudoBlankNode) obj;
		return eqc.equals(other.eqc) && context.equals(other.context);
	}

	@Override
	public int hashCode() {
		return 17 + eqc.hashCode() + 31 * context.hashCode();
	}

}
