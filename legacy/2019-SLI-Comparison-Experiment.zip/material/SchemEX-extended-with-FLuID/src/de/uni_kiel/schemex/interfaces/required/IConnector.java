package de.uni_kiel.schemex.interfaces.required;

import de.uni_kiel.schemex.common.IQuint;

/**
 * Created by Blume Till on 24.08.2016.
 */
public interface IConnector {

    void clear();

    void close();

    boolean addQuint(IQuint quint);

    boolean addTriple(String subject, String predicate, String object);

}
