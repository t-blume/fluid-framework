package de.uni_kiel.schemex.utils;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.implementation.common.DatasetStats;
import de.uni_kiel.schemex.implementation.common.PLDFilter;
import de.uni_kiel.schemex.implementation.common.StatsProperty;
import de.uni_kiel.schemex.implementation.common.StatsTypes;
import de.uni_kiel.schemex.implementation.provided.BasicQuintPipeline;
import de.uni_kiel.schemex.implementation.provided.FifoInstanceCache;
import de.uni_kiel.schemex.implementation.provided.FileQuadSource;
import de.uni_kiel.schemex.implementation.provided.NoisyDataFilter;
import de.uni_kiel.schemex.implementation.required.DeAnonymizer;
import de.uni_kiel.schemex.implementation.required.InstanceAggregator;
import de.uni_kiel.schemex.implementation.schemex.required.writer.utils.WriterVocabulary;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.interfaces.provided.IQuintSource;
import de.uni_kiel.schemex.interfaces.required.IQuintSourceListener;

import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public class AdvancedUtils {
    private static final String PREFIX = "http://www.w3.org/2002/07/owl#";

    public static void main(String[] args) {
        String filename = "out/laundromat-stats.csv";


        List<String> filenames = new LinkedList<>();
        filenames.add("out/btc14-stats.csv");
        filenames.add("out/dyldo-stats.csv");
        filenames.add("out/laundromat-stats.csv");
        filenames.add("out/timbl-stats.csv");

        try {
            owlUsageTotal(filenames);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void owlUsageTotal(List<String> fins) throws IOException {


        int distinctTotalProperties = 0;
        long sumTotalProperties = 0L;
        int distinctPrefixProperties = 0;
        long sumPrefixProperties = 0L;

        List<PropertyOccurence> prefixPropertyOccurences = new LinkedList<>();
        Map<String, Integer> combinedPrefixProperties = new HashMap<>();


        for(String fin : fins){
            FileInputStream fis = new FileInputStream(fin);
            //Construct BufferedReader from InputStreamReader
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));

            String line = null;
            while ((line = br.readLine()) != null) {
                String[] cells = line.split(",");
                String property;
                Integer occurence;

                if(cells.length > 2){
                    property = cells[0];
                    for(int i=1; i < cells.length-1;i++)
                        property += "," + cells[i];

                    occurence = Integer.valueOf(cells[cells.length-1]);

                }else{
                    property = cells[0];
                    occurence = Integer.valueOf(cells[1]);
                }
                //propertyOccurences.add(propertyOccurence);
                sumTotalProperties += occurence;

                if (property.startsWith(PREFIX)) {
                    distinctPrefixProperties++;
                    sumPrefixProperties += occurence;
                    combinedPrefixProperties.merge(property, occurence, (OLD,NEW) -> OLD + NEW);
                }
            }
            br.close();
        }
        combinedPrefixProperties.forEach((P,O) -> prefixPropertyOccurences.add(new PropertyOccurence(P,O)));

        System.out.println("Total properties: " + sumTotalProperties);
        System.out.println("_______________________");
        System.out.println("Total owl-properties: " + sumPrefixProperties);
        System.out.println("Distinct owl-properties: " + distinctPrefixProperties);
        System.out.println("-----------------------");
        Collections.sort(prefixPropertyOccurences, Comparator.comparingInt(o -> o.occurence));
        Collections.reverse(prefixPropertyOccurences);
        prefixPropertyOccurences.forEach(PO -> System.out.println(PO));
    }

    private static void owlUsage(String fin) throws IOException {
        FileInputStream fis = new FileInputStream(fin);

        //Construct BufferedReader from InputStreamReader
        BufferedReader br = new BufferedReader(new InputStreamReader(fis));

        //List<PropertyOccurence> propertyOccurences = new LinkedList<>();

        int distinctTotalProperties = 0;
        long sumTotalProperties = 0L;
        int distinctPrefixProperties = 0;
        long sumPrefixProperties = 0L;

        List<PropertyOccurence> prefixPropertyOccurences = new LinkedList<>();


        String line = null;
        while ((line = br.readLine()) != null) {
            String[] cells = line.split(",");
            String property;
            Integer occurence;

            if(cells.length > 2){
                property = cells[0];
                for(int i=1; i < cells.length-1;i++)
                    property += "," + cells[i];

                occurence = Integer.valueOf(cells[cells.length-1]);

            }else{
                property = cells[0];
                occurence = Integer.valueOf(cells[1]);
            }
            PropertyOccurence propertyOccurence = new PropertyOccurence(property, occurence);
            //propertyOccurences.add(propertyOccurence);

            distinctTotalProperties++;
            sumTotalProperties += propertyOccurence.getOccurence();

            if (propertyOccurence.getProperty().startsWith(PREFIX)) {
                distinctPrefixProperties++;
                sumPrefixProperties += propertyOccurence.getOccurence();
                prefixPropertyOccurences.add(propertyOccurence);
            }
        }

        br.close();

        System.out.println("Total properties: " + sumTotalProperties);
        System.out.println("Distinct properties: " + distinctTotalProperties);
        System.out.println("_______________________");
        System.out.println("Total owl-properties: " + sumPrefixProperties);
        System.out.println("Distinct owl-properties: " + distinctPrefixProperties);
        System.out.println("-----------------------");
        Collections.sort(prefixPropertyOccurences, Comparator.comparingInt(o -> o.occurence));
        Collections.reverse(prefixPropertyOccurences);
        prefixPropertyOccurences.forEach(PO -> System.out.println(PO));
    }

    private static FileQuadSource createFileQuadSource(String inputFile, boolean fileFilter) {
        List<String> filePaths = new LinkedList<>();
        filePaths.add(inputFile);
        final String finalRegex = ".*data\\.nq.*";

        if (!inputFile.matches(".*\\.[a-zA-Z]") && fileFilter) {
            return new FileQuadSource(filePaths, true, "http://schemex.west.uni-koblenz.de/",
                    (FileFilter) pathname -> {
                        if (pathname != null) {
                            boolean t = pathname.toString().matches(finalRegex);
                            if (t) {
                                System.out.println("Adding: " + pathname.toString());
                                return true;
                            } else
                                return false;
                        }

                        return
                                false;
                    });
        } else
            return new FileQuadSource(filePaths, true, "http://schemex.west.uni-koblenz.de/");
    }

    public static void propertyStatistics(String inputFile, String outputFile, boolean fileFilter) {
        List<String> filePaths = new LinkedList<>();
        filePaths.add(inputFile);
        IQuintSource source = createFileQuadSource(inputFile, fileFilter);
        source.registerQuintListener(new StatsProperty(outputFile));
        source.start();
    }

    public static void typeStatistics(String inputFile, String outputFile, boolean fileFilter) {
        List<String> filePaths = new LinkedList<>();
        filePaths.add(inputFile);
        IQuintSource source = createFileQuadSource(inputFile, fileFilter);
        source.registerQuintListener(new StatsTypes(outputFile));
        source.start();
    }

    public static void datasetStatistics(String inputFile, String outputFile, boolean fileFilter) {
        List<String> filePaths = new LinkedList<>();
        filePaths.add(inputFile);
        IQuintSource source = createFileQuadSource(inputFile, fileFilter);
        IElementCache<IInstanceElement> cache = new FifoInstanceCache<>();
        InstanceAggregator instanceAggregator = new InstanceAggregator(cache, true);
        DatasetStats datasetStats = new DatasetStats(outputFile);

        BasicQuintPipeline pipe = new BasicQuintPipeline();
        // Cleanup dirty data
        pipe.addProcessor(new NoisyDataFilter("http://schemex.de/broken/", true, "."));
        // Deanonymize the context URIs
        pipe.addProcessor(new DeAnonymizer("http://schemex.de/"));

        pipe.registerQuintListener(instanceAggregator);
        source.registerQuintListener(pipe);
        //listen to instances and calculate statistics
        cache.registerCacheListener(datasetStats);

        source.start();
    }
    public static void quadFiltering(String inputFile, Set<String> contexts, String outputFile, boolean fileFilter) {
        List<String> filePaths = new LinkedList<>();
        filePaths.add(inputFile);
        IQuintSource source = createFileQuadSource(inputFile, fileFilter);
        try {
            source.registerQuintListener(new PLDFilter(outputFile, contexts));
        } catch (IOException e) {
            e.printStackTrace();
        }
        source.start();
    }


    public static HashSet<String> loadContexts(String filename) {
        HashSet<String> contextURIs = new HashSet<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                // process the line.
                String[] split = line.split(";");
                if (split.length > 1)
                    //contextURIs.add(split[0], Integer.valueOf(split[1]));
                    contextURIs.add(split[0]);
                else
                    //contextURIs.add(split[0], -1);
                    contextURIs.add(split[0]);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return contextURIs;
    }

    public static void compareRDFFiles(List<String> filePaths1, List<String> filePaths2) {

        HashSet<IQuint> quints1 = new HashSet<>();
        HashSet<IQuint> quints2 = new HashSet<>();

        IQuintSource source1 = new FileQuadSource(filePaths1, false,
                "http://fluid.informatik.uni-kiel.de/");
        source1.registerQuintListener(new IQuintSourceListener() {
            @Override
            public void pushedQuint(IQuint quint) {
                quints1.add(quint);
            }

            @Override
            public void sourceClosed() {
                System.out.println("Source1 closed!");
            }

            @Override
            public void sourceStarted() {

            }
        });


        IQuintSource source2 = new FileQuadSource(filePaths2, false,
                "http://fluid.informatik.uni-kiel.de/");
        source2.registerQuintListener(new IQuintSourceListener() {
            @Override
            public void pushedQuint(IQuint quint) {
                quints2.add(quint);
            }

            @Override
            public void sourceClosed() {
                System.out.println("Source2 closed!");
            }

            @Override
            public void sourceStarted() {
            }
        });
        source2.start();

        Thread thread1 = new Thread(() -> source1.start());
        thread1.start();

        Thread thread2 = new Thread(() -> source2.start());
        thread2.start();

        //wait for finish
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("All caches filled!");

        int hits = 0;

        int totalSet1 = quints1.size();
        int totalSet2 = quints2.size();

        List<IQuint> remainingSource1 = new LinkedList<>();

        for (IQuint quint : quints1) {
            if (quints2.contains(quint)) {
                hits++;
                quints2.remove(quint);
            } else
                remainingSource1.add(quint);

        }
        System.out.println("=======================");
        System.out.println("Set_1: " + totalSet1);
        System.out.println("Set_2: " + totalSet2);

        System.out.println("hits: " + hits);
        System.out.println("Set_1/not in Set_2: " + remainingSource1.size());
        System.out.println("Set_2/not in Set_1: " + quints2.size());

        System.out.println("Coverage_1: " + new DecimalFormat("#.00").format(((double) hits / (double) (hits + remainingSource1.size())) * 100) + "%");
        System.out.println("Coverage_2: " + new DecimalFormat("#.00").format(((double) hits / (double) (hits + quints2.size())) * 100) + "%");


        System.out.println("=======================");

    }

    static class PropertyOccurence {

        private final String property;
        private final Integer occurence;

        public PropertyOccurence(String property, Integer occurence) {
            this.property = property;
            this.occurence = occurence;
        }

        public String getProperty() {
            return property;
        }

        public Integer getOccurence() {
            return occurence;
        }

        @Override
        public int hashCode() {
            return property.hashCode() ^ occurence.hashCode();
        }

        @Override
        public boolean equals(Object o) {
            if (!(o instanceof PropertyOccurence)) return false;
            PropertyOccurence other = (PropertyOccurence) o;
            return this.property.equals(other.getProperty()) &&
                    this.occurence.equals(other.getOccurence());
        }

        @Override
        public String toString() {
            return property + ", " + occurence;
        }
    }

}
