package de.uni_kiel.schemex.implementation.schemex.required.writer;

import de.uni_kiel.schemex.common.IRelation;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ISchemaElement;
import de.uni_kiel.schemex.implementation.common.NamedRelation;
import de.uni_kiel.schemex.implementation.common.RDFInstance;
import de.uni_kiel.schemex.implementation.common.SimpleRelation;
import de.uni_kiel.schemex.implementation.common.TypedResource;
import de.uni_kiel.schemex.implementation.schemex.common.*;
import de.uni_kiel.schemex.implementation.schemex.required.connectors.Connection;
import de.uni_kiel.schemex.implementation.schemex.required.writer.sinks.FileTripleSink;
import de.uni_kiel.schemex.implementation.schemex.required.writer.sinks.GraphStoreTripleSink;
import de.uni_kiel.schemex.implementation.schemex.required.writer.utils.WriterVocabulary;
import de.uni_kiel.schemex.interfaces.provided.IQuintSink;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;
import de.uni_kiel.schemex.interfaces.provided.ISchemaElementEmitter;
import de.uni_kiel.schemex.interfaces.required.IRelationListener;
import de.uni_kiel.schemex.interfaces.required.ISchemaElementListener;
import de.uni_kiel.schemex.utils.Constants;
import org.semanticweb.yars.nx.Literal;
import org.semanticweb.yars.nx.namespace.XSD;
import org.semanticweb.yars.nx.util.NxUtil;

import java.io.*;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.GZIPOutputStream;

/**
 * A universal writer class for turning a SchemEX schema into the N-Triple format. It can
 * be configured using different vocabulary files. As a parameter it gets
 * Triple-Sinks to actually write the triples (File, Sesame, Virtuoso,...)
 *
 * @author Till
 * @author Bastian
 */
public class UniversalWriter implements IRelationListener, ISchemaElementListener {

    private int successfullUpdates = 0;
    private int updateTries = 0;
    private int unresolvedCount = 0;
    private int newUnresolvedCount = 0;
    ////////////////////////////////////////////////////////////
    //////// Static Methods to create the known Writers ////////
    ////////////////////////////////////////////////////////////

    /**
     * Creates A FileWriter
     *
     * @param vocab
     * @param splitPayload
     * @param zip
     * @param outputDir
     * @param debug
     * @return
     * @throws IOException
     */
    public static UniversalWriter getFileWriter(WriterVocabulary vocab, boolean splitPayload, boolean zip, String outputDir,
                                                boolean clearRepo, boolean debug) throws IOException {
        return getFileWriter(vocab, splitPayload, zip, outputDir, clearRepo, debug, "schema");
    }

    public static UniversalWriter getFileWriter(WriterVocabulary vocab, boolean splitPayload, boolean zip, String outputDir,
                                                boolean clearRepo, boolean debug, String schemaName) throws IOException {
        PrintStream schemaWriter;
        PrintStream payloadWriter;
        if (zip) {
            schemaWriter = new PrintStream(new BufferedOutputStream(
                    new GZIPOutputStream(new FileOutputStream(outputDir + File.separator + "SchemEX+_" + schemaName + ".nt.gz"))));
        } else
            schemaWriter = new PrintStream(outputDir + File.separator + "SchemEX+_" + schemaName + ".nt");
        // Write the payload in a separate file only on request!!!
        if (!splitPayload) {
            payloadWriter = schemaWriter;
        } else {
            if (zip) {
                payloadWriter = new PrintStream(new BufferedOutputStream(
                        new GZIPOutputStream(new FileOutputStream(outputDir + File.separator + "payload.nt.gz"))));
            } else
                payloadWriter = new PrintStream(outputDir + File.separator + "payload.nt");
        }
        return new UniversalWriter(new FileTripleSink(schemaWriter, debug),
                new FileTripleSink(payloadWriter, debug),
                vocab, clearRepo);
    }

    /**
     * Creates a SesameWriter
     *
     * @param vocab
     * @param output
     * @param debug
     * @return
     * @throws IOException
     */
    public static UniversalWriter getSesameWriter(WriterVocabulary vocab, String output,
                                                  boolean clearRepo, boolean debug) throws IOException {
        return new UniversalWriter(new GraphStoreTripleSink(Connection::getSesameConnector,
                "http://localhost:8080/openrdf-sesame", output, debug),
                new GraphStoreTripleSink(Connection::getSesameConnector,
                        "http://localhost:8080/openrdf-sesame", output, debug),
                vocab, clearRepo);
    }

    /**
     * Creates a SesameWriter
     *
     * @param vocab
     * @param output
     * @param debug
     * @return
     * @throws IOException
     */
    public static UniversalWriter getRDF4JWriter(WriterVocabulary vocab, String output,
                                                 boolean clearRepo, boolean debug) throws IOException {
        return new UniversalWriter(new GraphStoreTripleSink(Connection::getRDF4JConnector,
                "http://localhost:8080/rdf4j-server/", output, debug),
                new GraphStoreTripleSink(Connection::getRDF4JConnector,
                        "http://localhost:8080/rdf4j-server/", output, debug),
                vocab, clearRepo);
    }


    ////////////////////////////////////////////////////////////
    ////////		UniversalWriter Implementation 		////////
    ////////////////////////////////////////////////////////////
    private int TCElemsWritten = 0;
    private int EQCElemsWritten = 0;
    private int TCUElemsWritten = 0;
    private int PBNElemsWritten = 0;

    private int TCRelationWritten = 0;
    private int EQCRelationWritten = 0;
    private int TCURelationWritten = 0;
    private int PBNRelationWritten = 0;

    //"Statement" writer
    private final IQuintSink schemaSink;
    private final IQuintSink payloadSink;

    private final WriterVocabulary vocab;


    public UniversalWriter(IQuintSink schemaSink, IQuintSink payloadSink, WriterVocabulary vocab, boolean clearRepo) {
        this.schemaSink = schemaSink;
        this.payloadSink = payloadSink;
        this.vocab = vocab;

        if (clearRepo) {
            schemaSink.clear();
            payloadSink.clear();
            System.out.println("Repository cleared");
        }
    }

    @Override
    public void finished(IRelationsCache cache) {
        // TODO Auto-generated method stub
    }

    public void close() {
        if (schemaSink != null) {
            schemaSink.close();
        }
        if (payloadSink != null) {
            payloadSink.close();
        }
        System.out.println("TCElemsWritten: " + TCElemsWritten);
        System.out.println("EQCElemsWritten: " + EQCElemsWritten);
        System.out.println("TCUElemsWritten: " + TCUElemsWritten);
        System.out.println("PBNElemsWritten: " + PBNElemsWritten);

        System.out.println("TCRelationWritten: " + TCRelationWritten);
        System.out.println("EQCRelationWritten: " + EQCRelationWritten);
        System.out.println("TCURelationWritten: " + TCURelationWritten);
        System.out.println("PBNRelationWritten: " + PBNRelationWritten);

        System.out.println("TCUpdate Tries: " + updateTries);
        System.out.println("TCUpdate Successful: " + successfullUpdates);

        System.out.println("UnresolvedTC: " + unresolvedCount);
        System.out.println("TCUnresolved: " + newUnresolvedCount);
    }


    /**
     * If SchemaCache flushes a SchemaElement and all of its relations,
     * this method is called with the schema element, its relations and
     * the SchemaCache as parameter.
     *
     * @param element     The element flushed
     * @param relations
     * @param lookupCache
     */
    @Override
    public void schemaElementFlushed(IResource element,
                                     Set<IRelation> relations, IRelationsCache lookupCache) {
        // Dispatch the element type and write out its relations

        // ... EQC relations schemex:hasDataset, relations to other TCs
        if (element instanceof EquivalenceClassResource) {
            writeEQCRelations(element, relations, lookupCache);
            // ... TC relations schemex:hasSubset
        } else if (element instanceof TypeClusterResource) {
            writeTypeClusterRelations(element, relations, lookupCache);
        } else if (element instanceof TypeClusterResourceUnresolved) {
            writeTypeClusterRelations(element, relations, lookupCache);
            TCURelationWritten++;
        } else if (element instanceof TypedResource) {
            String type = ((TypedResource) element).getType();
            // .. "Snippets"
            PBNRelationWritten++;
            if (type.equals(RDFInstance.RESOURCE_TYPE)) {
                writeInstanceRelation(relations);
                // ... also Snippets? But seems to be unused so far!
            } else if (type.equals(DatasourcePayload.RESOURCE_TYPE)) {
                writeContextRelation(relations);
                // ... void:uriLookupEndpoint
            } else if (type.equals(PseudoBlankNode.class.getName())) {
                writePseudoBlankNodeRelations(element, relations, lookupCache);
            }
        }
    }

    /**
     * If a SchemaElement is created and not in the SchemaCache,
     * this method is called with the schema element as parameter.
     * <p>
     * This method serves as dispatcher for writing out
     * - Type Clusters
     * - Equivalence Classes
     * - Pseudo blank nodes (in the payload like the void#Dataset)
     *
     * @param element
     */
    @Override
    public void elementEmitted(ISchemaElement element) {
        // Dispatch the request
        if (element instanceof TypeCluster) {
            TypeCluster t = (TypeCluster) element;
            writeTypeCluster(t);
            TCElemsWritten++;
        } else if (element instanceof EquivalenceClass) {
            EquivalenceClass eqc = (EquivalenceClass) element;
            writeEQC(eqc);
            EQCElemsWritten++;
        } else if (element instanceof PseudoBlankNode) {
            PseudoBlankNode p = (PseudoBlankNode) element;
            writePseudoBlankNode(p);
            PBNElemsWritten++;
        } else if (element instanceof TypeClusterResourceUnresolved)
            TCUElemsWritten++;
    }

    @Override
    public void finished(ISchemaElementEmitter emitter) {
        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()));


    }

    ///******************************************************///
    ///*****	Writer Methods on SchemaCache Flush 	*****///
    ///******************************************************///

    /**
     * Writes the relations a TC has, here the relations to EQCs
     *
     * @param tc
     * @param relations
     * @param lookupCache
     */
    protected void writeTypeClusterRelations(IResource tc, Set<IRelation> relations, IRelationsCache lookupCache) {
        // if unresolved TC, try to resolve in SC
        String tcNode;
        if (tc instanceof TypeClusterResourceUnresolved) {
            relations.forEach(X -> System.out.println(X));
            return;
        } else {
            //Normal procedure
            // Write the TC relations,
            tcNode = createTCTriplePart(tc.toString());
        }

        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()) + " " + tcNode);
        int n = 0;
        for (IRelation r : relations) {
            TCRelationWritten++;
            schemaSink.print(tcNode, "<" + vocab.getEntry(WriterVocabulary.TYPECLUSTER_TO_EQC) + ">",
                    createEQCTriplePart(r.getTarget().toString()));
            // Aggregate to n all uriLookupEndpoints attached to the EQC
            n += countEQCInstances(r.getTarget(), lookupCache.getRelations(r.getTarget()), lookupCache);
        }
        // Write out number of uriLookupEndpoints aggregated over all EQCs attached to this TC
        schemaSink.print(tcNode, "<" + vocab.getEntry(WriterVocabulary.COUNT_PROPERTY) + ">",
                new Literal(Integer.toString(n), XSD.INTEGER).toN3());
    }

    protected void writeEQCRelations(IResource eqc, Set<IRelation> relations,
                                     IRelationsCache lookupCache) {
        // Write out all relations!
        String eqcNode = createEQCTriplePart(eqc.toString());

        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()) + " " + eqcNode);

        for (IRelation r : relations) {
            EQCRelationWritten++;
            // Going to TC
            if (r instanceof NamedRelation) {
                NamedRelation nr = (NamedRelation) r;
                if (nr.getName().equals("pseudo")) {
                    // Writes out the relation hasDataset
                    schemaSink.print(eqcNode, "<" + vocab.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET) + ">",
                            createPseudoBlankNodeTriplePart(nr.getTarget()));
                } else {
                    // Writes out the relation to other TCs
                    //check if TC can be resolve now
                    if (r.getTarget() instanceof TypeClusterResourceUnresolved) {
                        updateTries++;
                        Set<IRelation> resolvedTC = lookupCache.getRelations(r.getTarget());

                        //System.out.println(realTC);
                        //if it was resolved now, write relation to correct TC
                        if (resolvedTC != null && !resolvedTC.isEmpty()) {
                            System.out.println(resolvedTC.size());
                            schemaSink.print(eqcNode, r.toString(), createTCTriplePart(resolvedTC.iterator().next().getTarget().toString()));
                            successfullUpdates++;
                        } else {
                            //if not, write Unresolved TC
                            schemaSink.print(eqcNode, r.toString(), createTCTriplePartUnresolved(r.getTarget().toString()));
                        }

                    } else //else normal procedure
                        //if(r.getTarget() instanceof  TypeClusterResource)
                        schemaSink.print(eqcNode, r.toString(), createTCTriplePart(r.getTarget().toString()));

                }
            } else {
                // FIXME: I think this is never used! -- Ansgar to check again once a new log is generated
                // Writes out the relations uriLookupEndpoint
                schemaSink.print(eqcNode, "<" + vocab.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_INSTANCE) + ">",
                        r.getTarget().toN3());
            }
        }

        // Write out count information
        int n = countEQCInstances(eqc, relations, lookupCache);
        schemaSink.print(eqcNode, "<" + vocab.getEntry(WriterVocabulary.COUNT_PROPERTY) + ">",
                new Literal(Integer.toString(n), XSD.INTEGER).toN3());
    }


    /**
     * Writes the (outgoing) relations of a pseudo blank node, e.g., here
     * the datasources attached to a dataset and the count information.
     *
     * @param node
     * @param relations
     * @param lookupCache
     */
    protected void writePseudoBlankNodeRelations(IResource node,
                                                 Set<IRelation> relations, IRelationsCache lookupCache) {
        // Print the references to the datasources (i.e.,
        // void:uriLookupEndpoint)

        //TODO: instances are collected from SimpleRelations and then never used!
        //TODO: instances are only counted, therefore they do not have to be in the cache
        Set<IResource> instances = new HashSet<>();
        String nTriple = createPseudoBlankNodeTriplePart(node);

        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()) + " " + nTriple);

        int num = 0;
        for (IRelation r : relations) {
            // Instances
            if (r instanceof SimpleRelation
                    && !instances.contains(r.getTarget())) {
                num++;
                instances.add(r.getTarget());
            } else if (r instanceof NamedRelation) {
                NamedRelation nr = (NamedRelation) r;
                if (nr.getName().equals("context")) {
                    // Write out the uriLookupEndpoint (i.e. context)
                    payloadSink.print(nTriple, "<" + vocab.getEntry(WriterVocabulary.LINKSET_TO_CONTEXT) + ">",
                            nr.getTarget().toN3());
                } else if (nr.getName().equals("example")) {
                    // Writes out an example URI using schemex:exampleResource
                    payloadSink.print(nTriple, "<" + vocab.getEntry(WriterVocabulary.EXAMPLE_RESOURCE_PROPERTY) + ">",
                            nr.getTarget().toN3());
                } else if (nr.getName().equals("count")) {
                    // Print count information, i.e., number of datasources
                    payloadSink.print(nTriple, "<" + vocab.getEntry(WriterVocabulary.COUNT_PROPERTY) + ">",
                            new Literal(nr.getTarget().toString(), XSD.INTEGER).toN3());
                }
            }
        }

    }


    // TODO: Seems to be unused so far, too.
    protected void writeContextRelation(Set<IRelation> relations) {
        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()));

        // Write out all relations of the context (i.e., the uriLookupEndpoint)
        for (IRelation r : relations) {
            IResource s = r.getSource();
            IResource t = r.getTarget();
            if (r instanceof NamedRelation) {
                NamedRelation n = (NamedRelation) r;

                if (n.getName().equals("snippet")) {

                    String snippet = t.toN3();
                    if (snippet != null) {
                        snippet = normalizeLiteral(snippet);
                        schemaSink.print(s.toN3(), "<" + vocab.getEntry(WriterVocabulary.TO_SNIPPET) + ">",
                                snippet);
                    }
                }
            }
        }
    }

    /**
     * Writes out any snippet (rdfs:label) attached to an instance
     * FIXME: an instance has up to three snippets (see example below) but it is much
     * more useful to take a single snippet but from multiple (up to three) examples
     * <p>
     * Example resource
     * <schemex.west.uni-koblenz.de/lseq08c520aadeb4b3b6ade103f852ea81a8-81bbc12690aaf68663718aabe654851b>
     * <http://schemex.west.uni-koblenz.de/exampleResource>
     * <http://www.w3.org/People/Berners-Lee/card#i>
     * Snippets
     * <http://www.w3.org/People/Berners-Lee/card#i>
     * <http://www.w3.org/2000/01/rdf-schema#label>
     * "Tim"
     * <http://www.w3.org/People/Berners-Lee/card#i>
     * <http://www.w3.org/2000/01/rdf-schema#label>
     * "Tim Berners-Lee"
     * <http://www.w3.org/People/Berners-Lee/card#i>
     * <http://www.w3.org/2000/01/rdf-schema#label>
     * "Timothy Berners-Lee"
     **/
    protected void writeInstanceRelation(Set<IRelation> relations) {
        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()));

        int count = 0;
        // Write out instances
        for (IRelation r : relations) {
            IResource s = r.getSource();
            IResource t = r.getTarget();
            if (r instanceof NamedRelation) {
                NamedRelation n = (NamedRelation) r;
                // Writes out "snippets" using rdfs:label
                if (n.getName().equals("snippet")) {
                    String snippet = t.toString();
                    if (snippet != null) {
                        snippet = normalizeLiteral(snippet);
                        schemaSink.print(s.toN3(), "<" + vocab.getEntry(WriterVocabulary.TO_SNIPPET) + ">",
                                "\"" + snippet + "\"");
                        count++;
                        if (count > 2)
                            break;
                    } // if
                } // if
            } // if
        } // for

    }
    ///******************************************************///
    ///*****	Writer Methods on InstanceCache Flush 	*****///
    ///******************************************************///

    /**
     * Writes a Type Cluster URI together with its schemex:hasClass
     *
     * @param tc
     */
    protected void writeTypeCluster(TypeCluster tc) {
        if (tc.getLocator() instanceof TypeClusterResourceUnresolved)
            System.out.println("Huehuehuehue");
        // Write the type cluster
        String tcNode = createTCTriplePart(tc.toString());

        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()) + " " + tcNode);

        schemaSink.print(tcNode, "<" + Constants.RDF_TYPE + ">",
                "<" + vocab.getEntry(WriterVocabulary.TYPECLUSTER_TYPE) + ">");
        // Add pseudo type for unresolved cluster
        //TODO: Unresolved TC here
        if (tc.getLocator().toString().equals(TypeCluster.TC_UNRESOLVED_LITERAL.getLocator().toString())) {
            unresolvedCount++;
            schemaSink.print(tcNode, "<" + vocab.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE) + ">",
                    "<" + vocab.getEntry(WriterVocabulary.TYPECLUSTER_UNRESOLVED) + ">");
        } else {
            // Write out the types of the TC
            for (String s : tc.getTypes()) {
                // FIXME Empty string should not happen
                if (s.trim().equals("")) {
                    schemaSink.print(tcNode, "<" + vocab.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE) + ">",
                            "<" + vocab.getEntry(WriterVocabulary.NAMESPACE) + "empty/" + ">");
                } else {
                    schemaSink.print(tcNode, "<" + vocab.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE) + ">",
                            s);
                }
            }
        }
    }

    /**
     * Just writes a single triple containing the EQC and the rdf:type schemex:EquivalenceClass
     *
     * @param eqc
     */
    protected void writeEQC(EquivalenceClass eqc) {
        String eqcNode = createEQCTriplePart(eqc.toString());
        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()) + " " + eqcNode);
        // Write the EQC and the type information schemex:EquivalenceClass
        schemaSink.print(eqcNode, "<" + Constants.RDF_TYPE + ">",
                "<" + vocab.getEntry(WriterVocabulary.EQUIVALENCECLASS_TYPE) + ">");
    }


    /**
     * Writes a pseudo blank node, e.g., here
     * a URI representing a void#dataset
     *
     * @param n
     */
    protected void writePseudoBlankNode(PseudoBlankNode n) {
        // Write the pseudo blank node
        String t = createPseudoBlankNodeTriplePart(n.getLocator());

        // Print stack trace for debugging
        schemaSink.printComment(traceToString(Thread.currentThread().getStackTrace()) + " " + t);
        schemaSink.print(t, "<" + Constants.RDF_TYPE + ">",
                "<" + vocab.getEntry(WriterVocabulary.LINKSET_TYPE) + ">");
    }


    ////////////////////////////////////////////////////////////
    //////// 			Helper Functions 				////////
    ////////////////////////////////////////////////////////////

    /**
     * Helper function to normalize a literal
     *
     * @param literal
     * @return
     */
    public static String normalizeLiteral(String literal) {
        // Replace control characters \r and \n
        String sn = literal.replace("\\r", " ");
        sn = sn.replace("\\n", " ");
        // Try to remove unnecessary backspaces
        String sTemp = NxUtil.unescape(sn);
        // In case, there was some error, use previous result to escape
        // FIXME: seems like a hack
        if (sTemp == null)
            sn = NxUtil.escapeForNx(sn);
        else
            sn = NxUtil.escapeForNx(sTemp);
        // Remove whitespaces
        sn = sn.replaceAll("\\s+", " ");
        return sn;
    }

    /**
     * Generates a nice string from the current stack trace!
     *
     * @param e
     * @return
     */
    private static String traceToString(StackTraceElement e[]) {
        int i = 0;
        String str = e[1].getMethodName();
        for (StackTraceElement s : e) {
            if (i > 1 && i < 4) {
                str = str + (":");
                str = str + (s.getMethodName());
            }
            i = i + 1;
        }
        return str;
    }


    /**
     * Count number of uriLookupEndpoints aggregated over all EQCs attached to this TC
     *
     * @param eqc         TODO: this parameter is not used! check if needed at all - maybe in some other context its useful
     * @param relations
     * @param lookupCache
     * @return
     */
    protected int countEQCInstances(IResource eqc, Set<IRelation> relations, IRelationsCache lookupCache) {
        // Not relations? No uriLookupEndpoints
        if (relations == null) {
            return 0;
        }

        // Get all void#Dataset attached to this EQC
        Set<IResource> instances = new HashSet<IResource>();
        // Aggregate counts over equivalence classes
        int n = 0;
        for (IRelation r : relations) {
            if (r instanceof NamedRelation) {
                NamedRelation nr = (NamedRelation) r;
                if (nr.getName().equals("pseudo")) {
                    n += countPseudoBlankNodeInstances(nr.getTarget(), lookupCache, instances);
                }
            }
        }
        return n;
    }

    /**
     * Count number of uriLookupEndpoint attached to a void#Dataset
     *
     * @param node
     * @param lookupCache
     * @param instancesFound
     * @return
     */
    protected int countPseudoBlankNodeInstances(IResource node,
                                                IRelationsCache lookupCache, Set<IResource> instancesFound) {

        int n = 0;

        Set<IRelation> rels = lookupCache.getRelations(node);
        if (rels == null) {
            return 0;
        }
        for (IRelation r : rels) {

            // Instances
            if (r instanceof SimpleRelation
                    && !instancesFound.contains(r.getTarget())) {
                n++;
                instancesFound.add(r.getTarget());
            }
        }

        return n;
    }


    private String createEQCTriplePart(String eqc) {
        StringBuilder sb = new StringBuilder();
        sb.append("<");
        sb.append(vocab.getEntry(WriterVocabulary.EQUIVALENCECLASS_PREFIX));
        sb.append(eqc);
        sb.append(vocab.getEntry(WriterVocabulary.EQUIVALENCECLASS_POSTFIX));
        sb.append(">");
        return sb.toString();
    }

    /**
     * @param tc
     * @return
     */
    private String createTCTriplePart(String tc) {
        //TODO: resolve TC here from SC
        StringBuilder sb = new StringBuilder();
        sb.append("<");
        sb.append(vocab.getEntry(WriterVocabulary.TYPECLUSTER_PREFIX));
        if (tc.equals(TypeCluster.TC_UNRESOLVED_LITERAL.getLocator().toString())) {
            unresolvedCount++;
            sb.append("NotResolvable");
        } else if (tc.equals(TypeCluster.createEmptyTypeCluster().getLocator().toString()))
            sb.append("NoTypes");
        else
            sb.append(tc);

        sb.append(vocab.getEntry(WriterVocabulary.TYPECLUSTER_POSTFIX));
        sb.append(">");

        return sb.toString();
    }

    private String createTCTriplePartUnresolved(String tc) {
        StringBuilder sb = new StringBuilder();
        sb.append("<");
        sb.append(vocab.getEntry(WriterVocabulary.TYPECLUSTER_PREFIX));
        if (tc.equals(TypeCluster.createEmptyTypeCluster().getLocator().toString()))
            sb.append("NoTypes");
        else {
            sb.append("NotResolvable");
            newUnresolvedCount++;
        }
        sb.append(vocab.getEntry(WriterVocabulary.TYPECLUSTER_POSTFIX));
        sb.append(">");
        return sb.toString();
    }

    private String createPseudoBlankNodeTriplePart(IResource node) {
        StringBuilder sb = new StringBuilder();
        sb.append("<");
        sb.append(vocab.getEntry(WriterVocabulary.LINKSET_PREFIX));
        sb.append(node.toString());
        sb.append(vocab.getEntry(WriterVocabulary.LINKSET_POSTFIX));
        sb.append(">");
        return sb.toString();
    }
}
