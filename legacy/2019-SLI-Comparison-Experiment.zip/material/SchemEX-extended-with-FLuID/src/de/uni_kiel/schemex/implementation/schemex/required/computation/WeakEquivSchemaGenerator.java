package de.uni_kiel.schemex.implementation.schemex.required.computation;

import de.uni_kiel.schemex.common.*;
import de.uni_kiel.schemex.implementation.common.*;
import de.uni_kiel.schemex.implementation.required.TransInstanceAggregator;
import de.uni_kiel.schemex.implementation.schemex.common.*;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;
import de.uni_kiel.schemex.utils.Hash;
import org.semanticweb.yars.nx.Literal;

import java.io.PrintStream;
import java.util.*;

import static de.uni_kiel.schemex.implementation.schemex.common.TypeCluster.TC_EMPTY;

/**
 * Created by Blume Till on 20.09.2016.
 */
public class WeakEquivSchemaGenerator extends RDFSSchemaGenerator {
    //TODO parameter
    public static boolean debug = true;

    private HashMap<String, IResource> srcRelated = new HashMap<>();
    private HashMap<IResource, Set<String>> srcLookUp = new HashMap<>();
    private HashMap<String, IResource> trgRelated = new HashMap<>();
    private HashMap<IResource, Set<String>> trgLookUp = new HashMap<>();

    private TransInstanceAggregator instanceAggregator;


    private Set<Link> linkSet = new TreeSet<>();//0-bisim use empty linkset
    private Set<Link> linkSetOut = new TreeSet<>();
    private Set<Link> linkSetIn = new TreeSet<>();

    Set<IResource> payloadContexts = new HashSet<>();


    public WeakEquivSchemaGenerator(int bisimulationDepth, String typeClassifier, IElementCache<IInstanceElement> instanceCache, IElementCache<BackwardInstance> backwardCache) {
        super(bisimulationDepth, typeClassifier, instanceCache, backwardCache);
    }

    public WeakEquivSchemaGenerator(int bisimulationDepth, String typeClassifier, IElementCache<IInstanceElement> instanceCache, IElementCache<BackwardInstance> backwardCache, Boolean useIncomingProperties) {
        super(bisimulationDepth, typeClassifier, instanceCache, backwardCache, useIncomingProperties);
    }


    @Override
    public Set<ISchemaElement> createSchemaIndex(IInstanceElement instance, IRelationsCache schemaCache) {
        TransInstance transInstance = null;
        if (instance instanceof TransInstance)
            transInstance = (TransInstance) instance;
        else {
            System.out.println("Not proper configured!");
            System.exit(-1);
        }

        Set<ISchemaElement> schemaElements = new HashSet<>();


        //TODO: implement for this as well
        //add additional properties based on Schema Graph
        //instance = inferProperties(instance);

        Set<String> types;
        if (schemaGraph != null)
            types = schemaGraph.inferSubjectTypes(instance);
        else
            types = getTypes(instance);

        ISchemaElement tc = new TypeCluster(types);

        boolean SC_TC_Miss = !schemaCache.contains(tc.getLocator());
        if (SC_TC_Miss)
            schemaElements.add(tc);

//        //see if TC can be resolved now
        IResource unresolvedTC = new TypeClusterResourceUnresolved(instance.getLocator());
        //fake create unresolved TC Resource to check if it is in SC
        if (schemaCache.contains(unresolvedTC)) {
            //found previous unresolved TC, link it to the newly created (should only be one)
            updates++;
            schemaCache.add(new SimpleRelation(unresolvedTC, tc.getLocator()));
        }

//        BackwardInstance back = new BackwardInstance(instance.getLocator(), tc.getLocator());
//        backwardCache.add(back);


        if (bisimulationDepth > 0) {
            System.out.println("Creating linkset...");
            createLinkSet(instance, 1, schemaCache);
        }

        System.out.println("Creating EQC...");
        //create EQC

        ISchemaElement schemaElement = new EquivalenceClass(linkSet, tc.getLocator());
        // add to output elements
        boolean SC_EQC_Miss = !schemaCache.contains(schemaElement.getLocator());
        if (SC_EQC_Miss)
            schemaElements.add(schemaElement);

        //add simple relation
        schemaCache.add(new SimpleRelation(tc.getLocator(), schemaElement.getLocator()));

        //check the OR
        String srcHash = Hash.md5(Integer.toString(linkSetOut.hashCode()));
        String trgHash = Hash.md5(Integer.toString(linkSetIn.hashCode()));

        boolean srcRel = srcRelated.containsKey(srcHash);
        boolean trgRel = trgRelated.containsKey(trgHash);

        IResource srcSE = null;
        IResource trgSE = null;

        if (srcRel)
            srcSE = srcRelated.get(srcHash);
        if (trgRel)
            trgSE = trgRelated.get(trgHash);

        if (srcSE != null && trgSE != null && srcSE != trgSE) {
            //recursive merge of Schema Elements
            //TODO if happens, add debug
            System.out.println("Updating Merging Data structure...");
            //Strategy: set everything to src
            Set<String> trgHashs = trgLookUp.remove(trgSE);
            for (String hash : trgHashs)
                trgRelated.put(hash, srcSE);

            final IResource tmp = srcSE;
            Set<IRelation> tmpRelations = schemaCache.getRelations(trgSE);
            //when we had a cache flush, this information is gone already
            if (tmpRelations != null) {
                tmpRelations.forEach(REL -> schemaCache.remove(REL));
                tmpRelations.forEach(REL -> REL.setSource(tmp));
                tmpRelations.forEach(REL -> schemaCache.add(REL));
            }
        }

        if (srcRel || trgRel) {
            addSrc(srcHash, srcSE);
            addTrg(trgHash, srcSE);
        } else {
            addSrc(srcHash, schemaElement.getLocator());
            addTrg(trgHash, schemaElement.getLocator());
            schemaElementResource = schemaElement.getLocator();
        }

        if (srcSE != null)
            schemaElementResource = srcSE;
        else if (trgSE != null)
            schemaElementResource = trgSE;


        System.out.println("Adding " + linkSet.size() + " links to Schema Cache...");
        int tmpCount = 0;
        for (Link l : linkSet) {
            IRelation relation = new NamedRelation(schemaElement.getLocator(), l.getObject(), l.getProperty().toN3());
            schemaCache.add(relation);
            tmpCount++;
            if (tmpCount % 1000 == 0)
                System.out.println("Added " + tmpCount + "/" + linkSet.size() + " links");
        }

        tmpCount = 0;
        //compute DataSourcePayload here!!
        if (payloadContexts != null) {
            payloadContexts.forEach(C -> {
                DatasourcePayload con = new DatasourcePayload(C);
                PseudoBlankNode payloadSchemaElement = new PseudoBlankNode(schemaElement.getLocator(),
                        con.getLocator());

                schemaCache.add(new NamedRelation(schemaElement.getLocator(),
                        payloadSchemaElement.getLocator(), "pseudo"));
                schemaCache.add(new NamedRelation(payloadSchemaElement.getLocator(), con.getLocator(), "context"));
            });
            tmpCount++;
            if (tmpCount % 1000 == 0)
                System.out.println("Added " + tmpCount + "/" + payloadContexts.size() + " payload elements");
        }
        //return all elements
        return schemaElements;
    }

    @Override
    protected Set<Link> createLinkSet(IInstanceElement instance, int currentDepth, IRelationsCache schemaCache) {
        if (instance == null)
            return null;
        if (currentDepth < 0 || currentDepth > bisimulationDepth)
            System.err.println("[BisimError] bisim depth: " + bisimulationDepth + ", current depth: " + currentDepth);
//        else
//            System.out.println(instance.getLocator() + "(Depth: " + currentDepth
//                    + ")");
        //+ " outgoingProps: " + instance.getOutgoingQuints().size() + ", " + "incomingProps: " + instance.getIncomingQuints().size());


        linkSet = new TreeSet<>();//0-bisim use empty linkset
        linkSetOut = new TreeSet<>();
        linkSetIn = new TreeSet<>();


        TransInstance transInstance = null;
        if (instance instanceof TransInstance)
            transInstance = (TransInstance) instance;
        else {
            System.out.println("Not proper configured!");
            System.exit(-1);
        }
        if (bisimulationDepth > 0) {
            //build schema links for base instance
            for (IQuint quint : transInstance.getOutgoingQuints()) {
                Link l = createLink(quint, currentDepth, schemaCache);
                if (l != null) {
                    linkSetOut.add(l);
                    linkSet.add(l);
                }
            }

            for (IQuint quint : transInstance.getIncomingQuints()) {
                Link l = createLink(quint, currentDepth, schemaCache);
                if (l != null) {
                    linkSet.add(l);
                    linkSetIn.add(l);
                }
            }

            //get all srcRelated instances
            Set<IResource> srcRelated = new HashSet<>();
            srcRelated.add(transInstance.getLocator());
            iterateOutgoing(transInstance, srcRelated);

            int cachesize = instanceCache.size();

//            if (debug)
//                System.out.println("Building and Computing instance... ");

            if (debug)
                srcRelatedMerges.add(srcRelated.size());

            //get all trgRelated instances
            Set<IResource> trgRelated = new HashSet<>();
            trgRelated.add(transInstance.getLocator());
            iterateIncoming(transInstance, trgRelated);

//            if (debug)
//                trgRelatedMerges.add(trgRelated.size());
//
//            if (debug)
//                System.out.println("Building and Computing Combined Instances (" + srcRelated.size() + ") ...");

            long tmp = System.currentTimeMillis();
            Set<IResource> seenOutProps = new HashSet<>();
            Set<IResource> seenInProps = new HashSet<>();


            int counter = 0;
            for (IResource resource : srcRelated) {
                IInstanceElement instanceElement = instanceCache.remove(resource);
                if (instanceElement != null) {
                    //build schema for related instances
                    for (IQuint quint : instanceElement.getOutgoingQuints()) {
                        if (!seenOutProps.contains(quint.getPredicate())) {
                            Link l = createLink(quint, currentDepth, schemaCache);
                            if (l != null) {
                                linkSet.add(l);
                                linkSetOut.add(l);
                            }
                            seenOutProps.add(quint.getPredicate());
                        }
                        //optimization here to remove redundancy
                        payloadContexts.add(quint.getContext());

                    }
                    if (trgRelated.contains(resource)) {
                        for (IQuint quint : instanceElement.getIncomingQuints()) {
                            if (!seenInProps.contains(quint.getPredicate())) {
                                Link l = createLink(quint, currentDepth, schemaCache);
                                if (l != null) {
                                    linkSet.add(l);
                                    linkSetIn.add(l);
                                }
                                seenInProps.add(quint.getPredicate());
                            }
                        }
                    }
                }
                counter++;
//                if (counter % 1000000 == 0) {
//                    System.out.println("Progress: " + (int) (((double) counter / (double) srcRelated.size()) * 100) + "%");
//                    System.out.println("LinkSet (outgoing): " + linkSet.size());
//                    System.out.println("Elapsed: " + (System.currentTimeMillis() - tmp) + "ms");
//                    tmp = System.currentTimeMillis();
//                }
            }

            //not needed anymore
            seenOutProps.clear();
            counter = 0;
            for (IResource resource : trgRelated) {
                IInstanceElement instanceElement = instanceCache.remove(resource);
                if (instanceElement != null) {
                    for (IQuint quint : instanceElement.getIncomingQuints()) {
                        if (!seenInProps.contains(quint.getPredicate())) {
                            Link l = createLink(quint, currentDepth, schemaCache);
                            if (l != null) {
                                linkSet.add(l);
                                linkSetIn.add(l);
                            }
                            seenInProps.add(quint.getPredicate());
                        }
                    }
                }
                counter++;
                if (counter % 10000 == 0) {
                    System.out.println("Progress: " + (int) (((double) counter / (double) trgRelated.size()) * 100) + "%");
                    System.out.println("LinkSet (incoming): " + linkSetIn.size());
                    System.out.println("Elapsed: " + (System.currentTimeMillis() - tmp) + "ms");
                    tmp = System.currentTimeMillis();
                }
            }
            removedInstances += (cachesize - instanceCache.size());
            if (debug && (removedInstances - lastPrintOut) > 50) {
                lastPrintOut = removedInstances;
                System.out.println("removed: " + removedInstances);
                System.out.println("left: " + instanceCache.size());
            }

        }
        return linkSet;

    }

    protected Link createLink(IQuint quint, int currentDepth, IRelationsCache schemaCache) {
        // only check non type predicates (without TC, nothing equals null)
        if (quint.getPredicate().toString().equals(typesClassifier))
            return null;

        //define object
        IResource object = quint.getObject();

        IResource targetInstanceLocator = new TypedResource(object, RDFInstance.RESOURCE_TYPE);

        //literals are dead ends for bisimulation
        if (currentDepth >= bisimulationDepth || object instanceof NodeResource &&
                ((NodeResource) object).getNode() instanceof Literal) {
            return new Link(quint.getPredicate(), TC_EMPTY.getLocator());
        } else {
            //follow bisimulation
            BackwardInstance backwardTargetInstance = backwardCache.get(targetInstanceLocator);
            IResource targetEQC;
            //get previously computed SE from Cache
            if ((backwardTargetInstance != null) &&
                    (targetEQC = backwardTargetInstance.getTentativeEquivalanceClassResources().get(currentDepth)) != null) {
                //found previously computed smaller EQC
                return new Link(quint.getPredicate(), targetEQC);
            } else {
                //else compute new one
                if (instanceCache.contains(targetInstanceLocator)) {
                    IInstanceElement targetInstance = instanceCache.get(targetInstanceLocator);
                    //reCURSION!!
                    Set<Link> targetLinkSet = createLinkSet(targetInstance, (currentDepth + 1), schemaCache);
                    ISchemaElement target = new EquivalenceClass(targetLinkSet, TC_EMPTY.getLocator());
                    BackwardInstance updateTargetBack;
                    if (backwardCache.contains(targetInstanceLocator))
                        updateTargetBack = backwardCache.get(targetInstanceLocator);
                    else {
                        updateTargetBack = new BackwardInstance(targetInstanceLocator, target.getLocator());
                        backwardCache.add(updateTargetBack);
                    }
                    updateTargetBack.addTentativeEquivalenceClassResource(1, target.getLocator());

                    //create linkSet with ECQ as target instead of TC
                    return new Link(quint.getPredicate(), target.getLocator());
                } else //then we just hope it simply does not exist
                    return new Link(quint.getPredicate(), TC_EMPTY.getLocator());
            }
        }
    }

    private void addSrc(String hash, IResource schemaElement) {
        srcRelated.put(hash, schemaElement);
        Set<String> tmpValues = new HashSet<>();
        tmpValues.add(hash);
        srcLookUp.merge(schemaElement, tmpValues, (OLD, NEW) -> {
            OLD.addAll(NEW);
            return OLD;
        });
    }

    private void addTrg(String hash, IResource schemaElement) {
        trgRelated.put(hash, schemaElement);
        Set<String> tmpValues = new HashSet<>();
        tmpValues.add(hash);
        trgLookUp.merge(schemaElement, tmpValues, (OLD, NEW) -> {
            OLD.addAll(NEW);
            return OLD;
        });
    }



    private int removedInstances = 0;
    private int lastPrintOut = 0;
    private List<Integer> srcRelatedMerges = new LinkedList<>();
    private List<Integer> trgRelatedMerges = new LinkedList<>();




    private void iterateIncoming(TransInstance transInstance, Set<IResource> trgRelated) {
        Queue<IQuint> propertyQueue = new ArrayDeque<>();
        propertyQueue.addAll(transInstance.getIncomingQuints());
        Set<IResource> seenProps = new HashSet<>();

        int counter = 0;
        //for each incoming property
        while (!propertyQueue.isEmpty()) {
//            if (debug && counter % 1000 == 1)
//                System.out.println("Property Queue Size: " + propertyQueue.size());
            IQuint quint = propertyQueue.poll();
            if (!seenProps.contains(quint.getPredicate())) {
                seenProps.add(quint.getPredicate());
                // for each instance that also uses this property as outgoing property
                for (IResource locator : instanceAggregator.trgRelatedProperties.get(quint.getPredicate())) {
                    //for each related instance, also check their related instances (if not done already)
                    if (!trgRelated.contains(locator)) {
                        trgRelated.add(locator);
                        if (instanceCache.contains(locator))
                            propertyQueue.addAll(instanceCache.get(locator).getIncomingQuints());

                    }
                }
            }
            counter++;
        }
    }

    private void iterateOutgoing(TransInstance transInstance, Set<IResource> srcRelated) {
        Queue<IQuint> propertyQueue = new ArrayDeque<>();
        propertyQueue.addAll(transInstance.getOutgoingQuints());
        Set<IResource> seenProps = new HashSet<>();

        int counter = 0;
        //for each outgoing property
        while (!propertyQueue.isEmpty()) {
            IQuint quint = propertyQueue.poll();

//            if (debug && counter % 100 == 1)
//                System.out.println("Property Queue Size: " + propertyQueue.size());

            // for each instance that also uses this property as outgoing property
            if (!seenProps.contains(quint.getPredicate())) {
                seenProps.add(quint.getPredicate());

                for (IResource locator : instanceAggregator.srcRelatedProperties.get(quint.getPredicate())) {
                    //for each related instance, also check their related instances (if not done already)
                    if (!srcRelated.contains(locator)) {
                        srcRelated.add(locator);
                        if (instanceCache.contains(locator))
                            propertyQueue.addAll(instanceCache.get(locator).getOutgoingQuints());

                    }
                }
            }
            counter++;
        }
    }

    private void iterateOutgoingRecursive(TransInstance transInstance, Set<IResource> srcRelated) {
        /*
            iterate over all instances that share at least one property
         */
        //for each outgoing property
        for (IQuint quint : transInstance.getOutgoingQuints()) {
            // for each instance that also uses this property as outgoing property
            for (IResource locator : instanceAggregator.srcRelatedProperties.get(quint.getPredicate())) {
                //for each related instance, also check their related instances (if not done already)
                if (!srcRelated.contains(locator)) {
                    srcRelated.add(locator);
                    if (instanceCache.contains(locator))
                        iterateOutgoing((TransInstance) instanceCache.get(locator), srcRelated);
                }
            }
        }
    }


    private void recursiveMergeOutgoing(TransInstance transInstance, Set<IResource> seen) {
        IInstanceElement tmpInstance;
        /*
            iterate over all instances that share at least one property
         */

        //for each outgoing property
        for (IQuint quint : transInstance.getOutgoingQuints()) {
            // for each instance that also uses this property as outgoing property
            for (IResource locator : instanceAggregator.srcRelatedProperties.get(quint.getPredicate())) {
                //retrieve instance from cache
                if ((tmpInstance = instanceCache.get(locator)) != null) {
                    //add also all of their properties to the instance
                    tmpInstance.getOutgoingQuints().forEach(Q -> transInstance.addOutgoingQuint(Q));
                    //for each related instance, also check their related instances (if not done already)
                    if (!seen.contains(locator)) {
                        seen.add(locator);
                        recursiveMergeOutgoing(transInstance, seen);
                    }
                }
            }
        }
    }

    private void recursiveMergeIncoming(TransInstance transInstance, Set<IResource> seen) {
        IInstanceElement tmpInstance;
        /*
            iterate over all instances that share at least one property
         */

        //for each outgoing property
        for (IQuint quint : transInstance.getIncomingQuints()) {
            // for each instance that also uses this property as outgoing property
            for (IResource locator : instanceAggregator.trgRelatedProperties.get(quint.getPredicate())) {
                //retrieve instance from cache
                if ((tmpInstance = instanceCache.get(locator)) != null) {
                    //add also all of their properties to the instance
                    tmpInstance.getIncomingQuints().forEach(Q -> transInstance.addIncomingQuint(Q));
                    //for each related instance, also check their related instances (if not done already)
                    if (!seen.contains(locator)) {
                        seen.add(locator);
                        recursiveMergeIncoming(transInstance, seen);
                        //TODO: can we safely remove the merged instances from cache?
                    }
                }
            }
        }
    }

    /**
     * Overwrite this method to model the OR (either incoming or outgoing)
     *
     * @param instance
     * @param currentDepth
     * @param schemaCache
     * @return
     */
    protected Set<Link> createLinkSetOut(IInstanceElement instance, int currentDepth, IRelationsCache schemaCache) {
        if (instance == null)
            return null;
        if (currentDepth < 0 || currentDepth > bisimulationDepth)
            System.err.println("[BisimError] bisim depth: " + bisimulationDepth + ", current depth: " + currentDepth);
//        else {
//            System.out.println(instance.getLocator() + "(Depth: " + currentDepth
//                    + ")" + " outgoingProps: " + instance.getOutgoingQuints().size() + ", " + "incomingProps: " + instance.getIncomingQuints().size());
//        }


        Set<Link> linkSet = new TreeSet<>();
        //for each quint, create a link (a link represents a path of bisim length)
        for (IQuint quint : instance.getOutgoingQuints()) {
            Link l = createLink(quint, currentDepth, schemaCache);
            if (l != null)
                linkSet.add(l);
        }
        return linkSet;
    }

    protected Set<Link> createLinkSetIn(IInstanceElement instance, int currentDepth, IRelationsCache schemaCache) {
        if (instance == null)
            return null;
        if (currentDepth < 0 || currentDepth > bisimulationDepth)
            System.err.println("[BisimError] bisim depth: " + bisimulationDepth + ", current depth: " + currentDepth);
//        else {
//            System.out.println(instance.getLocator() + "(Depth: " + currentDepth
//                    + ")" + " outgoingProps: " + instance.getOutgoingQuints().size() + ", " + "incomingProps: " + instance.getIncomingQuints().size());
//        }


        Set<Link> linkSet = new TreeSet<>();
        //for each quint, create a link (a link represents a path of bisim length)
        for (IQuint quint : instance.getIncomingQuints()) {
            Link l = createLink(quint, currentDepth, schemaCache);
            if (l != null)
                linkSet.add(l);
        }
        return linkSet;
    }

    public void setInstanceAggregator(TransInstanceAggregator instanceAggregator) {
        this.instanceAggregator = instanceAggregator;
    }

    @Override
    public void finished() {
        super.finished();
        printStatistics(System.out);
    }


    public void printStatistics(PrintStream printStream) {
        printStream.println("==== Property Related Equivalence Statistics ====");
        printStream.println("Removed Instances: " + removedInstances);
        //printStream.println("Src Related Merges: " + srcRelatedMerges.size());

        int totalSrcRelatedMerges = 0;
        for (Integer x : srcRelatedMerges)
            totalSrcRelatedMerges += x;

        printStream.println("Total Src-Related Instance-Merges: " + totalSrcRelatedMerges);
        printStream.println("Average Src-Related Instance-Merges: " + (double) totalSrcRelatedMerges / (double) srcRelatedMerges.size());


        int totalTrgRelatedMerges = 0;
        for (Integer x : trgRelatedMerges)
            totalTrgRelatedMerges += x;

        printStream.println("Total Trg-Related Instance-Merges: " + totalTrgRelatedMerges);
        printStream.println("Average Trg-Related Instance-Merges: " + (double) totalTrgRelatedMerges / (double) trgRelatedMerges.size());
        printStream.println("=================================================");
    }
}