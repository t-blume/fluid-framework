package de.uni_kiel.schemex.implementation.common;

import de.uni_kiel.schemex.common.ITimestamp;

/**
 * Timestamp with a Date
 * @author Bastian
 *
 */
public class DateTimestamp implements ITimestamp {

}
