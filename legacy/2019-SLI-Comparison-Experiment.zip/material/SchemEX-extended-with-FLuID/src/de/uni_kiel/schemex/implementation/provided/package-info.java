/**
 * This package contains some basic implementations of provided interfaces, such as streaming data from files and caches
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.implementation.provided;