package de.uni_kiel.schemex.implementation.schemex.required.computation;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ISchemaElement;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;

import java.util.Set;

/**
 * Created by Blume Till on 16.11.2016.
 */
public interface ISchemaGenerator {

    void enableLogging(String filepath, String name);

    Set<ISchemaElement> createSchemaIndex(IInstanceElement instance, IRelationsCache schemaCache);

    IResource getSchemaElementLocator();

    void finished();
}
