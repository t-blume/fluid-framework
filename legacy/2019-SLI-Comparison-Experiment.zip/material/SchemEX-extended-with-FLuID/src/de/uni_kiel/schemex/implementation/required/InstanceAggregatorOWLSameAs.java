package de.uni_kiel.schemex.implementation.required;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.implementation.common.OWLSameAsInstance;
import de.uni_kiel.schemex.implementation.common.Quad;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.utils.Constants;

/**
 * Aggregates information of instances
 * 
 * @author Blume Till
 *
 */
public class InstanceAggregatorOWLSameAs extends InstanceAggregator {

	public InstanceAggregatorOWLSameAs(IElementCache<IInstanceElement> cache, boolean useIncomingProps) {
		super(cache, useIncomingProps);
	}

	@Override
	public void finishedQuint(IQuint i) {
		super.finishedQuint(i);
		//insert owl:sameAS ALWAYS as symmetric relation
		if(i.getPredicate().toString().equals(Constants.OWL_SameAs))
			addQuint2Cache(new Quad(i.getObject(), i.getPredicate(), i.getSubject(), i.getContext()), false);
	}

	@Override
	protected IInstanceElement createInstance(IQuint quint){
		return new OWLSameAsInstance(quint.getSubject());
	}

	@Override
	public void finished() {
		cache.close();
	}
}
