package de.uni_kiel.schemex.implementation.schemex.required.writer.sinks;

import de.uni_kiel.schemex.interfaces.provided.IQuintSink;
import de.uni_kiel.schemex.interfaces.required.IConnector;
import de.uni_kiel.schemex.implementation.schemex.required.connectors.Connection;

/**
 * Created by Blume Till on 07.10.2016.
 */
public class GraphStoreTripleSink implements IQuintSink {
    private IConnector connection;
    private boolean debug;
    private int count = 0;

    public GraphStoreTripleSink(Connection.DBConnection dbConnection, String url, String graph, boolean debug) {
        connection = dbConnection.getConnector(url, graph);
        this.debug = debug;
    }

    @Override
    public void print(String... statement) {
        String[] prepared = prepareStatement(statement);
        if (prepared != null) {
            connection.addTriple(prepared[0], prepared[1], prepared[2]);
            count++;
            if (count % 1000 == 0)
                System.out.format("Add Triple: %08d    \r", count);

        }
    }


    @Override
    public void printComment(String comment) {
        if (debug)
            System.out.println(comment);
    }

    @Override
    public String[] prepareStatement(String... statement) {
        if (statement == null || statement.length != 3)
            System.err.println("[GraphStoreTripleSink] Invalid statement!");
        else {
            String[] prepared = new String[statement.length];
            for (int i = 0; i < statement.length; i++) {
                if (statement[i] != null) {
                    String tmp = statement[i].trim();
                    if (!tmp.startsWith("<") && !tmp.startsWith("\""))
                        tmp = "<" + tmp;
                    if (!tmp.endsWith(">") && !tmp.startsWith("\""))
                        tmp = tmp + ">";
                    prepared[i] = tmp;
                } else
                    prepared[i] = null;
            }
            return prepared;
        }
        return null;
    }

    @Override
    public void close() {
        connection.close();
    }

    @Override
    public void clear() {
        connection.clear();
    }


    public IConnector getConnection() {
        return connection;
    }
}
