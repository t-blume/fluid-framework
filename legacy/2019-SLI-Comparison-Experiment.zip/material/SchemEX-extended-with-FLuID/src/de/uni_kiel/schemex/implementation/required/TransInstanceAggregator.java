package de.uni_kiel.schemex.implementation.required;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.implementation.common.*;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.utils.Constants;

import java.util.*;

import static de.uni_kiel.schemex.implementation.common.RDFInstance.RESOURCE_TYPE;

/**
 * Aggregates information of instances
 *
 * @author Blume Till
 */
public class TransInstanceAggregator extends InstanceAggregator {

    public Map<IResource, Set<IResource>> srcRelatedProperties;
    public Map<IResource, Set<IResource>> trgRelatedProperties;

    private Queue<IResource> queue;
    int maxCacheSize;


    public TransInstanceAggregator(IElementCache<IInstanceElement> cache, boolean useIncomingProps, int maxCacheSize) {
        super(cache, useIncomingProps);
        this.maxCacheSize = maxCacheSize;
        queue = new ArrayDeque<>();
        srcRelatedProperties = new HashMap<>();
        trgRelatedProperties = new HashMap<>();
    }

    @Override
    public void finishedQuint(IQuint i) {
        //collect all instances using a specific property
        Set<IResource> src = new HashSet<>();
        src.add(new TypedResource(i.getSubject(), RESOURCE_TYPE));
        srcRelatedProperties.merge(i.getPredicate(), src, (OLD, NEW) -> {
            OLD.addAll(src);
            return OLD;
        });

        if(useIncomingProps){
            Set<IResource> trg = new HashSet<>();
            trg.add(i.getObject());
            trgRelatedProperties.merge(i.getPredicate(), trg, (OLD, NEW) -> {
                OLD.addAll(src);
                return OLD;
            });
        }
        //creates/updates instances
        addQuint2Cache(i, true);
        //add incoming props as inverted props
        if(useIncomingProps)
            addQuint2Cache(new Quad(i.getObject(), i.getPredicate(), i.getSubject(), i.getContext()), false);
    }

    @Override
    protected void addQuint2Cache(IQuint quint, boolean asOutgoing){
        TransInstance element = new TransInstance(quint.getSubject());
        if (cache.contains(element.getLocator()))
            element = (TransInstance) cache.get(element.getLocator());
        else
            cache.add(element);

        if(asOutgoing) {
            element.addOutgoingQuint(quint);
            //all instances that use the same property as outgoing property
            //element.addAllSrcPropertyRelatedInstances(srcRelatedProperties.get(quint.getPredicate()));
        }
        else {
            element.addIncomingQuint(quint);
            //all instances that use the same property as incoming property
            //element.addAllTrgPropertyRelatedInstances(trgRelatedProperties.get(quint.getPredicate()));
        }
    }


    @Override
    public void finished() {
        cache.close();
    }
}
