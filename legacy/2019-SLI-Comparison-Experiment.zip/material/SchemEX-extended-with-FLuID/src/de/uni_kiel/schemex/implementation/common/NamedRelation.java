package de.uni_kiel.schemex.implementation.common;

import de.uni_kiel.schemex.common.IRelation;
import de.uni_kiel.schemex.common.IResource;

/**
 * A relation between two {@link IResource}s, which has a name
 * 
 * @author Bastian
 *
 */
public class NamedRelation implements IRelation {

	private String name;
	private IResource source;
	private IResource target;

	/**
	 * Constructor
	 * 
	 * @param source
	 *            The start of the relation
	 * @param target
	 *            The end of the relation
	 * @param name
	 *            The relation's name
	 */
	public NamedRelation(IResource source, IResource target, String name) {
		this.source = source;
		this.target = target;
		this.name = name;
	}

	@Override
	public IResource getSource() {
		return source;
	}

	@Override
	public void setSource(IResource resource) {
		this.source = resource;
	}

	@Override
	public IResource getTarget() {
		return target;
	}

	@Override
	public String toString() {
		return name;
	}

	public String getName() {
		return name;
	}

	@Override
	public int hashCode() {
		return 17 + name.hashCode() + 31 * source.hashCode()
				+ target.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof NamedRelation))
			return false;

		NamedRelation n = (NamedRelation) obj;
		return name.equals(n.name) && source.equals(n.source)
				&& target.equals(n.target);
	}

}
