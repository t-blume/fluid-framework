package de.uni_kiel.schemex.implementation.required.materialize;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.implementation.common.NodeResource;
import de.uni_kiel.schemex.implementation.common.Quad;
import de.uni_kiel.schemex.interfaces.provided.IQuintProcessor;
import de.uni_kiel.schemex.utils.Constants;
import org.semanticweb.yars.nx.Resource;

/**
 * A processor which materializes input data. In a first step it has to be
 * initialized. It will analyze the given vocabulary data and afterwards produce
 * triples materializing input
 * 
 * @author Bastian
 *
 */
public class MaterializeAggregator implements IQuintProcessor {

	private CreateRDFSemanticMap map;

	/**
	 * Constructor
	 * 
	 * @param input
	 *            The input. Should be a list of directories or files.
	 *            Directories will be expanded, but not subdirectories
	 */
	public MaterializeAggregator(List<File> input) {

		List<File> inExpanded = new ArrayList<File>();
		for (File f : input) {
			if (f.isDirectory()) {
				for (File f2 : f.listFiles()) {
					if (!f2.isDirectory()) {
						inExpanded.add(f2);
					}
				}

			} else {
				inExpanded.add(f);
			}
		}
		map = new CreateRDFSemanticMap(
				 inExpanded.toArray(new File[inExpanded.size()]));

	}

	/**
	 * Initializes the materializer. It will start to gather information from
	 * the vocabulary files
	 * 
	 * @throws Exception
	 */
	public void initialize() throws Exception {
		map.execute();
	}

	@Override
	public List<IQuint> processQuint(IQuint q) {

		List<IQuint> result = new ArrayList<>();
		if (q.getPredicate().toString().equals(Constants.RDF_TYPE)) {

			List<String> types = new ArrayList<>();

			types.add(q.getObject().toString());
			CreateRDFSemanticMap.materialize(types, map.subclassMap);

			for (String t : types) {
				Resource tr = new Resource(t);
				NodeResource ntr = new NodeResource(tr);

				IQuint qt = new Quad(q.getSubject(), q.getPredicate(), ntr,
						q.getContext());
				result.add(qt);
			}

		} else {
			List<String> preds = new ArrayList<String>();
			preds.add(q.getPredicate().toString());
			CreateRDFSemanticMap.materialize(preds, map.subpropertyMap);

			for (String s : preds) {
				Resource pr = new Resource(s);
				NodeResource npr = new NodeResource(pr);
				IQuint qp = new Quad(q.getSubject(), npr, q.getObject(),
						q.getContext());
				result.add(qp);

			}

		}
		return result;
	}

}
