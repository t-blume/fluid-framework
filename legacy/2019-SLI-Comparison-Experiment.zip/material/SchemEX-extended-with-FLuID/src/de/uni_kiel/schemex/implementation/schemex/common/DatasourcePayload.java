package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.implementation.common.TypedResource;

/**
 * Represents a context, a source where information was seen.
 * 
 * @author Bastian
 *
 */
public class DatasourcePayload implements IPayloadElement {

	private IResource resource;

	public static String RESOURCE_TYPE = "Context";

	/**
	 * Constructor
	 * 
	 * @param resource
	 *            The identifier of the context
	 */
	public DatasourcePayload(IResource resource) {
		this.resource = new TypedResource(resource, RESOURCE_TYPE);
	}

	@Override
	public IResource getLocator() {
		return resource;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof DatasourcePayload))
			return false;

		DatasourcePayload other = (DatasourcePayload) obj;
		return resource.equals(other.resource);
	}

	@Override
	public int hashCode() {
		return resource.hashCode();
	}

	@Override
	public String toString() {
		return resource.toString();
	}

}
