package de.uni_kiel.schemex.common;

/**
 * A representation of a single moment in time.
 * 
 * @author Bastian
 *
 */
public interface ITimestamp {

}
