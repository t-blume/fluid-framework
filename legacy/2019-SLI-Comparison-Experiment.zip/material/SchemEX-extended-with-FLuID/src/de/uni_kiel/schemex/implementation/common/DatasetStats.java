package de.uni_kiel.schemex.implementation.common;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.required.IElementCacheListener;
import de.uni_kiel.schemex.utils.BasicUtils;

import java.io.*;
import java.util.HashSet;
import java.util.LinkedList;

import static de.uni_kiel.schemex.utils.Constants.RDF_TYPE;

public class DatasetStats implements IElementCacheListener<IInstanceElement> {

    private String outFile = "out/dataset-stats.csv";


    public DatasetStats(String outFile) {
        this.outFile = outFile;
    }

    private HashSet<String> uniqueTypes = new HashSet<>();
    private HashSet<String> uniqueProperties = new HashSet<>();
    private HashSet<String> uniqueSources = new HashSet<>();

    private long numberOfVertices = 0L;
    private long numberOfInstances = 0L;
    private long numberOfEdges = 0L;

    private LinkedList<Integer> outgoingPropertiesPerInstance = new LinkedList<>();
    private LinkedList<Integer> incomingPropertiesPerInstance = new LinkedList<>();
    private LinkedList<Integer> typesPerInstance = new LinkedList<>();
    private LinkedList<Integer> sourcesPerInstance = new LinkedList<>();


    @Override
    public void elementFlushed(IInstanceElement instance) {
        numberOfVertices++;
        incomingPropertiesPerInstance.add(instance.getIncomingQuints().size());
        if (instance.getOutgoingQuints().size() > 0) {
            numberOfInstances++;
            numberOfEdges += instance.getOutgoingQuints().size();

            int outgoingProperties = 0;
            int types = 0;
            HashSet<String> sources = new HashSet<>();
            for (IQuint quint : instance.getOutgoingQuints()) {
                if (quint.getPredicate().toString().equals(RDF_TYPE)) {
                    types++;
                    uniqueTypes.add(quint.getObject().toString());
                } else {
                    outgoingProperties++;
                    uniqueProperties.add(quint.getPredicate().toString());
                }
                sources.add(quint.getContext().toString());
                uniqueSources.add(quint.getContext().toString());
            }
            outgoingPropertiesPerInstance.add(outgoingProperties);
            typesPerInstance.add(types);
            sourcesPerInstance.add(sources.size());
        }
    }

    @Override
    public void finished() {
        System.out.println("|V| = " + numberOfVertices);
        System.out.println("|E| = " + numberOfEdges);

        double[] outgoingPropertyStats = BasicUtils.standardStats(outgoingPropertiesPerInstance);
        System.out.println("outgoingProps: avg: " + outgoingPropertyStats[1] + "(SD=" + outgoingPropertyStats[2] + ")");
        double[] incomingPropertyStats = BasicUtils.standardStats(incomingPropertiesPerInstance);
        System.out.println("incomingProps: avg: " + incomingPropertyStats[1] + "(SD=" + incomingPropertyStats[2] + ")");
        double[] typeStats = BasicUtils.standardStats(typesPerInstance);
        System.out.println("types: avg: " + typeStats[1] + "(SD=" + typeStats[2] + ")");
        double[] sourcesStats = BasicUtils.standardStats(sourcesPerInstance);
        System.out.println("sources: avg: " + sourcesStats[1] + "(SD=" + sourcesStats[2] + ")");

        System.out.println("Unique Types: " + uniqueTypes.size());
        System.out.println("Unique Properties: " + uniqueProperties.size());
        System.out.println("Unique Sources: " + uniqueSources.size());


        File out = BasicUtils.createFile(outFile);
        FileOutputStream fos = null;
        System.out.println("Exporting statistics to: " + outFile);
        try {
            fos = new FileOutputStream(out);
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
            bw.write("|V|,|E|,|Instances|," +
                    "Avg. Types,SD Types," +
                    "Avg. Props,SD Props.," +
                    "Avg. Inc. Props,SD Inc. Props.," +
                    "Avg. Sources,SD Sources," +
                    "Unique Types,Unique Props.,Unique Sources\n");
            bw.write(numberOfVertices + "," + numberOfEdges + "," + numberOfInstances + "," +
                    typeStats[1] + "," + typeStats[2] + "," +
                    outgoingPropertyStats[1] + "," + outgoingPropertyStats[2] + "," +
                    incomingPropertyStats[1] + "," + incomingPropertyStats[2] + "," +
                    sourcesStats[1] + "," + sourcesStats[2] + "," +
                    uniqueTypes.size() + "," + uniqueProperties.size() + "," + uniqueSources.size() + "\n");
            bw.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
