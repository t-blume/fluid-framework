package de.uni_kiel.schemex.implementation.provided;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.provided.IQuintPipeline;
import de.uni_kiel.schemex.interfaces.provided.IQuintProcessor;
import de.uni_kiel.schemex.interfaces.required.IQuintListener;
import de.uni_kiel.schemex.interfaces.required.IQuintSourceListener;

/**
 * Basic implementation of a {@link IQuintPipeline} which may get its
 * {@link IQuint}s from sources at which it is registered. Quints will be
 * processed by the internal processors in the order they were added. For all
 * resulting Quints, listeners will be notified
 * 
 * @author Bastian
 *
 */
public class BasicQuintPipeline implements IQuintPipeline, IQuintSourceListener {

	private List<IQuintListener> listeners;
	private List<IQuintProcessor> processors;

	/**
	 * Constructor
	 */
	public BasicQuintPipeline() {
		listeners = new ArrayList<>();
		processors = new ArrayList<>();
	}

	@Override
	public void process(IQuint i) {
		Queue<IQuint> temp = new ArrayDeque<>();
		Queue<IQuint> current = new ArrayDeque<>();
		temp.add(i);
		for (IQuintProcessor p : processors) {
			while (!temp.isEmpty()) {
				IQuint q = temp.poll();
				List<IQuint> list = p.processQuint(q);
				current.addAll(list);
			}

			Queue<IQuint> swap = temp;
			temp = current;
			current = swap;
		}

		for (IQuint q : temp)
			notifyListeners(q);

	}

	private void notifyListeners(IQuint q) {
		for (IQuintListener l : listeners) {
			l.finishedQuint(q);
		}
	}

	@Override
	public void addProcessor(IQuintProcessor p) {
		processors.add(p);
	}

	@Override
	public void removeProcessor(IQuintProcessor p) {
		processors.remove(p);
	}

	@Override
	public List<IQuintProcessor> getPipeline() {
		return processors;
	}

	@Override
	public void registerQuintListener(IQuintListener l) {
		listeners.add(l);
	}

	@Override
	public void pushedQuint(IQuint quint) {
		process(quint);
	}

	@Override
	public void sourceClosed() {
		for (IQuintListener l : listeners) {
			l.finished();
		}

	}

	@Override
	public void sourceStarted() {

	}

}
