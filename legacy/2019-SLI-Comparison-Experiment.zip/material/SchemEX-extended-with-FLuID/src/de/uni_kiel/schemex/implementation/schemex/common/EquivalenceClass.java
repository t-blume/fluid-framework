package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ISchemaElement;

import java.util.HashSet;
import java.util.Set;

/**
 * Schemex equivalence class. Instances are sorted in their equivalence classes
 * according to their TypeCluster and relations, that is properties connecting
 * to other TypeClusters
 *
 * @author Bastian
 */
public class EquivalenceClass implements ISchemaElement {

    private Set<Link> linkSet;
    private IResource tc;
    private EquivalenceClassResource resource;
    private Set<IPayloadElement> payloadElements = new HashSet<>();

    /**
     * Constructor
     *
     * @param tc The typecluster
     */
    public EquivalenceClass(Set<Link> linkSet, IResource tc) {
        this.linkSet = linkSet;
        this.tc = tc;
        resource = new EquivalenceClassResource(linkSet, tc);
    }

    public IResource getTCResource() {
        return tc;
    }

    public Set<IPayloadElement> getPayloadElements() {
        return payloadElements;
    }

    @Override
    public IResource getLocator() {
        return resource;
    }

    @Override
    public String toString() {
        return resource.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof EquivalenceClass))
            return false;

        return resource.equals(((EquivalenceClass) obj).resource);
    }

    @Override
    public int hashCode() {
        return resource.hashCode();
    }

    /**
     * Getter for the sets of links contained in the equivalence class
     *
     * @return The linkset
     */
    public Set<Link> getLinkSet() {
        return linkSet;
    }


    @Override
    public void addPayload(IPayloadElement payloadElement) {
        this.payloadElements.add(payloadElement);
    }

    @Override
    public ISchemaElement clone() {
        EquivalenceClass clone = new EquivalenceClass(linkSet, tc);
        payloadElements.forEach(PAY -> clone.addPayload(PAY));
        return clone;
    }


}
