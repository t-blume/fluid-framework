package de.uni_kiel.schemex.common;

/**
 * Created by Blume Till on 27.04.2017.
 */
public interface IPayloadElement extends ILocatable {

}
