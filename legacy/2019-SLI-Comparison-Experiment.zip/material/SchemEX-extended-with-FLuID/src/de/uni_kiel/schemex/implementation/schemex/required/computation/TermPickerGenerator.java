package de.uni_kiel.schemex.implementation.schemex.required.computation;

import de.uni_kiel.schemex.common.*;
import de.uni_kiel.schemex.implementation.common.*;
import zbw.cau.gotham.schema.SchemaGraphInferencing;
import de.uni_kiel.schemex.implementation.schemex.common.*;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;
import org.semanticweb.yars.nx.Literal;
import org.semanticweb.yars.nx.Node;
import org.semanticweb.yars.nx.Resource;

import java.util.*;


/**
 * Created by Blume Till on 20.09.2016.
 */
public class TermPickerGenerator implements ISchemaGenerator {

    ////////////////////////////////////////////
    ////////////////    debug   ////////////////
    public int unresolvedLiteralCluster = 0;
    public int outgoingLinks = 0;
    public int updates = 0;
    protected Map<TypeCluster, Boolean> foundLiteralTypes;
    protected Boolean regardIncomingProperties = false;
    ////////////////////////////////////////////
    ////////////////    config  ////////////////
    protected final int bisimulationDepth;
    protected final String typesClassifier;
    protected IResource schemaElementResource;
    protected SchemaGraphInferencing schemaGraph = null;
    ////////////////////////////////////////////
    ////////////////    caches  ////////////////
    protected IElementCache<IInstanceElement> instanceCache;
    protected IElementCache<BackwardInstance> backwardCache;


    public TermPickerGenerator(int bisimulationDepth, String typesClassifier, IElementCache<IInstanceElement> instanceCache,
                               IElementCache<BackwardInstance> backwardCache) {
        this.bisimulationDepth = bisimulationDepth;
        this.typesClassifier = typesClassifier;
        this.instanceCache = instanceCache;
        this.backwardCache = backwardCache;


        foundLiteralTypes = new HashMap<>();
        for (Map.Entry<Resource, TypeCluster> e : TypeCluster.DATATYPE_MAP.entrySet())
            foundLiteralTypes.put(e.getValue(), false);

    }

    public TermPickerGenerator(int bisimulationDepth, String typesClassifier, IElementCache<IInstanceElement> instanceCache,
                               IElementCache<BackwardInstance> backwardCache, Boolean useIncomingProperties) {
        this.bisimulationDepth = bisimulationDepth;
        this.typesClassifier = typesClassifier;
        this.instanceCache = instanceCache;
        this.backwardCache = backwardCache;
        this.regardIncomingProperties = useIncomingProperties;


        foundLiteralTypes = new HashMap<>();
        for (Map.Entry<Resource, TypeCluster> e : TypeCluster.DATATYPE_MAP.entrySet())
            foundLiteralTypes.put(e.getValue(), false);

    }

    public void registerSchemaGraph(SchemaGraphInferencing schemaGraph) {
        this.schemaGraph = schemaGraph;
    }

    @Override
    public void enableLogging(String filepath, String name) {
        //TODO: DEBUGGER
    }

    @Override
    public Set<ISchemaElement> createSchemaIndex(IInstanceElement instance, IRelationsCache schemaCache) {
        Set<ISchemaElement> schemaElements = new HashSet<>();

        //add additional properties based on Schema Graph
        instance = inferProperties(instance);

        Set<String> types;
        if (schemaGraph != null)
            types = schemaGraph.inferSubjectTypes(instance);
        else
            types = getTypes(instance);

        ISchemaElement tc = new TypeCluster(types);

        boolean SC_TC_Miss = !schemaCache.contains(tc.getLocator());
        if (SC_TC_Miss)
            schemaElements.add(tc);

//        //see if TC can be resolved now
        IResource unresolvedTC = new TypeClusterResourceUnresolved(instance.getLocator());
        //fake create unresolved TC Resource to check if it is in SC
        if (schemaCache.contains(unresolvedTC)) {
            //found previous unresolved TC, link it to the newly created (should only be one)
            updates++;
            schemaCache.add(new SimpleRelation(unresolvedTC, tc.getLocator()));
        }

        BackwardInstance back = new BackwardInstance(instance.getLocator(), tc.getLocator());
        backwardCache.add(back);

        Set<Link> linkSet = new TreeSet<>();//0-bisim use empty linkset
        if (bisimulationDepth > 0)
            linkSet = createLinkSet(instance, 1, schemaCache);

        //create EQC
        ISchemaElement schemaElement = new EquivalenceClass(linkSet, tc.getLocator());
        schemaElementResource = schemaElement.getLocator();

        // add to output elements
        boolean SC_EQC_Miss = !schemaCache.contains(schemaElement.getLocator());
        if (SC_EQC_Miss)
            schemaElements.add(schemaElement);

        //add simple relation
        schemaCache.add(new SimpleRelation(tc.getLocator(), schemaElement.getLocator()));


        for (Link l : linkSet) {
            IRelation relation = new NamedRelation(schemaElement.getLocator(), l.getObject(), l.getProperty().toN3());
            schemaCache.add(relation);
        }

        //return all elements
        return schemaElements;
    }

    @Override
    public IResource getSchemaElementLocator() {
        return schemaElementResource;
    }

    @Override
    public void finished() {
        System.out.println("unresolvedLiteralCluster: " + unresolvedLiteralCluster);
        System.out.println("outgoingLinks: " + outgoingLinks);
        System.out.println("Updates: " + updates);
    }

    protected Set<Link> createLinkSet(IInstanceElement instance, int currentDepth, IRelationsCache schemaCache) {
        if (instance == null)
            return null;
        if (currentDepth < 0 || currentDepth > bisimulationDepth)
            System.err.println("[BisimError] bisim depth: " + bisimulationDepth + ", current depth: " + currentDepth);
//        else {
//            System.out.println(instance.getLocator() + "(Depth: " + currentDepth
//                    + ")" + " outgoingProps: " + instance.getOutgoingQuints().size() + ", " + "incomingProps: " + instance.getIncomingQuints().size());
//        }


        Set<Link> linkSet = new TreeSet<>();
        Set<IQuint> allQuints = instance.getOutgoingQuints();
        allQuints.addAll(instance.getIncomingQuints());

        //termpicker does not care about which types are connected to which property
        // -> add all connected types of all properties to each property

        Set<String> allObjectTypes = new HashSet<>();
        for (IQuint quint : allQuints) {
            IResource targetInstanceLocator = new TypedResource(quint.getObject(),
                    RDFInstance.RESOURCE_TYPE);

            IInstanceElement targetInstance;
            if ((targetInstance = instanceCache.get(targetInstanceLocator)) != null) {
                targetInstance = inferProperties(targetInstance);
                allObjectTypes.addAll(getTypes(targetInstance));
            }

            //infer types based on property
            if (schemaGraph != null)
                allObjectTypes.addAll(schemaGraph.inferObjectTypes(quint));
        }
        //for each quint, create a link (a link represents a path of bisim length)
        for (IQuint quint : allQuints) {
            Link l = createLink(quint, currentDepth, schemaCache, allObjectTypes);
            if (l != null)
                linkSet.add(l);
        }
        return linkSet;
    }


    protected Link createLink(IQuint quint, int currentDepth, IRelationsCache schemaCache,
                              Set<String> allObjectTypes) {
        // only check non type predicates (without TC, nothing equals null)
        if (quint.getPredicate().toString().equals(typesClassifier))
            return null;

        //define object TypeCluster
        IResource object = quint.getObject();
        IResource targetInstanceLocator = new TypedResource(quint.getObject(),
                RDFInstance.RESOURCE_TYPE);
        TypeCluster objTC = new TypeCluster(allObjectTypes);
        if (object instanceof NodeResource) {
            NodeResource nr = (NodeResource) object;
            if (!(nr.getNode() instanceof Literal)) {
                if (backwardCache.contains(targetInstanceLocator)) {
                    BackwardInstance backwardTargetInstance = backwardCache.get(targetInstanceLocator);
                    if (currentDepth < bisimulationDepth) {
                        IResource targetEQC;
                        if ((targetEQC = backwardTargetInstance.getTentativeEquivalanceClassResources().get(currentDepth)) != null) {
                            //found previously computed smaller EQC
                            return new Link(quint.getPredicate(), targetEQC);
                        }
                    } else
                        return new Link(quint.getPredicate(), backwardTargetInstance.getTypeClusterResource());
                }

                if (instanceCache.contains(targetInstanceLocator)) {
                    IInstanceElement targetInstance = instanceCache.get(targetInstanceLocator);

                    //we have instance information about target, create EQC if depth is not reached
                    if (currentDepth < bisimulationDepth) {
                        Set<Link> targetLinkSet = createLinkSet(targetInstance, currentDepth + 1, schemaCache);
                        ISchemaElement target = new EquivalenceClass(targetLinkSet, objTC.getLocator());

                        BackwardInstance updateTargetBack;
                        if (backwardCache.contains(targetInstanceLocator))
                            updateTargetBack = backwardCache.get(targetInstanceLocator);
                        else {
                            updateTargetBack = new BackwardInstance(targetInstanceLocator, objTC.getLocator());
                            backwardCache.add(updateTargetBack);
                        }
                        updateTargetBack.addTentativeEquivalenceClassResource(1, target.getLocator());

                        //create linkSet with ECQ as target instead of TC
                        return new Link(quint.getPredicate(), target.getLocator());
                    } else
                        return new Link(quint.getPredicate(), objTC.getLocator());

                } else {
                    return new Link(quint.getPredicate(), objTC.getLocator());
                }
            }
        }

        //TODO: TypeClusterPredictor
        //objectCluster = predictor.predictObjectCluster(quint, objectCluster);
        return new Link(quint.getPredicate(), objTC.getLocator());
    }


    ////////////////////////////////////////////
    ////////////////    HELPER  ////////////////
    ////////////////////////////////////////////
    protected Set<String> getTypes(IInstanceElement instance) {
        if (typesClassifier != null) {
            Set<String> types = new TreeSet<>();
            for (IQuint q : instance.getOutgoingQuints()) {
                if (q.getPredicate().toString().equals(typesClassifier)) {
                    try {
                        types.add(q.getObject().toString());
                    } catch (Exception e) {
                        System.out.println("Error in type for: " + instance.getLocator().toString());
                    }
                }
            }
            return types;
        } else
            return new TreeSet<>(); //empty TypeCluster
    }


    /**
     * Determines the literal type of the given node
     *
     * @param node RDF node
     * @return literal type
     */

    protected TypeCluster determineLiteral(Node node) {
        if (node instanceof Literal) {
            Literal l = (Literal) node;
            Resource r = l.getDatatype();
            return TypeCluster.DATATYPE_MAP.get(r);
        }
        return null;
    }

    private IInstanceElement inferProperties(IInstanceElement instance) {
        IInstanceElement newInstance = instance.clone();
        if (schemaGraph != null) {
            HashMap<String, Set<String>> inferredProperties = schemaGraph.inferProperties(instance);
            if (inferredProperties != null) {
                for (Map.Entry<String, Set<String>> infProps : inferredProperties.entrySet()) {
                    IResource object = null;
                    IResource context = null;
                    for (IQuint instanceQuint : newInstance.getOutgoingQuints()) {
                        if (instanceQuint.getPredicate().toString().equals(infProps.getKey())) {
                            object = instanceQuint.getObject();
                            context = instanceQuint.getContext();
                            break;
                        }
                    }

                    if (object == null)
                        System.err.println("Could not find original statement!!");
                    for (String infProp : infProps.getValue())
                        newInstance.addOutgoingQuint(new Quad(instance.getLocator(), new NodeResource(new Resource(infProp)), object, context));

                }
            }
        }
        return newInstance;
    }
}