package de.uni_kiel.schemex.implementation.schemex.required.connectors;

import de.uni_kiel.schemex.interfaces.required.IConnector;

/**
 * Created by Blume Till on 26.08.2016.
 */

public class Connection {

    //Function Interface magic
    @FunctionalInterface
    public interface DBConnection {
        IConnector getConnector(String url, String id);
    }

    public static IConnector getSesameConnector(String url, String id) {
        return new SesameConnector(url, id);
    }

    public static IConnector getRDF4JConnector(String url, String id) {
        return new RDF4JConnector(url, id);
    }

}