package de.uni_kiel.schemex.implementation.required;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.implementation.common.NodeResource;
import de.uni_kiel.schemex.implementation.common.Quad;
import de.uni_kiel.schemex.interfaces.provided.IQuintProcessor;
import org.semanticweb.yars.nx.Resource;

import java.util.ArrayList;
import java.util.List;

/**
 * Deanonymizes quads. Blank nodes will be dereferenced by using the given
 * context information, if no context is given or the context itself is a blank
 * node, a given prefix is used
 *
 * @author Bastian
 */
public class DeAnonymizer implements IQuintProcessor {

    private String prefix;

    /**
     * Creates a DeAnonymizer with the given prefix, which will be used in the
     * case of no usable context information
     *
     * @param prefix The prefix to be used as context if none is available
     */
    public DeAnonymizer(String prefix) {
        this.prefix = prefix;
    }

    private IResource deanon(IResource r, IResource context) {
        String s = r.toString();

        if (!s.matches("(http(s)?|(ftp)):\\/\\/.*")) {
            String c;
            if (context != null) {
                c = context.toString();
                // In case the context itself was a blank node -> use prefix
                if (c.startsWith("_:"))
                    c = prefix;

            } else {
                c = prefix;
            }

            if (!(c.endsWith("/") || c.endsWith("#")))
                c = c + "/";

            s = s.replaceAll("_:", "");

            return new NodeResource(new Resource(c + s));
        } else
            return r;

    }

    @Override
    public List<IQuint> processQuint(IQuint q) {
        List<IQuint> l = new ArrayList<>();
        try {
            IResource s = deanon(q.getSubject(), q.getContext());
            IResource o = deanon(q.getObject(), q.getContext());
            IResource c = deanon(q.getContext(), q.getContext());
            IQuint qn = new Quad(s, q.getPredicate(), o, c);
            l.add(qn);
        } catch (Exception e) {
            e.printStackTrace();
            return l;
        }
        return l;
    }
}
