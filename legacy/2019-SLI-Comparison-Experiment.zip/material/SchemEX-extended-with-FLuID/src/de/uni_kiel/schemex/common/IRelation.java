package de.uni_kiel.schemex.common;

/**
 * Models a relation between two {@link ISchemaElement}s.
 * 
 * @author Bastian
 * 
 */
public interface IRelation {

	/**
	 * Returns the source of the relation
	 *
	 * @return The relation's source
	 */
	IResource getSource();

	void setSource(IResource resource);

	/**
	 * Returns the target of the relation
	 * 
	 * @return The relation's target
	 */
	IResource getTarget();
}
