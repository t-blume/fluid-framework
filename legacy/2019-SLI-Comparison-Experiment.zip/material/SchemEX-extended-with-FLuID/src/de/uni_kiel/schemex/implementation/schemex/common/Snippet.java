package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.implementation.common.StringResource;

/**
 * A snippet containing descriptions of elements
 * 
 * @author Bastian
 *
 */
public class Snippet implements IPayloadElement {

	private String snippet;

	private IResource res;

	private IResource describedResource;

	/**
	 * Constructor
	 *
	 * @param snippet  The description
	 * @param resource The resource
	 */
	public Snippet(String snippet, IResource resource) {
		this.snippet = snippet;
		res = new StringResource(snippet);
		describedResource = resource;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Snippet))
			return false;

		Snippet other = (Snippet) obj;
		return snippet.equals(other.snippet);
	}

	/**
	 * Getter for the resource
	 *
	 * @return The resource
	 */
	public IResource getDescribedResource() {
		return describedResource;
	}

	@Override
	public int hashCode() {
		return snippet.hashCode();
	}

	@Override
	public String toString() {
		return snippet;
	}

	@Override
	public IResource getLocator() {
		return res;
	}

}
