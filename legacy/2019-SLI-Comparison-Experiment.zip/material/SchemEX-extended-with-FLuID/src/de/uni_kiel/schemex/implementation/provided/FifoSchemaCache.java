package de.uni_kiel.schemex.implementation.provided;

import de.uni_kiel.schemex.common.IRelation;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;
import de.uni_kiel.schemex.interfaces.required.IRelationListener;

import java.util.*;

/**
 * A first-in-first-out (FIFO) cache implementation for schema elements. Objects
 * are stored as long as the internal capacity is not exhausted. At that point,
 * the earliest added entry will be removed to clear some space for the new
 * entry. If the cache is closed, all not yet removed entries will be removed
 * and listeners will be informed of the closing. Each removed entry will be
 * given to the registered listeners. Entries contain both the elements and
 * relations they have with other elements
 * 
 * @author Bastian
 *
 */
public class FifoSchemaCache implements IRelationsCache {

	private Map<IResource, Set<IRelation>> elements;
	private Queue<IResource> queue;

	private List<IRelationListener> listeners;
	private int capacity;
	boolean closed;

	// FIXME int might be too small, Queue only allows int as size
	private int maxSize = 0;	

	/**
	 * Constructor. Creates a cache with the highest integer as capacity
	 */
	public FifoSchemaCache() {
		this(Integer.MAX_VALUE);
	}

	/**
	 * Constructor. Creates a cache with the given capacity
	 * 
	 * @param capacity
	 *            The capacity
	 */
	public FifoSchemaCache(int capacity) {
		this.capacity = capacity;
		elements = new HashMap<>();
		queue = new ArrayDeque<>();
		listeners = new ArrayList<>();
		
		closed = false;
	}

	@Override
	public Set<IRelation> getRelations(IResource element) {
		return elements.get(element);
	}

	@Override
	public int size() {
		return queue.size();
	}

	@Override
	public void add(IRelation rel) {
		IResource r = rel.getSource();
		Set<IRelation> c = elements.get(r);
		if (c == null) {
			int currentSize = size();
			maxSize = Math.max(maxSize, currentSize);
			if (capacity == Integer.MAX_VALUE && currentSize % 1000 == 0)
				System.out.format("\t\t\t\t\t\t\t\t\t\t\tSC: %08d / %08d\r", currentSize, maxSize);
			
			if (currentSize == capacity) {
				if (capacity == Integer.MAX_VALUE) {
					System.out.format("\nSchema Cache limit %08d reached - Gold standard failed !\n", maxSize);
					System.exit(-1);
				}
				removeLast();
			}
			c = new HashSet<>();
			elements.put(r, c);
			queue.add(r);
		}
		c.add(rel);


	}

	@Override
	public void remove(IRelation rel) {
		Set<IRelation> relations = elements.get(rel.getSource());
		if(relations == null || relations.isEmpty())
			return;

		if(relations.remove(rel)){
			//TODO: Update queue if empty
		}
	}

	@Override
	public void flush() {
		while (size() != 0) {
			removeLast();
		}
	}

	private void notifyListeners(IResource r, Set<IRelation> c) {
		for (IRelationListener l : listeners)
			l.schemaElementFlushed(r, c, this);
	}

	private void removeLast() {
		IResource remove = queue.poll();
		Set<IRelation> removeElement = elements.remove(remove);
		
		int currentSize = size();
		maxSize = Math.max(maxSize, currentSize);
		if (capacity == Integer.MAX_VALUE && maxSize % 1000 == 0)
			System.out.format("\t\t\t\t\t\t\t\t\t\t\tSC: %08d / %08d\r", currentSize, maxSize);

		notifyListeners(remove, removeElement);
	}

	@Override
	public void registerCacheListener(IRelationListener listener) {
		listeners.add(listener);
	}

	@Override
	public boolean contains(IResource locator) {
		return elements.containsKey(locator);
	}

	@Override
	public void close() {
		flush();
		closed = true;
		for (IRelationListener l : listeners)
			l.finished(this);
	}

	@Override
	public boolean isClosed() {
		return closed;
	}

	@Override
	public void add(IResource r) {
		Set<IRelation> c = elements.get(r);
		if (c == null) {
			int currentSize = size();
			maxSize = Math.max(maxSize, currentSize);
			if (capacity > 1000000 && maxSize % 1000 == 0)
				System.out.format("\t\t\t\t\t\t\t\t\t\t\tCache %08d / %08d\r", currentSize, maxSize);

			if (size() == capacity) {
				if (capacity > 1000000)
					System.out.format("\t\t\t\t\t\t\t\t\t\t\tCache limit %08d reached - Gold standard failed !\n", maxSize);

				removeLast();
			}
			c = new HashSet<>();
			elements.put(r, c);
			queue.add(r);
		}
	}
}
