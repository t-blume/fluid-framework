package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.utils.Hash;
import org.semanticweb.yars.nx.BNode;

import java.util.Set;

/**
 * A resource for typeclusters. It generates an ID using a md5 hashed hashcode
 * of the set of types.
 *
 * @author Bastian
 */
public class TypeClusterResource implements IResource {
    /**
     * Special typecluster for non-resolved types
     */
    public static TypeClusterResource TC_NOT_RESOLVED_LITERAL;

    static {
        TC_NOT_RESOLVED_LITERAL = new TypeClusterResource(null);
        TC_NOT_RESOLVED_LITERAL.md5 = Hash.md5("NotResolvableLiteral");
    }

    private String md5;
    private int hash;

    /**
     * Constructor
     *
     * @param types The set of types
     */
    public TypeClusterResource(Set<String> types) {
        if (types == null) {
            md5 = Hash.md5(Integer.toString(0));
            hash = 0;
        } else {
            md5 = Hash.md5(Integer.toString(types.hashCode()));
            hash = types.hashCode();
        }
    }

    public TypeClusterResource(String md5, int hash) {
        this.md5 = md5;
        this.hash = hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof TypeClusterResource)) {
            return false;
        }

        TypeClusterResource r = (TypeClusterResource) obj;

        return md5.equals(r.md5);
    }

    @Override
    public int hashCode() {
        return hash;
    }

    @Override
    public String toString() {
        return md5;
    }

    @Override
    public String toN3() {
        return (new BNode(md5)).toN3();
    }
}
