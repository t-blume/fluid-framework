/**
 * This package contains classes used for materializing types and properties
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.implementation.required.materialize;