package de.uni_kiel.schemex.implementation.schemex.common;

import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ISchemaElement;
import de.uni_kiel.schemex.implementation.common.NodeResource;
import org.semanticweb.yars.nx.Resource;

import java.util.Set;

/**
 * A representation of a link. A link is a property connecting one resource to
 * another one. It is specified in N-Quad/N-Triple notation by the predicate and
 * object
 *
 * @author Bastian
 * @editor Till
 */
public class Link implements Comparable<Link>, ISchemaElement {

    private IResource property;
    private IResource object;
    private IResource locator;

    /**
     * Constructor
     *
     * @param property The property (or predicate)
     * @param object   The object
     */
    public Link(IResource property, IResource object) {
        this.property = property;
        this.object = object;
        this.locator = new NodeResource(new Resource(property.toString() + object.toString()));
    }

    /**
     * Getter for the property
     *
     * @return The property
     */
    public IResource getProperty() {
        return property;
    }

    /**
     * Getter for the object
     *
     * @return The object
     */
    public IResource getObject() {
        return object;
    }

    public IResource getLocator() {
        return locator;
    }

    @Override
    public int hashCode() {
        //@editor: Till
        //Do not use Unresolved TC URI for hashing of EQCs, instead use dummy
        if (object instanceof TypeClusterResourceUnresolved)
            return (property.toString() + TypeClusterResourceUnresolved.TC_NOT_RESOLVED_DUMMY).hashCode();
        else
            return (property.toString() + object.toString()).hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        //@editor: Till
        //Do not use Unresolved TC for equals
        if (!(obj instanceof Link)) {
            return false;
        }

        Link other = (Link) obj;
        return hashCode() == other.hashCode();
    }

    @Override
    public String toString() {
        //@editor: Till
        if (object instanceof TypeClusterResourceUnresolved)
            return property.toString() + TypeClusterResourceUnresolved.TC_NOT_RESOLVED_DUMMY;
        else
            return property.toString() + object.toString();
    }

    @Override
    public int compareTo(Link o) {
        return toString().compareTo(o.toString());
    }

    @Override
    public void addPayload(IPayloadElement payloadElement) {

    }

    @Override
    public Set<IPayloadElement> getPayloadElements() {
        return null;
    }

    @Override
    public ISchemaElement clone() {
        return new Link(property, object);
    }
}
