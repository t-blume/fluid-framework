package de.uni_kiel.schemex.implementation.provided;


import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.implementation.common.NodeResource;
import de.uni_kiel.schemex.implementation.common.Quad;
import de.uni_kiel.schemex.interfaces.provided.IQuintSource;
import de.uni_kiel.schemex.interfaces.required.IQuintSourceListener;
import org.semanticweb.yars.nx.Node;
import org.semanticweb.yars.nx.Resource;
import org.semanticweb.yars.nx.parser.NxParser;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * A {@link IQuintSource} reading quads in the N-Triple or N-Quad format from
 * files
 *
 * @author Bastian
 *
 */
public class FileQuadSource implements IQuintSource {

	private List<IQuintSourceListener> listeners;

	private List<Path> filePaths;

	private NodeResource defaultContext;

	private FileFilter fileFilter;
	/**
	 * Constructor
	 *
	 * @param filePaths
	 *            Paths containing the input files. May be either files or
	 *            directories
	 * @param recursive
	 *            If true, subdirectories will be included as well, otherwise
	 *            not
	 * @param defaultContext
	 *            Context to be inserted if no context was given for an instance
	 */
	public FileQuadSource(List<String> filePaths, boolean recursive,
						  String defaultContext, FileFilter... fileFilters) {
		listeners = new ArrayList<>();
		this.defaultContext = new NodeResource(new Resource(defaultContext));
		this.filePaths = new ArrayList<>();
		for (String s : filePaths) {
			Path path = Paths.get(s).toAbsolutePath();
			//System.out.println("P: " + path.toString());
			// Continue if given path is nonexistant
			if (!Files.exists(path)) {
				System.out.println("Skipping non-existent file: " + path);
				continue;
			}

			// In case of a given directory -> check insides but disregards
			// following folders
			if (Files.isDirectory(path)) {
				traverseDirectory(path, recursive, this.filePaths);

			} else if (Files.isRegularFile(path)) {
				this.filePaths.add(path);
			}
		}
		if(fileFilters != null && fileFilters.length > 0)
			fileFilter = fileFilters[0];
	}

	private void traverseDirectory(Path dir, boolean recursive, List<Path> paths) {
		Queue<Path> q = new ArrayDeque<>();
		q.add(dir);
		while (!q.isEmpty()) {
			Path element = q.poll();
			try {
				DirectoryStream<Path> d = Files.newDirectoryStream(element);
				for (Path p : d) {
					if (Files.isRegularFile(p)) {
						paths.add(p);
					} else if (Files.isDirectory(p)) {
						if (recursive) {
							q.add(p);
						}
					}
				}
			} catch (IOException e) {
			}
		}

	}

	@Override
	public void close() {
		for (IQuintSourceListener i : listeners) {
			i.sourceClosed();
		}
	}

	@Override
	public void start() {
		if(fileFilter != null){
			List<Path> filteredPaths = new LinkedList<>();
			filePaths.forEach(FPath -> {
				System.out.println(FPath);
				if(fileFilter.accept(FPath.toFile()))
					filteredPaths.add(FPath);
			});
			filePaths = filteredPaths;
		}

		for (IQuintSourceListener i : listeners)
			i.sourceStarted();


		Iterator<Path> paths = filePaths.iterator();

		while (paths.hasNext()) {
			Path p = paths.next();
			System.out.println("Processing: " + p.toString());
			try {
				InputStream in = Files.newInputStream(p);

				if (p.toString().endsWith(".zip")) {
					ZipInputStream zin = new ZipInputStream(in);
					ZipEntry entry;
					while ((entry = zin.getNextEntry()) != null) {
						NxParser parser = new NxParser(new BufferedInputStream(zin));
						iterateParser(parser);
					}
				} else {
					if (p.toString().endsWith(".gz")) {
						in = new GZIPInputStream(in);

					}
					NxParser parser = new NxParser(new BufferedInputStream(in));
					iterateParser(parser);
				}
				// Close stream
				in.close();
			} catch (IOException e) {
				continue;
			}
		}

		for (IQuintSourceListener l : listeners) {
			l.sourceClosed();
		}
	}

	private void iterateParser(NxParser parser) {
		while (parser.hasNext()) {
			Node[] nodes = parser.next();
			if (nodes.length < 3)
				continue;


			// get nodes
			Node subject = nodes[0];
			Node predicate = nodes[1];
			Node object = nodes[2];

			IQuint quint = null;

			// Check whether context was present
			if (nodes.length == 3) {
				quint = new Quad(new NodeResource(subject), new NodeResource(
						predicate), new NodeResource(object), defaultContext);
			} else if (nodes.length == 4) {
				Node context = nodes[3];
				quint = new Quad(new NodeResource(subject), new NodeResource(
						predicate), new NodeResource(object), new NodeResource(
						context));

			}

			// If something happened, continue
			if (quint == null)
				continue;

			// Notify listeners
			for (IQuintSourceListener l : listeners)
				l.pushedQuint(quint);

		}

	}

	@Override
	public void registerQuintListener(IQuintSourceListener listener) {
		listeners.add(listener);
	}

	@Override
	public void removeQuintListener(IQuintSourceListener listener) {
		listeners.remove(listener);
	}

}
