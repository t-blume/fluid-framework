package de.uni_kiel.schemex.implementation.common;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.implementation.schemex.required.writer.sinks.FileQuadSink;
import de.uni_kiel.schemex.interfaces.provided.IQuintSink;
import de.uni_kiel.schemex.interfaces.required.IQuintSourceListener;
import de.uni_kiel.schemex.utils.BasicUtils;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.zip.GZIPOutputStream;

public class PLDFilter implements IQuintSourceListener {

    private int counter = 0;
    private String outFile;
    private IQuintSink sink;
    private Set<String> paylevelDomains;

    public PLDFilter(Set<String> contexts) throws IOException {
        this("out/filtered.nt.gz", contexts);
    }
    public PLDFilter(String outFile, Set<String> contexts) throws IOException {
        paylevelDomains = new HashSet<>();
        contexts.forEach(C -> {
            try {
                paylevelDomains.add(new URI(C).getHost());
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
        });
        this.outFile = outFile;
        BasicUtils.createFile(outFile);
        this.sink = new FileQuadSink( new PrintStream(new BufferedOutputStream(
                new GZIPOutputStream(new FileOutputStream(outFile)))), false);
    }
    @Override
    public void pushedQuint(IQuint quint) {
        try {
            if (paylevelDomains.contains(new URI(quint.getContext().toString()).getHost()))
                sink.print(quint.getSubject().toN3(), quint.getPredicate().toN3(), quint.getObject().toN3(), quint.getContext().toN3());
            else
                counter++;

        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void sourceClosed() {
        System.out.println("Exporting "+counter+" quads to: " + outFile);

    }

    @Override
    public void sourceStarted() {
        System.out.println("Tracking Properties.. ");
    }
}
