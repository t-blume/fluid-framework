package de.uni_kiel.schemex.common;

import java.util.Set;

/**
 * Models an element of a schema.
 */
public interface ISchemaElement extends ILocatable {

    void addPayload(IPayloadElement payloadElement);

    Set<IPayloadElement> getPayloadElements();
}
