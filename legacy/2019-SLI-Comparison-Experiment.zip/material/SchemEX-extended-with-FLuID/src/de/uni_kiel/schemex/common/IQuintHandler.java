package de.uni_kiel.schemex.common;

public interface IQuintHandler {

        void handle(IQuint quint);

}
