package de.uni_kiel.schemex.implementation.common;


import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.common.IResource;

import java.util.HashSet;
import java.util.Set;

/**
 * An instance which encapsulates a multitude of statements made about it
 * property cliques
 *
 * @author Blume Till
 */
public class TransInstance extends RDFInstance {



//    private Set<IResource> srcPropertyRelatedInstances;
//    private Set<IResource> trgPropertyRelatedInstances;

    public TransInstance(IResource locator) {
        super(locator);
//        srcPropertyRelatedInstances = new HashSet<>();
//        trgPropertyRelatedInstances = new HashSet<>();
    }

    @Override
    public void addOutgoingQuint(IQuint q) {
        super.addOutgoingQuint(q);
    }

    @Override
    public void addIncomingQuint(IQuint q) {
        super.addIncomingQuint(q);
    }

    @Override
    public IInstanceElement clone() {
        TransInstance element = new TransInstance(getLocator());
        for (IQuint quint : getOutgoingQuints())
            element.addOutgoingQuint(quint);
        for (IQuint quint : getIncomingQuints())
            element.addIncomingQuint(quint);
//        for (IResource resource : srcPropertyRelatedInstances)
//            element.addSrcPropertyRelatedInstances(resource);
//        for (IResource resource : trgPropertyRelatedInstances)
//            element.addTrgPropertyRelatedInstances(resource);
        return element;
    }



//    @Override
//    public String toString() {
//        return super.toString() + " srcPropertyRelatedInstances: " + srcPropertyRelatedInstances.size() +
//                " trgPropertyRelatedInstances: " + trgPropertyRelatedInstances.size();
//    }
//
//    public Set<IResource> getSrcPropertyRelatedInstances() {
//        return srcPropertyRelatedInstances;
//    }
//
//    public void addSrcPropertyRelatedInstances(IResource srcPropertyRelatedInstance) {
//        this.srcPropertyRelatedInstances.add(srcPropertyRelatedInstance);
//    }
//
//    public void addAllSrcPropertyRelatedInstances(Set<IResource> srcPropertyRelatedInstances) {
//        this.srcPropertyRelatedInstances.addAll(srcPropertyRelatedInstances);
//    }
//
//    public Set<IResource> getTrgPropertyRelatedInstances() {
//        return trgPropertyRelatedInstances;
//    }
//
//    public void addTrgPropertyRelatedInstances(IResource trgPropertyRelatedInstance) {
//        this.trgPropertyRelatedInstances.add(trgPropertyRelatedInstance);
//    }
//
//    public void addAllTrgPropertyRelatedInstances(Set<IResource> trgPropertyRelatedInstances) {
//        this.trgPropertyRelatedInstances.addAll(trgPropertyRelatedInstances);
//    }
}
