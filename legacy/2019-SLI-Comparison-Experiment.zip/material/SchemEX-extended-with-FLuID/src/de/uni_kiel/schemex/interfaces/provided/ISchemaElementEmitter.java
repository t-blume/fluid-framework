package de.uni_kiel.schemex.interfaces.provided;

import de.uni_kiel.schemex.interfaces.required.ISchemaElementListener;

/**
 * Interface for objects that can emit schema elements
 * 
 * @author Bastian
 *
 */
public interface ISchemaElementEmitter {

	/**
	 * Registers a listener for the emitted schema elements
	 * 
	 * @param l
	 *            The listener to be registered
	 */
	public void registerSchemaElementListener(ISchemaElementListener l);
}
