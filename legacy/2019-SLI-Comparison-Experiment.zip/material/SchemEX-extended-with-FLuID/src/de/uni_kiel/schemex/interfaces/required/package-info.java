/**
 * This package contains required interfaces for processing data. The interfaces describe listeners and processors 
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.interfaces.required;