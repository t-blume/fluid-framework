package de.uni_kiel.schemex.interfaces.provided;

import java.util.Set;

import de.uni_kiel.schemex.common.IRelation;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ISchemaElement;
import org.openrdf.repository.RepositoryException;

import de.uni_kiel.schemex.interfaces.required.IRelationListener;

/**
 * A cache used for schema data. The cache should model some kind of graph. The
 * graph's vertices are {@link ISchemaElement}s. Edges between vertices are
 * represented by {@link IRelation}s.
 * 
 * @author Bastian
 * 
 */
public interface IRelationsCache {


	/**
	 * Checks whether an element specified by its {@link IResource} locator is
	 * contained in the cache
	 * 
	 * @param locator
	 *            The locator of the element
	 * @return <code>true</code>, if the element is contained in the cache,
	 *         <code>false</code> otherwise
	 */
	boolean contains(IResource locator);


	/**
	 * Returns a set of all relations attached to a given element of the schema
	 * 
	 * @param element
	 *            The element which's relations should be queried
	 * @return A set containing the relations between elements
	 */
	Set<IRelation> getRelations(IResource element);

	/**
	 * Returns the number of elements contained in the cache
	 * 
	 * @return The number of elements
	 */
	int size();

	/**
	 * Adds a new relation to the schema. The method is expected to add the
	 * relation as an edge to the relation's source, such that it is part of the
	 * relations returned by the {@link #getRelations(IResource)} if
	 * queried with the relation's source
	 * 
	 * @param rel
	 *            The relation to be added
	 * 
	 */
	void add(IRelation rel);

	void remove(IRelation rel);
	
	void add(IResource r);

	/**
	 * Flushes the whole cache. That means, that all elements have to be removed
	 * from it, triggering the listener callbacks.
	 */
	void flush();

	/**
	 * Registers an {@link IRelationListener}. It will be called for each element
	 * with its relations removed from the cache
	 * 
	 * @param listener
	 *            The listener to be registered
	 */
	void registerCacheListener(IRelationListener listener);

	/**
	 * Signals that no more elements should be cached. Listeners should be
	 * notified and the cache should be emptied
	 * @throws RepositoryException 
	 */
	void close();

	/**
	 * Checks whether the Cache is closed
	 * 
	 * @return <code>true</code> if the cache is closed, <code>false</code> else
	 */
	boolean isClosed();
}
