package de.uni_kiel.schemex.implementation.schemex.required.computation;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ISchemaElement;
import de.uni_kiel.schemex.implementation.common.OWLSameAsInstance;
import de.uni_kiel.schemex.implementation.schemex.common.BackwardInstance;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;

import java.util.Set;

/**
 * Created by Blume Till on 20.09.2016.
 */
public class SameAsSchemaGenerator extends RDFSSchemaGenerator {

    public SameAsSchemaGenerator(int bisimulationDepth, String typeClassifier, IElementCache<IInstanceElement> instanceCache, IElementCache<BackwardInstance> backwardCache) {
        super(bisimulationDepth, typeClassifier, instanceCache, backwardCache);
    }

    public SameAsSchemaGenerator(int bisimulationDepth, String typeClassifier, IElementCache<IInstanceElement> instanceCache, IElementCache<BackwardInstance> backwardCache, Boolean useIncomingProperties) {
        super(bisimulationDepth, typeClassifier, instanceCache, backwardCache, useIncomingProperties);
    }

    public Set<ISchemaElement> createSchemaIndex(IInstanceElement instance, IRelationsCache schemaCache) {
        OWLSameAsInstance owlSameAsInstance = null;
        if (instance instanceof OWLSameAsInstance)
            owlSameAsInstance = (OWLSameAsInstance) instance;
        else {
            System.out.println("Not proper configured!");
            System.exit(-1);
        }

        //iterate over all connected instances and add all their statements
        IInstanceElement tmpInstance;
        for (IResource locator : owlSameAsInstance.getOWLSameAsInstances())
            if ((tmpInstance = instanceCache.get(locator)) != null) {
                tmpInstance.getOutgoingQuints().forEach(Q -> instance.addOutgoingQuint(Q));
                tmpInstance.getIncomingQuints().forEach(Q -> instance.addIncomingQuint(Q));
            }

        return super.createSchemaIndex(instance, schemaCache);
    }
}