/**
 *  This package contains implementations for common interfaces used by schemex
 */
/**
 * @author Bastian
 *
 */
package de.uni_kiel.schemex.implementation.schemex.common;