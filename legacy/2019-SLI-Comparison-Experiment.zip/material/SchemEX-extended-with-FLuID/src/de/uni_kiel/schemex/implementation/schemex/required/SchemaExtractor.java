package de.uni_kiel.schemex.implementation.schemex.required;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IPayloadElement;
import de.uni_kiel.schemex.common.IResource;
import de.uni_kiel.schemex.common.ISchemaElement;
import de.uni_kiel.schemex.implementation.common.SimpleRelation;
import de.uni_kiel.schemex.implementation.schemex.common.BackwardInstance;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;
import de.uni_kiel.schemex.interfaces.provided.ISchemaElementEmitter;
import de.uni_kiel.schemex.interfaces.required.IElementCacheListener;
import de.uni_kiel.schemex.interfaces.required.ISchemaElementListener;
import de.uni_kiel.schemex.implementation.schemex.common.EquivalenceClass;
import de.uni_kiel.schemex.implementation.schemex.common.TypeCluster;
import de.uni_kiel.schemex.implementation.schemex.required.computation.IPayloadGenerator;
import de.uni_kiel.schemex.implementation.schemex.required.computation.ISchemaGenerator;
import org.semanticweb.yars.nx.Resource;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

/**
 * The class for extracting SchemEx schema information from an instance stream
 *
 * @author Bastian
 */
public class SchemaExtractor implements
        IElementCacheListener<IInstanceElement>, ISchemaElementEmitter {

    private IRelationsCache schemaCache;
    private IRelationsCache payloadCache;

    private List<ISchemaElementListener> listeners;

    private ISchemaGenerator schemaGenerator;
    private IPayloadGenerator payloadGenerator;


    /**
     * Constructs a parametrized Schema Extractor with the given caches and generators
     *
     * @param schemaCache
     * @param payloadCache
     * @param instanceCache
     * @param backwardCache
     * @param schemaGenerator
     * @param payloadGenerator
     */
    public SchemaExtractor(IRelationsCache schemaCache, IRelationsCache payloadCache,
                           IElementCache<IInstanceElement> instanceCache, IElementCache<BackwardInstance> backwardCache,
                           ISchemaGenerator schemaGenerator, IPayloadGenerator payloadGenerator) {

        this.schemaCache = schemaCache;//TODO: actually use different caches
        this.payloadCache = payloadCache;
        this.payloadGenerator = payloadGenerator;
        this.schemaGenerator = schemaGenerator;

        instanceCache.registerCacheListener(this);
        listeners = new ArrayList<>();
    }


    @Override
    public void elementFlushed(IInstanceElement instance) {
        if (instance == null || instance.getOutgoingQuints().isEmpty()) {
            //keep old instance definition
            return; //TODO as parameter
        }

        ////	Schema		////
        //create schema index according to given setup
        Set<ISchemaElement> elements = schemaGenerator.createSchemaIndex(instance, schemaCache);
        ////	Payload		////
        //extract payload as needed
        if(payloadGenerator != null)
            payloadGenerator.createPayload(schemaGenerator.getSchemaElementLocator(), instance, schemaCache);
        //FIXME: Many duplicate triples when writing them instantly, problem?
        // notify writer
        elements.forEach(ELEM -> notifyListeners(ELEM));

    }

    @Override
    public void finished() {
        for (Entry<Resource, TypeCluster> e : TypeCluster.DATATYPE_MAP.entrySet()) {
            //create all static TypeCluster (Literal TypeCluster)
            notifyListeners(e.getValue());

            // Create empty EQC
            // TODO Why? To be consistent with the Schema, not to have TC which do not have a attached EQC?
            EquivalenceClass eqc = new EquivalenceClass(new TreeSet<>(), e.getValue().getLocator());
            notifyListeners(eqc);
            schemaCache.add(new SimpleRelation(e.getValue().getLocator(), eqc.getLocator()));
        }
        //create Unresolved TypeCluster
        notifyListeners(TypeCluster.TC_UNRESOLVED_LITERAL);
        // Create empty EQC
        // TODO Why? To be consistent with the Schema, not to have TC which do not have a attached EQC?
        EquivalenceClass eqc = new EquivalenceClass(new TreeSet<>(),
                TypeCluster.TC_UNRESOLVED_LITERAL.getLocator());

        notifyListeners(eqc);
        schemaCache.add(new SimpleRelation(TypeCluster.TC_UNRESOLVED_LITERAL.getLocator(), eqc.getLocator()));

        //close everything
        schemaCache.close();
        payloadCache.close();
        for (ISchemaElementListener l : listeners)
            l.finished(this);

//        //TODO: Debugger
//        MissLogger.getLogger().close();
        schemaGenerator.finished();
    }


    private void notifyListeners(ISchemaElement el) {
        for (ISchemaElementListener l : listeners)
            l.elementEmitted(el);
    }

    @Override
    public void registerSchemaElementListener(ISchemaElementListener l) {
        listeners.add(l);
    }
}
