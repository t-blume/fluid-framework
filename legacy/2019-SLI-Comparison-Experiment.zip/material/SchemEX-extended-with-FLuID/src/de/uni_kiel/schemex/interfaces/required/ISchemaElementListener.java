package de.uni_kiel.schemex.interfaces.required;

import de.uni_kiel.schemex.common.ISchemaElement;
import de.uni_kiel.schemex.interfaces.provided.ISchemaElementEmitter;

/**
 * A listener for emitted schema elements
 *
 * @author Bastian
 */
public interface ISchemaElementListener {

    /**
     * An element has been emitted
     *
     * @param el The emitted elements
     */
    void elementEmitted(ISchemaElement el);

    /**
     * The emitter has stopped sending new elements
     *
     * @param emitter The emitter
     */
    void finished(ISchemaElementEmitter emitter);
}
