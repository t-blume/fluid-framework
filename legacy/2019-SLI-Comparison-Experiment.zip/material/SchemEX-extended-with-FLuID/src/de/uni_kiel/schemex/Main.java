package de.uni_kiel.schemex;

import de.uni_kiel.evaluation.connectors.Connection;
import de.uni_kiel.evaluation.eval.EvalUnit;
import de.uni_kiel.evaluation.eval.EvalUnitExperimental;
import de.uni_kiel.evaluation.vocabularies.SchemEXVocabulary;
import de.uni_kiel.evaluation.vocabularies.VocabularyConstants;
import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.implementation.common.QuintFilter;
import de.uni_kiel.schemex.implementation.provided.*;
import de.uni_kiel.schemex.implementation.required.*;
import de.uni_kiel.schemex.implementation.required.materialize.MaterializeAggregator;
import de.uni_kiel.schemex.implementation.schemex.common.BackwardInstance;
import de.uni_kiel.schemex.implementation.schemex.required.SchemaExtractor;
import de.uni_kiel.schemex.implementation.schemex.required.computation.*;
import de.uni_kiel.schemex.implementation.schemex.required.writer.UniversalWriter;
import de.uni_kiel.schemex.implementation.schemex.required.writer.sinks.FileQuadSink;
import de.uni_kiel.schemex.implementation.schemex.required.writer.utils.WriterVocabulary;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.interfaces.provided.IQuintSource;
import de.uni_kiel.schemex.interfaces.provided.IRelationsCache;
import de.uni_kiel.schemex.interfaces.required.IElementCacheListener;
import de.uni_kiel.schemex.interfaces.required.IQuintSourceListener;
import de.uni_kiel.schemex.utils.Constants;
import org.apache.commons.cli.*;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;
import org.openrdf.repository.RepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.bridge.SLF4JBridgeHandler;
import zbw.cau.gotham.schema.ISchemaGraph;
import zbw.cau.gotham.schema.InMemorySchemaGraph;
import zbw.cau.gotham.schema.SchemaGraphInferencing;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import static de.uni_kiel.schemex.utils.AdvancedUtils.*;
import static de.uni_kiel.schemex.utils.BasicUtils.createFile;
import static de.uni_kiel.schemex.utils.BasicUtils.getReallyUsedMemory;
import static de.uni_kiel.schemex.utils.Constants.RDF_TYPE;

public class Main {

    private static void run(CommandLine cmd) throws IOException, RepositoryException {
        // --- READ PARAMETERS ---------------------------------------
//        System.setErr(new PrintStream(new OutputStream() {
//            @Override
//            public void write(int b) {
//            }
//        }));
        System.out.println(cmd.hasOption("ff"));
        for(Option option: cmd.getOptions()){
            System.out.println(option.toString());
        }
        System.out.println(cmd.getOptions());
        boolean debug = false;
        if (cmd.hasOption("debug")) {
            debug = true;
        }
        String vocabFile = "";
        if (cmd.hasOption("v")) {
            vocabFile = cmd.getOptionValue("v");
        }

        WriterVocabulary wvocab = null;
        try {
            wvocab = WriterVocabulary.fromFile(vocabFile);
        } catch (Exception e) {
            wvocab = WriterVocabulary.DEFAULT;
            // System.out.println("Couldn't find vocabulary - using default");
        }
        if (cmd.hasOption("stat")) {
            String[] args = cmd.getOptionValues("stat");
            propertyStatistics(args[0], args[1], cmd.hasOption("ff"));
            System.exit(0);
        }

        if (cmd.hasOption("stat2")) {
            String[] args = cmd.getOptionValues("stat2");
            typeStatistics(args[0], args[1], cmd.hasOption("ff"));
            System.exit(0);
        }

        if (cmd.hasOption("stat3")) {
            String[] args = cmd.getOptionValues("stat3");
            datasetStatistics(args[0], args[1], cmd.hasOption("ff"));
            System.exit(0);
        }

        if (cmd.hasOption("filt")) {
            String[] args = cmd.getOptionValues("filt");
            quadFiltering(args[0], loadContexts(args[1]), args[2], cmd.hasOption("ff"));
            System.exit(0);
        }
        if (cmd.hasOption("eval")) {
            Set<EvalUnitExperimental.EvalType> evalTypes = new HashSet<>();
            if (cmd.hasOption("evalOpt")) {
                String[] evalOpt = cmd.getOptionValues("evalOpt");
                for (String eo : evalOpt)
                    for (EvalUnitExperimental.EvalType et : EvalUnitExperimental.EvalType.values())
                        if (eo.matches(et.toString()))
                            evalTypes.add(et);
            }

            String[] args = cmd.getOptionValues("eval");
            String server = "http://localhost:8080/openrdf-sesame/";
            if (cmd.hasOption("srv"))
                server = cmd.getOptionValue("srv");
            evaluateIndices(args[0], args[1], server, evalTypes, debug, wvocab);
            System.exit(0);
        }

        boolean splitSchema = cmd.hasOption("ps");
        boolean zip = cmd.hasOption("z");
        boolean clearRepo = cmd.hasOption("cl");
        boolean silent = cmd.hasOption("s");
        boolean fixLiterals = cmd.hasOption("l");
        boolean isDirectory = true;

        int numberOfSnippets = 3;
        if (cmd.hasOption("sn")) {
            try {
                numberOfSnippets = Integer.parseInt(cmd.getOptionValue("sn"));
                if (numberOfSnippets < 0)
                    numberOfSnippets = 0;
            } catch (Exception e) {
                System.out.println("Number of snippets parameter is no integer value: "
                        + e.getMessage());
            }
        }

        // --- READ Inference Parameters ---------------------------------------
        boolean useRDFs = cmd.hasOption("rdfs");
        boolean useLODSem = cmd.hasOption("lodsem");
        boolean useSameAs = cmd.hasOption("sa");
        String externalSchemaGraph = null;
        if (cmd.hasOption("sg")) {
            externalSchemaGraph = cmd.getOptionValue("sg");
            System.out.println("Loading external schema graph from: " + externalSchemaGraph);
        }

        int bisimDepth = 1;
        if (cmd.hasOption("bi")) {
            try {
                bisimDepth = Integer.parseInt(cmd.getOptionValue("bi"));
            } catch (Exception e) {
                System.out.println("Bisim depth parameter is no integer value: "
                        + e.getMessage());
            }
        }
        boolean useIncomingProps = false;
        if (cmd.hasOption("ip"))
            useIncomingProps = true;

        String typeClassifier = RDF_TYPE; //default
        if (cmd.hasOption("noTC"))
            typeClassifier = null;

        boolean sameObject = false;
        if (cmd.hasOption("so"))
            sameObject = true;

        boolean independentTC = false;
        if (cmd.hasOption("inTC"))
            independentTC = true;

        Set<String> relations = null;
        String relationsFilename = null;
        if (cmd.hasOption("rel")) {
            relations = new HashSet<>();
            relationsFilename = cmd.getOptionValue("rel");
            try (BufferedReader br = new BufferedReader(new FileReader(relationsFilename))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.contains(";")) {
                        String[] split = line.split(";");
                        line = split[0];
                    }
                    line = line.trim();
                    if (!line.isEmpty())
                        relations.add(line);
                }
            }
            System.out.println("Rel:" + relationsFilename + " (" + relations.size() + ")");
        }

        String logging = null;
        if (cmd.hasOption("log")) {
            logging = cmd.getOptionValue("log");
            System.out.println("Log: " + logging);
        }
        int cacheSize = -1;
        int secCacheSize = -1;
        int schemaCacheSize = -1;

        if (cmd.hasOption("c")) {
            try {
                cacheSize = Integer.parseInt(cmd.getOptionValue("c"));
            } catch (Exception e) {
                System.out.println("Cache size parameter is no integer value: "
                        + e.getMessage());
            }
        }

        if (cmd.hasOption("secc")) {
            try {
                secCacheSize = Integer.parseInt(cmd.getOptionValue("secc"));
            } catch (Exception e) {
                System.out.println("Cache size parameter is no integer value: "
                        + e.getMessage());
            }
        }

        if (cmd.hasOption("sc")) {
            try {
                schemaCacheSize = Integer.parseInt(cmd.getOptionValue("sc"));
            } catch (Exception e) {
                System.out.println("Cache size parameter is no integer value: "
                        + e.getMessage());
            }
        }

        ///////////////////////////////////////////
        ////////////	goldstandard	///////////
        if (cacheSize < 0)
            cacheSize = Integer.MAX_VALUE;
        if (secCacheSize < 0)
            secCacheSize = Integer.MAX_VALUE;
        if (schemaCacheSize < 0)
            schemaCacheSize = Integer.MAX_VALUE;
        ///////////////////////////////////////////

        List<String> files = new ArrayList<>();

        // option d - read and process a directory
        if (cmd.hasOption("d")) {
            String input_directory = cmd.getOptionValue("d");
            files.add(input_directory);
            isDirectory = true;
        }

        // option debug - write comment into n3 schema.nt file


        // option f - read and process a file
        if (cmd.hasOption("f")) {
            String input_filename = cmd.getOptionValue("f");
            files.add(input_filename);
            isDirectory = false;
        }

        final String output;
        if (cmd.hasOption("o")) {
            output = cmd.getOptionValue("o");

            // create folder, if it does not exist
            File output_folder = new File(output);
            if (!output_folder.exists()) {
                try {
                    output_folder.mkdir();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else
            output = ".";

        String writerType = "";
        if (cmd.hasOption("w")) {
            writerType = cmd.getOptionValue("w");
        } else
            writerType = "simple2012format";


        String defaultContext = "";
        if (cmd.hasOption("dc")) {
            defaultContext = cmd.getOptionValue("dc");
        } else {
            defaultContext = wvocab.getEntry(WriterVocabulary.NAMESPACE);
        }


        //do not compute schema, only create schema graph
        if (cmd.hasOption("bsg")) {
            String[] args = cmd.getOptionValues("bsg");

            buildSchemaGraph(isDirectory, files, defaultContext, wvocab, output, args[0], args[1]);
            System.exit(0);
        }


        final String sesameServer;
        if (cmd.hasOption("srv")) {
            sesameServer = cmd.getOptionValue("srv");
        } else {
            sesameServer = "http://localhost:8080/rdf4j-server/";
        }

        boolean materialize = false;
        String matInput = "";
        if (cmd.hasOption("m")) {
            matInput = cmd.getOptionValue("m");
            materialize = true;
        }


        // ------------------------------------------------------------
        // decalare final variables as parameter for inner class
        final int insCache = cacheSize;
        final int secCache = secCacheSize;
        final int schCache = schemaCacheSize;
        final int payCache = schemaCacheSize / 10;
        final int optCache = 50000; //TODO
        // ------------------------------------------------------------
        // Initiate data source component (=read from file)
        IQuintSource source;
        if (isDirectory) {
            final String finalRegex = ".*data\\.nq.*";
            source = new FileQuadSource(files, true, defaultContext, new FileFilter() {
                @Override
                public boolean accept(File pathname) {
                    if (pathname != null) {
                        boolean t = pathname.toString().matches(finalRegex);
                        if (t) {
                            System.out.println("Adding: " + pathname.toString());
                            return true;
                        } else
                            return false;
                    }

                    return
                            false;
                }
            }
            );
        } else
            source = new FileQuadSource(files, false, defaultContext);


        source.registerQuintListener(new IQuintSourceListener() {
            long n = 0;

            PrintStream out = new PrintStream(new FileOutputStream(createFile(output
                    + File.separator + "quads.txt")));

            @Override
            public void sourceStarted() {
            }

            @Override
            public void sourceClosed() {
                out.println("--------Quads processed---------");
                out.println("Num: " + n);
                out.println("--------------------------");
            }

            @Override
            public void pushedQuint(IQuint quint) {
                n++;
            }
        });

        // Initialize the processing pipeline
        BasicQuintPipeline pipe = new BasicQuintPipeline();

        // ;-)
        //p.addProcessor(new PassThroughProcessor());

        // Cleanup dirty data
        pipe.addProcessor(new NoisyDataFilter(wvocab.getEntry(WriterVocabulary.NAMESPACE) + "broken/", fixLiterals, output));
        // Deanonymize the context URIs
        pipe.addProcessor(new DeAnonymizer("http://schemex.de/"));

        //relation parameterization
        if (relations != null && !relations.isEmpty())
            pipe.addProcessor(new QuintFilter(relations));

        RDFSGraphFilter rdfsGraphFilter = null;
        QuintFilter quintFilter = null;
        if (useRDFs || useLODSem) {
            if (externalSchemaGraph != null) {
                System.out.println("Accessing external schema graph:");
                //Using pre-computed schema graph, thus, filter only
                quintFilter = new QuintFilter(Constants.RDFS_PROPERTIES);
                pipe.addProcessor(quintFilter);

                System.out.println(externalSchemaGraph);
                if (externalSchemaGraph.endsWith(".nt")) {
                    System.out.println("is triples file");
                    List<String> filepaths = new LinkedList<>();
                    filepaths.add(externalSchemaGraph);
                    FileQuadSource fileQuadSource = new FileQuadSource(filepaths, false, defaultContext);
                    BasicQuintPipeline schemaPipe = new BasicQuintPipeline();
                    rdfsGraphFilter = new RDFSGraphFilter(Constants.RDFS_PROPERTIES);
                    schemaPipe.addProcessor(rdfsGraphFilter);
                    fileQuadSource.registerQuintListener(schemaPipe);

                    // Start Schema Graph
                    fileQuadSource.start();
                    System.out.println("Loaded external schema graph");
                    //rdfsGraphFilter.getSchemaGraph().printStatistics(System.out);
                } else {
                    File file = new File(externalSchemaGraph);
                    System.out.println("is no triples file");
                    if (file.exists() && file.isDirectory()) {
                        System.out.println("is folder");
                        SchemaGraphInferencing schemaGraph = new SchemaGraphInferencing(10000, externalSchemaGraph);
                        rdfsGraphFilter = new RDFSGraphFilter(Constants.RDFS_PROPERTIES);
                        rdfsGraphFilter.setSchemaGraph(schemaGraph);
                    } else {
                        System.err.println("Misconfigured schema graph! (" + externalSchemaGraph + ")");
                        System.exit(-1);
                    }
                }
            } else {
                // QuintFilter component that removes all RDFS properties, but adds them to a graph
                rdfsGraphFilter = new RDFSGraphFilter(Constants.RDFS_PROPERTIES);
                pipe.addProcessor(rdfsGraphFilter);
            }
        } else {
            // QuintFilter component that removes all RDFS properties
            quintFilter = new QuintFilter(Constants.RDFS_PROPERTIES);
            pipe.addProcessor(quintFilter);
        }

        // Materialize the data on the fly
        if (materialize) {
            List<File> matList = new ArrayList<>();
            matList.add(new File(matInput));
            MaterializeAggregator ma = new MaterializeAggregator(matList);
            try {
                ma.initialize();
            } catch (Exception e) {
                e.printStackTrace();
            }
            pipe.addProcessor(ma);
        }


        final IElementCache<IInstanceElement> instanceCache = new FifoInstanceCache<>(cacheSize);
        final IElementCache<BackwardInstance> backwardCache = new FifoInstanceCache<>(secCacheSize);

        // Setup of caches
        final IRelationsCache simpleSchemaCache = new FifoSchemaCache(schemaCacheSize);
        final IRelationsCache payloadCache = new FifoSchemaCache(schemaCacheSize / 10);

        instanceCache.registerCacheListener(new IElementCacheListener<IInstanceElement>() {
            PrintStream out = new PrintStream(new FileOutputStream(output + File.separator + "instances.txt"));
            private long n = 0;

            private long lastTime = System.currentTimeMillis();

            private double maxTime = Double.MIN_VALUE;
            private double minTime = Double.MAX_VALUE;

            private long maxMemory = 0;
            private long maxUsedMemory = 0;

            private long maxInstanceCacheSize = insCache;
            private long maxBackwardCacheSize = secCache;
            private long maxSchemaCacheSize = schCache;
            private long maxPayloadCacheSize = payCache;
            private long maxOptimizerCacheSize = optCache;
            private long instanceCacheSize = 0;
            private long backwardCacheSize = 0;
            private long schemaCacheSize = 0;
            private long payloadCacheSize = 0;
            private long optimizerCacheSize = 0;

            private boolean verbose = true;

            @Override
            public void elementFlushed(IInstanceElement instance) {
                n++;

                instanceCacheSize = instanceCache.size();
                backwardCacheSize = backwardCache.size();
                schemaCacheSize = simpleSchemaCache.size();
                //payloadCacheSize = payloadCache.size();

                maxInstanceCacheSize = Math.max(maxInstanceCacheSize, instanceCacheSize);
                maxBackwardCacheSize = Math.max(maxBackwardCacheSize, backwardCacheSize);
                maxSchemaCacheSize = Math.max(maxSchemaCacheSize, schemaCacheSize);
                maxPayloadCacheSize = Math.max(maxPayloadCacheSize, payloadCacheSize);
                maxPayloadCacheSize = Math.max(maxPayloadCacheSize, payloadCacheSize);
                if (n % 10000 == 0) {

                    long currentTime = System.currentTimeMillis();
                    long delta = currentTime - lastTime;
                    lastTime = currentTime;
                    double instancesPerSecond = (100000.0 / delta * 1000.0);
                    maxTime = Math.max(instancesPerSecond, maxTime);
                    minTime = Math.min(instancesPerSecond, minTime);

                    long runtimeMemory = getReallyUsedMemory();
                    maxMemory = Math.max(runtimeMemory, maxMemory);
                    maxUsedMemory = Math.max(maxUsedMemory, runtimeMemory);

                    Date date = new Date();
                    System.out.println("\n--------------------------------------");
                    System.out.format("%tc: Instance count %08d", date, n);
                    System.out.format(" - Caches I: %08d/%08d B: %08d/%08d S: %08d/%08d O: %08d/%08d\n",
                            instanceCacheSize, maxInstanceCacheSize, backwardCacheSize, maxBackwardCacheSize,
                            schemaCacheSize, maxSchemaCacheSize, optimizerCacheSize, maxOptimizerCacheSize);

                    if (verbose == true) {
                        System.out.println(" instances per second: " + instancesPerSecond);
                        System.out.println("Current Memory: " + (runtimeMemory / 1024 / 1024) + "MB");
                        System.out.println("Max Memory: " + (maxUsedMemory / 1024 / 1024) + "MB");
                        System.out.println("--------------------------------------\n");
                    }
                }

            }

            @Override
            public void finished() {
                out.println("--------Instances---------");
                out.println("Num: " + n);
                out.println("Maximum instances per second: " + maxTime);
                out.println("Minimum instances per second: " + minTime);
                out.println("Maximum memory allocated: " + (maxMemory / 1024 / 1024) + "MB");
                out.println("Maximum memory used: " + (maxUsedMemory / 1024 / 1024) + "MB");
                out.println("Maximum instance cache used: " + maxInstanceCacheSize);
                out.println("Maximum backward cache used: " + maxBackwardCacheSize);
                out.println("Maximum schema cache used: " + maxSchemaCacheSize);
                out.println("Maximum payload cache used: " + maxPayloadCacheSize);
                out.println("--------------------------");
            }
        });
        boolean useWeakEquivalences = cmd.hasOption("wE");

        // Build pipe and start SchemEX
        //Use owl:sameAs-Instances instead
        InstanceAggregator instanceAggregator;
        if (useLODSem || useSameAs)
            instanceAggregator = new InstanceAggregatorOWLSameAs(instanceCache, useIncomingProps);
        else if (useWeakEquivalences)
            instanceAggregator = new TransInstanceAggregator(instanceCache, useIncomingProps, cacheSize);
        else
            instanceAggregator = new InstanceAggregator(instanceCache, useIncomingProps);

        pipe.registerQuintListener(instanceAggregator);
        source.registerQuintListener(pipe);

        ISchemaGenerator schemaGenerator;
        //FIXME:
        if (useWeakEquivalences) {
            schemaGenerator = new WeakEquivSchemaGenerator(bisimDepth, typeClassifier, instanceCache, backwardCache, useIncomingProps);
            ((WeakEquivSchemaGenerator) schemaGenerator).setInstanceAggregator((TransInstanceAggregator) instanceAggregator);
            System.out.println("SemSets");
        } else if (sameObject) {
            schemaGenerator = new SemSetGenerator(bisimDepth, typeClassifier, instanceCache, backwardCache, useIncomingProps);
            System.out.println("SemSets");
        } else if (independentTC) {
            schemaGenerator = new TermPickerGenerator(bisimDepth, typeClassifier, instanceCache, backwardCache, useIncomingProps);
            System.out.println("TermPicker");
        } else if (useRDFs) {
            schemaGenerator = new RDFSSchemaGenerator(bisimDepth, typeClassifier, instanceCache, backwardCache, useIncomingProps);
            ((RDFSSchemaGenerator) schemaGenerator).registerSchemaGraph(rdfsGraphFilter.getSchemaGraph());
        } else if (useLODSem) {
            schemaGenerator = new SameAsSchemaGenerator(bisimDepth, typeClassifier, instanceCache, backwardCache, useIncomingProps);
            ((SameAsSchemaGenerator) schemaGenerator).registerSchemaGraph(rdfsGraphFilter.getSchemaGraph());
        } else if (useSameAs) {
            schemaGenerator = new SameAsSchemaGenerator(bisimDepth, typeClassifier, instanceCache, backwardCache, useIncomingProps);
        } else //without schema graph
            schemaGenerator = new RDFSSchemaGenerator(bisimDepth, typeClassifier, instanceCache, backwardCache, useIncomingProps);

        //generic filename structure depending on the configuration
        String niceName = "";
        String inputFile = files.get(0);
        String[] tmp = inputFile.split("(" + "\\" + System.getProperty("file.separator") + "|/" + ")");
        String dataset = tmp[tmp.length - 1];
        dataset = dataset.replaceAll("\\..*", "");
        niceName += dataset + "_";
        if (cacheSize == Integer.MAX_VALUE && schemaCacheSize == Integer.MAX_VALUE)
            niceName += "gold_";
        else {
            String cs = String.valueOf(cacheSize);
            char[] chars = cs.toCharArray();
            cs = "";
            for (int i = chars.length - 1; i >= 0; i--)
                cs += chars[i];
            cs = cs.replaceAll("000", "k");
            chars = cs.toCharArray();
            cs = "";
            for (int i = chars.length - 1; i >= 0; i--)
                cs += chars[i];

            String scs = String.valueOf(schemaCacheSize);
            chars = scs.toCharArray();
            scs = "";
            for (int i = chars.length - 1; i >= 0; i--)
                scs += chars[i];
            scs = scs.replaceAll("000", "k");
            chars = scs.toCharArray();
            scs = "";
            for (int i = chars.length - 1; i >= 0; i--)
                scs += chars[i];

            niceName += cs + "-" + scs + "_";
        }


        if (useRDFs)
            niceName += "rdfs_";
        else if (useLODSem)
            niceName += "lodsem_";
        else if (useSameAs)
            niceName += "sameAs_";
        else if (useWeakEquivalences)
            niceName += "weakEqui_";
        if (typeClassifier == null)
            niceName += "noTC_";
        if (relations != null && !relations.isEmpty()) {
            String tmpRelName = relationsFilename.split("\\.")[Math.max(
                    relationsFilename.split("\\.").length - 2, 0)];
            tmpRelName = tmpRelName.split("\\\\|\\/")[tmpRelName.split("\\\\|\\/").length - 1];
            System.out.println(tmpRelName);
            niceName += "rel-" + tmpRelName + "_";
        }

        if (useIncomingProps)
            niceName += "ip_";
        if (sameObject)
            niceName += "so_";
        if (independentTC)
            niceName += "inTC_";

        niceName += "bD-" + bisimDepth;
        niceName += "_sn-" + numberOfSnippets;
        niceName += (externalSchemaGraph == null ? "" : "_postSG");
        System.out.println(niceName);

        //if logging is enable
        if (logging != null) {
            String name = "MissLogger_" + niceName + ".csv";
            schemaGenerator.enableLogging(logging, name);
        }

        IPayloadGenerator payloadGenerator = null;
        if (!useWeakEquivalences)
            payloadGenerator = new DatasourcePayloadGenerator(new ContextExtractor());
        if (numberOfSnippets > 0) {
            //TODO
        }

        //instanceCache.registerCacheListener(new InstanceStatisticsWriter(optimizerCache, output));
        // Setup of SchemaExtractor
        SchemaExtractor schemaExtractor;
        UniversalWriter writer = null;
        // Use the "old" SchemexWriter for writing schema.nt
        switch (writerType) {
            case "simple2012format":
                schemaExtractor = new SchemaExtractor(simpleSchemaCache, payloadCache, instanceCache, backwardCache,
                        schemaGenerator, payloadGenerator);
                schemaExtractor.registerSchemaElementListener(new SchemaStatisticsWriter(output));
                writer = UniversalWriter.getFileWriter(wvocab, splitSchema, zip, output, clearRepo, debug, niceName);
                schemaExtractor.registerSchemaElementListener(writer);
                simpleSchemaCache.registerCacheListener(writer);
                payloadCache.registerCacheListener(writer);
                break;
            case "sesame":
                schemaExtractor = new SchemaExtractor(simpleSchemaCache, payloadCache, instanceCache, backwardCache,
                        schemaGenerator, payloadGenerator);
                schemaExtractor.registerSchemaElementListener(new SchemaStatisticsWriter(output));
                writer = UniversalWriter.getSesameWriter(wvocab, output, clearRepo, debug);
                schemaExtractor.registerSchemaElementListener(writer);
                simpleSchemaCache.registerCacheListener(writer);
                payloadCache.registerCacheListener(writer);
                break;
            case "rdf4j":
                schemaExtractor = new SchemaExtractor(simpleSchemaCache, payloadCache, instanceCache, backwardCache,
                        schemaGenerator, payloadGenerator);
                schemaExtractor.registerSchemaElementListener(new SchemaStatisticsWriter(output));
                writer = UniversalWriter.getRDF4JWriter(wvocab, output, clearRepo, debug);
                schemaExtractor.registerSchemaElementListener(writer);
                simpleSchemaCache.registerCacheListener(writer);
                payloadCache.registerCacheListener(writer);
                break;
            default:
                System.out.println(writerType + " is invalid argument for option: w");
                System.exit(-1);
        }


        // Start SchemEX
        source.start();

        // flush stream buffer and close repository
        if (writer != null) {
            writer.close();
        }

        if (silent == false)
            System.out.println("\nFinished");
    }

    public static void main(String[] args) throws IOException, RepositoryException {
        System.out.println(ArrayUtils.toString(args));
        // Set up a simple log4j configuration that logs on the console
        BasicConfigurator.configure();
        // log4j file configuration
        PropertyConfigurator.configure("log4j.properties");

        // JUL to slf4j logging bridge needed for nxparser logging
        SLF4JBridgeHandler.removeHandlersForRootLogger();
        SLF4JBridgeHandler.install();

        // test logger
        Logger logger = LoggerFactory.getLogger(Main.class);
        final String message = "Start logging!";
        logger.info(message);

        Options computeOptions = new Options();

        // input options
        OptionGroup input = new OptionGroup();

        // read an input file
        Option file = new Option("f", "file", true, "location of input file");
        file.setArgName("file");
        input.addOption(file);
        // read a complete directory
        Option dir = new Option("d", "directory", true, "location of input directory");
        dir.setArgName("dir");
        input.addOption(dir);

        computeOptions.addOptionGroup(input);

        // processing options - scheme extraction
        OptionGroup process = new OptionGroup();
        // cachesize option
        Option cacheSize = new Option("c", "cachesize", true,
                "cache size (max cached number of RDF instances)");
        cacheSize.setArgName("int");
        cacheSize.setRequired(true);
        process.addOption(cacheSize);

        computeOptions.addOptionGroup(process);

        Option schema_cacheSize = new Option("sc", "schema-cachesize", true, "schema cache size");
        schema_cacheSize.setArgName("int");
        computeOptions.addOption(schema_cacheSize);

        ///////////////////////////////////////////////////////////////
        //additional caches:
        // secondary cachesize option
        Option sec_cacheSize = new Option("secc", "sec-cachesize", true, "secondary cache size");
        sec_cacheSize.setArgName("int");
        sec_cacheSize.setRequired(false);
        computeOptions.addOption(sec_cacheSize);

        Option output = new Option("o", "output", true, "output folder or repository name");
        output.setArgName("folder");
        computeOptions.addOption(output);

        Option server = new Option("srv", "server", true, "sesame server URL");
        output.setArgName("server URL");
        computeOptions.addOption(server);

        Option zip = new Option("z", "zip", false, "zip output");
        computeOptions.addOption(zip);

        Option vocab = new Option("v", "vocab", true, "vocabularyFile");
        computeOptions.addOption(vocab);

        Option mat = new Option("m", "materialize", true, "materializes data");
        mat.setArgName("ontology");
        computeOptions.addOption(mat);

        Option writer = new Option("w", "writer", true, "<simple2012format> or <sesame> or <rdf4j> or <rdf4jIterative>  writer");
        writer.setArgName("arg");
        computeOptions.addOption(writer);

        Option debug = new Option("db", "debug", false, "write comment to schema file");
        computeOptions.addOption(debug);

        // Outputwriter
        Option payloadSplit = new Option("ps", "split", false, "writes schema and payload in separate files");
        computeOptions.addOption(payloadSplit);

        Option defaultContext = new Option("dc", "defaultContext", true, "default context in case of triple data");
        computeOptions.addOption(defaultContext);

        // FIXME fix literals
        Option fixLiteral = new Option("l", "literal", false, "try to fix literals");
        computeOptions.addOption(fixLiteral);

        // empty sesame repository before writing
        Option clearRepo = new Option("cl", "clear", false, "clear sesame repository before writing");
        computeOptions.addOption(clearRepo);

        // sesame writer
        Option silent = new Option("s", "silent", false, "no output to console");
        computeOptions.addOption(silent);


        //Configuration
        OptionGroup inferenceOptions = new OptionGroup();
        Option useRDFs = new Option("rdfs", "RDFs", false, "Infer RDF Schema information");
        Option useLODSem = new Option("lodsem", "LODSemantics", false, "Infer RDFS + owl:sameAs schema information");
        Option useSameAs = new Option("sa", "sameAs", false, "Infer owl:sameAs schema information");

        inferenceOptions.addOption(useRDFs);
        inferenceOptions.addOption(useLODSem);
        inferenceOptions.addOption(useSameAs);
        computeOptions.addOptionGroup(inferenceOptions);

        Option useExternalSchemaGraph = new Option("sg", "schemagraph", true, "Use existing schema graph");
        computeOptions.addOption(useExternalSchemaGraph);

        Option createExternalSchemaGraph = new Option("bsg", "build-schemagraph", true, "Create schema graph on disk");
        createExternalSchemaGraph.setArgs(2);
        computeOptions.addOption(createExternalSchemaGraph);

        Option kBisim = new Option("bi", "bisimulation", true, "Use k-Bisimulation to create EQCs");
        kBisim.setArgName("int");
        computeOptions.addOption(kBisim);

        Option incomingProps = new Option("ip", "incoming-props", false, "Also use incoming properties");
        computeOptions.addOption(incomingProps);

        Option typeCluster = new Option("noTC", "No TypeCluster", false, "Turn distinction between Types and Properties off");
        computeOptions.addOption(typeCluster);

        Option sameObject = new Option("so", "same object", false, "All object TypeCluster are identifies by instance URI");
        computeOptions.addOption(sameObject);

        Option independentTC = new Option("inTC", "independent TC", false, "All object TypeCluster do not share same property");
        computeOptions.addOption(independentTC);

        Option weakEquivalence = new Option("wE", "weakEquiv", false, "Use transitively co-occurring properties to merge instances.");
        computeOptions.addOption(weakEquivalence);

        Option relation = new Option("rel", "relation", true, "Excludes all properties mentioned in the given csv file");
        relation.setArgName("relation-file-location");
        computeOptions.addOption(relation);

        Option snippets = new Option("sn", "snippets", true, "Number of snippets attached as payload");
        snippets.setArgName("int");
        computeOptions.addOption(snippets);

        Option logging = new Option("log", "logging", true, "Enable Logging Mechanism for Analyzing Program Behavior by specifying location");
        logging.setArgName("log-file-location");
        computeOptions.addOption(logging);


        Option evaluate = new Option("eval", "evaluate", true, "Evaluate: <goldRepo> <apprRepo>");
        evaluate.setArgs(2);
        computeOptions.addOption(evaluate);

        Option statistics = new Option("stat", "statisticsProps", true, "<inputFile> <outputFile>");
        statistics.setArgs(2);
        computeOptions.addOption(statistics);

        Option statistics2 = new Option("stat2", "statisticsType", true, "<inputFile> <outputFile>");
        statistics2.setArgs(2);
        computeOptions.addOption(statistics2);

        Option statistics3 = new Option("stat3", "statisticsDataset", true, "<inputFile> <outputFile>");
        statistics3.setArgs(2);
        computeOptions.addOption(statistics3);

        Option filtering = new Option("filt", "filtering", true, "<inputFile> <contextFile> <outputFile>");
        filtering.setArgs(3);
        computeOptions.addOption(filtering);

        Option fileFilter = new Option("ff", "filefilter", false, "filter for data files");
        computeOptions.addOption(fileFilter);

        String evalOpts = "";
        for (int i = 0; i < EvalUnitExperimental.EvalType.values().length - 1; i++)
            evalOpts += "<" + EvalUnitExperimental.EvalType.values()[i] + "> or ";
        evalOpts += "<" + EvalUnitExperimental.EvalType.values()[EvalUnitExperimental.EvalType.values().length - 1] + ">";
        Option evaluateOptions = new Option("evalOpt", "evaluate-options", true,
                "Evaluate only some queries: " + evalOpts);
        evaluate.setArgs(Option.UNLIMITED_VALUES);

        computeOptions.addOption(evaluateOptions);

        ///////////////////////////////////////////////////////////
        Options optionsHelp = new Options();
        Option help = new Option("h", "help", false, "print help");
        optionsHelp.addOption(help);

        CommandLineParser parserHelp = new DefaultParser();
        HelpFormatter formatterHelp = new HelpFormatter();
        CommandLine cmdHelp;


        // this parses the command line just for help and doesn't throw an exception on unknown options
        try {
            // parse the command line arguments for the help option
            cmdHelp = parserHelp.parse(optionsHelp, args, true);

            // print help
            if (cmdHelp.hasOption("h") || cmdHelp.hasOption("help")) {
                formatterHelp.printHelp(80, " ", "Extract a schema index from NQuads.\n",
                        computeOptions, "\n", true);
                System.exit(0);
            }

        } catch (ParseException e1) {
            formatterHelp.printHelp(80, " ", "ERROR: " + e1.getMessage() + "\n",
                    optionsHelp, "\nError occurred! Please see the error message above", true);
            System.exit(-1);
        }

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd = null;
        // this parses the command line for all other options
        try {
            // parse the command line arguments with the defined options
            cmd = parser.parse(computeOptions, args, true);

            // everything's fine, run the program
            run(cmd);
        } catch (ParseException e2) {
            formatter.printHelp(80, " ", "ERROR: " + e2.getMessage() + "\n",
                    computeOptions, "\nError occurred! Please see the error message above", true);
            System.exit(-1);
        }

    }


    /**
     * Separate "main"
     *
     * @param isDirectory
     * @param files
     * @param defaultContext
     * @param writerVocabulary
     * @param output
     * @throws FileNotFoundException
     */
    private static void buildSchemaGraph(boolean isDirectory, List<String> files, String defaultContext,
                                         WriterVocabulary writerVocabulary, String output, String propertyStatsFile,
                                         String typeStatsFile) throws IOException {

//        if (output == null || !(output.endsWith(".nt") || !output.contains("."))) {
//            System.err.println("Invalid output file/folder: <*.nt> | <folder>");
//            System.exit(-1);
//        }
        System.out.println("Stats of schema graph only...");
        // ------------------------------------------------------------
        // Initiate data source component (=read from file)
        IQuintSource source;
        if (isDirectory) {
//            final String finalRegex = ".*data\\.nq.*";
            source = new FileQuadSource(files, true, defaultContext, (FileFilter) pathname -> {
                if (pathname != null) {
//                    boolean t = pathname.toString().matches(finalRegex);
//                    if (t) {
                        System.out.println("Adding: " + pathname.toString());
                        return true;
//                    } else
//                        return false;
                }

                return
                        false;
            }
            );
        } else
            source = new FileQuadSource(files, false, defaultContext);


        source.registerQuintListener(new IQuintSourceListener() {
            long n = 0;
            File outfile = new File(output + "dataset-triples.txt");
            PrintStream out= new PrintStream(outfile);

            @Override
            public void sourceStarted() {
            }

            @Override
            public void sourceClosed() {
                out.println("--------Quads processed---------");
                out.println("Num: " + n);
                out.println("--------------------------");
            }

            @Override
            public void pushedQuint(IQuint quint) {
                n++;
            }
        });

        // Initialize the processing pipeline
        BasicQuintPipeline pipe = new BasicQuintPipeline();

        // Cleanup dirty data
        pipe.addProcessor(new NoisyDataFilter(writerVocabulary.getEntry(WriterVocabulary.NAMESPACE) + "broken/", false, output));
        // Deanonymize the context URIs
        pipe.addProcessor(new DeAnonymizer("http://schemex.de/"));


        RDFSGraphFilter rdfsGraphFilter = null;
        QuintFilter quintFilter = null;
        // QuintFilter component that removes all RDFS properties, but adds them to a graph
        rdfsGraphFilter = new RDFSGraphFilter(Constants.RDFS_PROPERTIES);
        pipe.addProcessor(rdfsGraphFilter);
        source.registerQuintListener(pipe);

        // Start SchemEX
        source.start();

        System.out.println("opening property stats file: " + propertyStatsFile);
        HashMap<String, Integer> propertyStats = new HashMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(new File(propertyStatsFile)));
        String line;
        while((line = reader.readLine()) != null){
            String[] tmp = line.split(",");
            String text;
            int value;
            if(tmp.length != 2){
                System.out.println("Error in Parsing line: " + line);
                if (tmp.length > 2){
                    text = "";
                    for(int i=0; i < tmp.length-1; i++)
                        text += tmp[i];
                    value = Integer.parseInt(tmp[tmp.length-1]);
                }else {
                    System.out.println("Invalid Line!");
                    continue;
                }
            }else{
                text = tmp[0];
                value = Integer.parseInt(tmp[1]);
            }
            propertyStats.put(text, value);
        }

        System.out.println("opening type stats file: " + typeStatsFile);
        HashMap<String, Integer> typeStats = new HashMap<>();
        reader = new BufferedReader(new FileReader(new File(typeStatsFile)));
        while((line = reader.readLine()) != null){
            String[] tmp = line.split(",");
            String text;
            int value;
            if(tmp.length != 2){
                if (tmp.length > 2){
                    text = "";
                    for(int i=0; i < tmp.length-1; i++)
                        text += tmp[i];
                    value = Integer.parseInt(tmp[tmp.length-1]);
                }else {
                    System.out.println("Error in Parsing line: " + line);
                    System.out.println("Invalid Line!");
                    continue;
                }
            }else{
                text = tmp[0];
                value = Integer.parseInt(tmp[1]);
            }
            typeStats.put(text, value);
        }
        File outfile = new File(output + "schema-graph-statistics.txt");
        PrintStream outPrintStream = new PrintStream(outfile);
        rdfsGraphFilter.getSchemaGraph().printStatistics(outPrintStream, propertyStats, typeStats);
        //finished
//        System.out.println("Exporting schema graph to \"" + output + "\"");
//        if (output.endsWith(".nt")) {
//            PrintStream schemaWriter = new PrintStream(output);
//            FileQuadSink sink = new FileQuadSink(schemaWriter, true);
//            ((InMemorySchemaGraph) rdfsGraphFilter.getSchemaGraph().getSchemaGraph()).stream(quint ->
//                    sink.print(quint.getSubject().toN3(), quint.getPredicate().toN3(), quint.getObject().toN3(), quint.getContext().toN3()));
//        } else if (!output.contains("."))
//            ((InMemorySchemaGraph) rdfsGraphFilter.getSchemaGraph().getSchemaGraph()).persist(output);


        System.out.println("done");
    }


    private static void evaluateIndices(String goldRepository, String approximateRepository,
                                        String server, Set<EvalUnitExperimental.EvalType> evalOptSet,
                                        boolean debug, WriterVocabulary vocabulary) {
//        VocabularyConstants goldVocab = new SchemEXVocabulary();
//        VocabularyConstants apprVocab = new SchemEXVocabulary();


        EvalUnit evalUnit = new EvalUnit(Connection::getRDF4JConnector, server,
                goldRepository, approximateRepository, vocabulary);

//        EvalUnitExperimental evalUnit = new EvalUnitExperimental(Connection::getRDF4JConnector, server,
//                goldRepository, goldVocab, approximateRepository, apprVocab, evalOptSet, debug);

        long start = System.currentTimeMillis();
        evalUnit.evaluate();
        Date date = new Date((System.currentTimeMillis() - start));
        DateFormat formatter = new SimpleDateFormat("mm:ss:SSS");
        System.out.println("Duration: " + formatter.format(date) + " ms");
    }
}
