package de.uni_kiel.schemex.implementation.common;

import de.uni_kiel.schemex.common.IResource;

/**
 * This resource encapsulates a string. This string may represent names or uris
 * or anything representing a unique identifier
 * 
 * @author Bastian
 *
 */
public class StringResource implements IResource {

	private String res;

	/**
	 * Constructor
	 * @param resource The identifier to be encapsulated
	 */
	public StringResource(String resource) {
		this.res = resource;
	}

	@Override
	public int hashCode() {
		return res.hashCode();
	}

	@Override
	public String toString() {
		return res;
	}

	
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof StringResource)) {
			return false;
		}

		StringResource other = (StringResource) obj;

		return res.equals(other.res);
	}

	@Override
	public String toN3() {
		return "\"" + res + "\"";
	}
}
