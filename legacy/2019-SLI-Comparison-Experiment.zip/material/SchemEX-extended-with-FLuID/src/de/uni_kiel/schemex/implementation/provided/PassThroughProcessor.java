package de.uni_kiel.schemex.implementation.provided;

import java.util.ArrayList;
import java.util.List;

import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.interfaces.provided.IQuintProcessor;

/**
 * Simple processor which just passes on everything it gets
 * 
 * @author Bastian
 *
 */
public class PassThroughProcessor implements IQuintProcessor {

	@Override
	public List<IQuint> processQuint(IQuint q) {
		List<IQuint> list = new ArrayList<>();
		list.add(q);
		return list;
	}
}
