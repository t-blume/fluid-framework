package de.uni_kiel.schemex.implementation.required;

import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.implementation.common.Quad;
import de.uni_kiel.schemex.implementation.common.RDFInstance;
import de.uni_kiel.schemex.interfaces.provided.IElementCache;
import de.uni_kiel.schemex.interfaces.required.IQuintListener;


/**
 * Aggregates information of instances
 * 
 * @author Bastian
 * @editor Till
 */
public class InstanceAggregator implements IQuintListener {

	protected IElementCache<IInstanceElement> cache;
	protected final boolean useIncomingProps;

	/**
	 * Creates an InstanceAggregator which uses the given cache to store
	 * instances
	 * 
	 * @param cache
	 */
	public InstanceAggregator(IElementCache<IInstanceElement> cache) {
		this(cache, false);
	}
	public InstanceAggregator(IElementCache<IInstanceElement> cache, boolean useIncomingProps) {
		this.cache = cache;
		this.useIncomingProps = useIncomingProps;
	}

	@Override
	public void finishedQuint(IQuint i) {
		addQuint2Cache(i, true);
		//add incoming props as inverted props
		if(useIncomingProps)
			addQuint2Cache(new Quad(i.getObject(), i.getPredicate(), i.getSubject(), i.getContext()), false);

	}

	protected IInstanceElement createInstance(IQuint quint){
		return new RDFInstance(quint.getSubject());
	}

	protected void addQuint2Cache(IQuint quint, boolean asOutgoing){
		IInstanceElement element = createInstance(quint);
		if (cache.contains(element.getLocator()))
			element = cache.get(element.getLocator());
		else
			cache.add(element);

		if(asOutgoing)
			element.addOutgoingQuint(quint);
		else
			element.addIncomingQuint(quint);
	}

	@Override
	public void finished() {
		cache.close();
	}

}
