package de.uni_kiel.evaluation.vocabularies;


import java.util.Map;
import java.util.Set;

public interface VocabularyConstants {

    String NO_PROPERTY_OBJECT_CLUSTER();

    /**
     * A constant to give access to the Manchester OWL api representation of the class COMPLEXSCHEMAELEMENT.<p>
     */
    String CLASS_COMPLEX_SCHEMA_ELEMENT();

    /**
     * A constant to give access to the Manchester OWL api representation of the class OBJECTCLUSTER.<p>
     */
    String CLASS_OBJECT_CLUSTER();

    /**
     * A constant to give access to the Manchester OWL api representation of the class PROPERTYOBJECTCLUSTER.<p>
     */
    String CLASS_PROPERTY_OBJECT_CLUSTER();

    String CLASS_PROPERTY_CLUSTER();

    /**
     * A constant to give access to the Manchester OWL API representation of the object property HASOBJECTEQUIVALENCE.<p>
     */
    String HAS_OBJECT_EQUIVALENCE();

    /**
     * A constant to give access to the Manchester OWL API representation of the object property HASPAYLOADELEMENT.<p>
     */
    String HAS_PAYLOAD_ELEMENT();

    /**
     * A constant to give access to the Manchester OWL API representation of the object property HASPREDICATEEQUIVALENCE.<p>
     */
    String HAS_PREDICATE_EQUIVALENCE();

    /**
     * A constant to give access to the Manchester OWL API representation of the object property HASSUBJECTEQUIVALENCE.<p>
     */
    String HAS_SUBJECT_EQUIVALENCE();

    /**
     * A constant to give access to the Manchester OWL API representation of the object property ISOBJECTEQUIVALENCEOF.<p>
     */
    String IS_OBJECT_EQUIVALENCE_OF();

    /**
     * A constant to give access to the Manchester OWL API representation of the object property ISPREDICATEEQUIVALENCEOF.<p>
     */
    String IS_PREDICATE_EQUIVALENCE_OF();

    /**
     * A constant to give access to the Manchester OWL API representation of the object property ISSUBJECTEQUIVALENCEOF.<p>
     */
    String IS_SUBJECT_EQUIVALENCE_OF();

    /**
     * A constant to give access to the Manchester OWL API representation of the data property PAYLOAD.<p>
     */
    String PAYLOAD_INFORMATION();


    //TODO Comment all this functions
    String HAS_ATTRIBUTE();

    String UNRESOLVED_LITERAL_CLUSTER();

    String EMPTY_LITERAL_CLUSTER();

    String EMPTY_PROPERTIES_CLUSTER();

    String RDF_TYPE();

    String GET_LINK_OBJECT();

    String GET_TC_QUERY();

    String GET_OC_QUERY(String tc);

    String GET_OC(Set<String> types);


    String GET_DS_FROM_TYPES(Set<String> types);

    String GET_EQC_FROM_CLASSES(Set<String> classes);

    String QUERY_DS_VIA_EQC(String eqc);

    /**
     *
     * @param classes
     * @return
     */
    String QUERY_DS_VIA_CLASSES(Set<String> classes);

    /**
     * Creates a query which will return all the datasources associated with an object cluster.
     * @param tc Object Cluster
     * @return Query
     */
    String QUERY_DS_VIA_OC(String tc);

    /**
     * Gets the hash value from the Object Cluster.
     * @param oc Object Cluster URI
     * @return Hash Value
     */
    String GET_HASH_VALUE_FROM_OC(String oc);

    /**
     * Creates an Object Cluster URI with the specified HASH Value.
     * @param s Hash value
     * @return Object Cluster URI.
     */
    String CREATE_OC_VIA_HASH(String s);

    /**
     * Returns a query which gets the datasources of a property cluster with the specified properties.
     * @param properties List of properties for the property cluster.
     * @return Query which returns data sources.
     */
    String GET_DS_FROM_PROPERTIES(Set<String> properties);

    /**
     * This checks wether a property should be filtered out, depending on the vocabularies specification.
     * @param x Property
     * @return true --> should be filtered; false --> should not be filtered.
     */
    boolean IS_FILTER_PROPERTY(String x);

    /**
     * Returns a query which will get the attached property OC pairs.
     * @param objectPropertyPairs Map<X,Y> X: URI of property; Y: HASH Value of OC (can contain multiple types)
     * @return Query which returns the attached datasources
     */
    String GET_DS_FROM_PROPERTY_OBJECT_PAIRS(Set<Map<String, String>> objectPropertyPairs);

    /**
     * Creates a query which returns the attached properties of a Property Cluster.
     * @param pc URI of property Cluster.
     * @return SPARQL-Query
     */
    String GET_PROPERTIES_FROM_PC(String pc);

    /**
     * Creates a query which will get all the datasources associated with the Unresolved Literal Cluster
     * @return SPARQL-Query
     */
    String GET_DS_FROM_UNRESOLVED_LITERAL_CLUSTER();

    /**
     * Creates a query which will get all the datasources associated with the Empty Literal Cluster.
     * @return SPARQL-Query
     */
    String GET_DS_FROM_EMPTY_LITERAL_CLUSTER();

    /**
     * Creates a query which gets all the datasources associated with a no Property Object Cluster.
     * @return SPARQL-Query
     */
    String QUERY_DS_FROM_NO_PROPERTY_OBJECT_CLUSTER();

    /**
     *  Creates a query which will return all the Property - Object Cluster Pairs of property object cluster.
     * @param poc URI of Property Object Cluster
     * @return SPARQL-Query
     */
    String GET_PROPERTY_OBJECT_PAIRS(String poc);

    String QUERY_DS_FROM_PROPERTY_OBJECT_CLUSTER(String poc);

    /**
     * Creates a query which will return all the Object Cluster that exist.
     * @return SPARQL-Query
     */
    String GET_PROPERTY_OBJECT_CLUSTER();


    String CSE_CONSTRAINT_PC(String cseNode, Set<String> s);

    String CSE_CONSTRAINT_OC(String cseNode, String s);

    String CSE_CONSTRAINT_POC(String cseNode, Set<Map<String, String>> s);

    String CSE_CONSTRAINT_DS(String cseNode);

    /**
     * This function returns a query body which will give the cse, which have no cse above them.
     * This is considered a prime cse.
     * @return SPARQL-Query
     */
    String GET_PRIME_COMPLEX_SCHEMA_ELEMENTS();

    String GET_PC_FROM_CSE(String cseNode);

    String GET_OC_FROM_CSE(String cseNode);

    String GET_POC_FROM_CSE(String cseNode);

    String GET_CSE_FROM_CSE(String cseNode);

    String CSE_CONSTRAINT_CSE(String cseNode, String s);

    String CSE_CONSTRAINT_OC_UNRESOLVED_LITERAL_CLUSTER(String cseNode);

    String CSE_CONSTRAINT_OC_EMPTY_LITERAL_CLUSTER(String cseNode);

    String GET_HASH_VALUE_FROM_CSE(String cse);

    String CREATE_CSE_VIA_HASH(String o);

    String CSE_CONSTRAINT_NO_POC(String cseNodeEval);


    String GET_HASH_VALUE_FROM_POC(String poc);

    String QUERY_DS_VIA_PC(String pc);

    String GET_HASH_VALUE_FROM_PC(String pc);

    String GET_DS_FROM_EMPTY_PROPERTIES_CLUSTER();

    String QUERY_DS_VIA_CSE(String cse);
}
