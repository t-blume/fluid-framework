package de.uni_kiel.evaluation.vocabularies;


import de.uni_kiel.evaluation.utils.VariablesGenerator;

import java.util.*;

public class FLuIDVocabulary implements VocabularyConstants {

    VariablesGenerator generator = VariablesGenerator.getInstance();

    //this lists needs to be initialised
    private static String[] filterPropertyList = {"schemex", "west", "fluid"};

    public static final String NS = "http://www.fluid.informatik.uni-kiel.de/ontologies/2018/2/";
    public static final String NS_IMPL = "http://www.fluid-framework.informatik.uni-kiel.de/";

    //schema
    public static final String CLASS_COMPLEX_SCHEMA_ELEMENT = NS + "ComplexSchemaElement";
    public static final String CLASS_PROPERTY_CLUSTER = NS + "PropertyCluster";
    public static final String CLASS_PROPERTY_OBJECT_CLUSTER = NS + "PropertyObjectCluster";
    public static final String CLASS_OBJECT_CLUSTER = NS + "ObjectCluster";

    //paylaod
    public static final String CLASS_DATASOURCE_ELEMENT = NS + "DatasourceElement";
    public static final String CLASS_COUNT_ELEMENT = NS + "CountElement";
    public static final String CLASS_SNIPPET_ELEMENT = NS + "SnippetElement";


    //special objects
    public static final String UNRESOLVED_LITERAL_CLUSTER = NS + "ObjectCluster";
    public static final String EMPTY_OBJECTS = CLASS_OBJECT_CLUSTER + "NoObjects";
    public static final String EMPTY_PROPERTIES = CLASS_PROPERTY_CLUSTER + "NoProperties";

    //For what is this used
    public static final String EMPTY_PROPERTY_OBJECT = CLASS_PROPERTY_OBJECT_CLUSTER + "NoProperty-Objects";

    //blank node for storing Links
    public static final String CLASS_LINK_ELEMENT = NS_IMPL + "Link";
    public static final String getPropertyLink = NS + "getPropertyLink";
    public static final String getLinkObject = NS + "getLinkObject";

    //storing schema information
    public static final String hasAttribute = NS + "hasAttribute";

    //storing payload information
    public static final String hasPayload = NS + "hasPayload"; //the element
    public static final String payload = NS + "payload"; //the information

    //schema-level relationships
    public static final String isSubjectEquivalence = NS + "isSubjectEquivalenceOf";
    public static final String isPredicateEquivalence = NS + "isPredicateEquivalenceOf";
    public static final String isObjectEquivalence = NS + "isObjectEquivalenceOf";
    public static final String hasSubjectEquivalence = NS + "hasSubjectEquivalence";
    public static final String hasPredicateEquivalence = NS + "hasPredicateEquivalence";
    public static final String hasObjectEquivalence = NS + "hasObjectEquivalence";

    //Implementation detail for reading and writing
    public static final String abstractSchemaElementType = NS_IMPL + "abstractSchemaElementType";
    private String ls = " .\n";
    ;

    public String GET_PROPERTY_LINK() {
        return "<" + getPropertyLink + ">";
    }

    @Override
    public String NO_PROPERTY_OBJECT_CLUSTER() {
        return "<" + EMPTY_PROPERTY_OBJECT + ">";
    }

    @Override
    public String CLASS_COMPLEX_SCHEMA_ELEMENT() {
        return "<" + CLASS_COMPLEX_SCHEMA_ELEMENT + ">";
    }

    @Override
    public String CLASS_OBJECT_CLUSTER() {
        return "<" + CLASS_OBJECT_CLUSTER + ">";
    }

    @Override
    public String CLASS_PROPERTY_OBJECT_CLUSTER() {
        return "<" + CLASS_PROPERTY_OBJECT_CLUSTER + ">";
    }

    @Override
    public String CLASS_PROPERTY_CLUSTER() {
        return "<" + CLASS_PROPERTY_CLUSTER + ">";
    }

    @Override
    public String HAS_OBJECT_EQUIVALENCE() {
        return "<" + hasObjectEquivalence + ">";
    }

    @Override
    public String HAS_PAYLOAD_ELEMENT() {
        return "<" + hasPayload + ">";
    }

    @Override
    public String HAS_PREDICATE_EQUIVALENCE() {
        return "<" + hasPredicateEquivalence + ">";
    }

    @Override
    public String HAS_SUBJECT_EQUIVALENCE() {
        return "<" + hasSubjectEquivalence + ">";
    }

    @Override
    public String IS_OBJECT_EQUIVALENCE_OF() {
        return "<" + isObjectEquivalence + ">";
    }

    @Override
    public String IS_PREDICATE_EQUIVALENCE_OF() {
        return "<" + isPredicateEquivalence + ">";
    }

    @Override
    public String IS_SUBJECT_EQUIVALENCE_OF() {
        return "<" + isSubjectEquivalence + ">";
    }


    @Override
    public String PAYLOAD_INFORMATION() {
        return "<" + payload + ">";
    }

    @Override
    public String HAS_ATTRIBUTE() {
        return "<" + hasAttribute + ">";
    }


    @Override
    public String UNRESOLVED_LITERAL_CLUSTER() {
        return "<" + UNRESOLVED_LITERAL_CLUSTER + ">";
    }

    @Override
    public String EMPTY_LITERAL_CLUSTER() {
        return "<" + EMPTY_OBJECTS + ">";
    }

    @Override
    public String EMPTY_PROPERTIES_CLUSTER() {
        return "<" + EMPTY_PROPERTIES + ">";
    }

    @Override
    public String RDF_TYPE() {
        return "<" + "http://www.w3.org/1999/02/22-rdf-syntax-ns#type" + ">";
    }


    @Override
    public String GET_LINK_OBJECT() {
        return "<" + getLinkObject + ">";
    }

    @Override
    public String GET_TC_QUERY() {
        return "?eqc " + "<" + NS + "hasSubjectEquivalence> ?tc";
    }

    @Override
    public String GET_OC(Set<String> types) {

        // Find a tc which contains all the types
        String query = "";
        if (types.size() > 0) {
            int counter = 0;
            for (String s : types) {
                query += "?tc <" + hasAttribute + "> ?node" + counter + ".";
                query += " ?node" + counter + " <" + getLinkObject + "> <" + s + ">.";
                counter++;
            }
        } else
            query = "FILTER NOT EXISTS";


        return query;
    }

    ///////////////////////////////////////////////////
    /////////////////////USED//////////////////////////
    ///////////////////////////////////////////////////
    //CSE -------------------------------------------------------------

    @Override
    public String CSE_CONSTRAINT_PC(String cseNode, Set<String> s) {
        String cseNodeReal = cseNode.contains("http") ? "<" + cseNode + "> " : "" + cseNode + " ";

        String query = "";
        query += "" + cseNodeReal + " " + HAS_SUBJECT_EQUIVALENCE() + " ?pc" + ls;
        for (String p : s) {
            String node = " ?" + generator.getVariableName("node");

            query += "?pc " + HAS_ATTRIBUTE() + node;
            query += node + " " + GET_PROPERTY_LINK() + " <" + p + "> " + ls;


        }
        return query;
    }

    @Override
    public String CSE_CONSTRAINT_OC(String cseNode, String hashValue) {
        String cseNodeReal = cseNode.contains("http") ? "<" + cseNode + "> " : "" + cseNode + " ";

        String query = "" + cseNodeReal + " " + HAS_SUBJECT_EQUIVALENCE() + " <" + CREATE_OC_VIA_HASH(hashValue) + ">" + ls;
        return query;
    }

    @Override
    public String CSE_CONSTRAINT_OC_UNRESOLVED_LITERAL_CLUSTER(String cseNode) {
        String cseNodeReal = cseNode.contains("http") ? "<" + cseNode + "> " : "" + cseNode + " ";
        String query = "" + cseNodeReal + " " + HAS_SUBJECT_EQUIVALENCE() + " " + UNRESOLVED_LITERAL_CLUSTER() + ls;
        return query;
    }

    @Override
    public String CSE_CONSTRAINT_OC_EMPTY_LITERAL_CLUSTER(String cseNode) {
        String cseNodeReal = cseNode.contains("http") ? "<" + cseNode + "> " : "" + cseNode + " ";
        String query = "" + cseNodeReal + " " + HAS_SUBJECT_EQUIVALENCE() + " " + EMPTY_LITERAL_CLUSTER() + ls;
        return query;
    }


    @Override
    public String CSE_CONSTRAINT_POC(String cseNode, Set<Map<String, String>> s) {
        String cseNodeReal = cseNode.contains("http") ? "<" + cseNode + "> " : "" + cseNode + " ";
        String query = "";
        String poc = "?" + generator.getVariableName("poc");

        for (Map<String, String> map : s) {
            String property = map.keySet().stream().findFirst().get();
            String objectCluster = CREATE_OC_VIA_HASH(map.values().stream().findFirst().get());
            String node = "?" + generator.getVariableName("node");
            query += "" + cseNodeReal + " " + HAS_SUBJECT_EQUIVALENCE() + " " + poc + ls;
            query += poc + " " + HAS_ATTRIBUTE() + " " + node + ls;
            query += node + " " + GET_LINK_OBJECT() + " <" + objectCluster + ">" + ls;
            query += node + " " + GET_PROPERTY_LINK() + " <" + property + ">" + ls;
        }
        return query;
    }

    @Override
    public String CSE_CONSTRAINT_NO_POC(String cseNode) {
        String cseNodeReal = cseNode.contains("http") ? "<" + cseNode + "> " : "" + cseNode + " ";
        String query = "";
        query += "" + cseNodeReal + " " + HAS_SUBJECT_EQUIVALENCE() + " " + NO_PROPERTY_OBJECT_CLUSTER() + ls;
        return query;
    }




    @Override
    public String CSE_CONSTRAINT_CSE(String cseNode, String s) {
        String query = "";
        if (s.contains("http"))
            query += "<" + cseNode + "> " + HAS_SUBJECT_EQUIVALENCE() + " <" + s + ">";
         else
            query += "<" + cseNode + "> " + HAS_SUBJECT_EQUIVALENCE() + " " + s + "";

        return query;
    }

    @Override
    public String CSE_CONSTRAINT_DS(String cseNode) {
        String pay = "?" + generator.getVariableName("pay");
        String cseNodeReal = cseNode.contains("http") ? "<" + cseNode + "> " : "" + cseNode + " ";
        String query = cseNodeReal + HAS_PAYLOAD_ELEMENT() + " " + pay + ls +
                "?pay " + PAYLOAD_INFORMATION() + " ?ds.";

        return query;
    }


    @Override
    public String GET_PRIME_COMPLEX_SCHEMA_ELEMENTS() {
        ls = " .\n";
        String query = "?x " + RDF_TYPE() + " " + CLASS_COMPLEX_SCHEMA_ELEMENT() + ls;
        query += "FILTER (NOT EXISTS {?k " + HAS_SUBJECT_EQUIVALENCE() + "?x})";
        return query;
    }

    @Override
    public String GET_PC_FROM_CSE(String cseNode) {
        String ls = ".\n";
        String variable = "?" + generator.getVariableName("pc");
        String query = "<" + cseNode + "> " + HAS_SUBJECT_EQUIVALENCE() + " " + variable + ls;
        query += variable + " " + RDF_TYPE() + " " + CLASS_PROPERTY_CLUSTER();
        return query;
    }

    @Override
    public String GET_OC_FROM_CSE(String cseNode) {
        String ls = ".\n";
        String variable = "?" + generator.getVariableName("pc");
        String query = "<" + cseNode + "> " + HAS_SUBJECT_EQUIVALENCE() + " ?c" + ls;
        query += "?c " + RDF_TYPE() + " " + CLASS_OBJECT_CLUSTER();
        return query;
    }

    @Override
    public String GET_POC_FROM_CSE(String cseNode) {
        String ls = ".\n";
        String variable = "?" + generator.getVariableName("pc");
        String query = "<" + cseNode + "> " + HAS_SUBJECT_EQUIVALENCE() + " ?c" + ls;
        query += "?c " + RDF_TYPE() + " " + CLASS_PROPERTY_OBJECT_CLUSTER();
        return query;
    }

    @Override
    public String GET_CSE_FROM_CSE(String cseNode) {
        String ls = ".\n";
        String variable = "?" + generator.getVariableName("pc");
        String query = "<" + cseNode + "> " + HAS_SUBJECT_EQUIVALENCE() + " ?c" + ls;
        query += "?c " + RDF_TYPE() + " " + CLASS_COMPLEX_SCHEMA_ELEMENT();
        return query;
    }


    @Override
    public String GET_HASH_VALUE_FROM_CSE(String oc) {
        String result = oc.replace("<", "").replace(">", "");
        result = result.replace(CLASS_COMPLEX_SCHEMA_ELEMENT, "");
        return result;
    }

    @Override
    public String CREATE_CSE_VIA_HASH(String s) {
        String result = CLASS_COMPLEX_SCHEMA_ELEMENT + s;
        return result;
    }

    @Override
    public String QUERY_DS_VIA_CSE(String cse) {
        String query = cse+" " + HAS_PAYLOAD_ELEMENT() + " ?pay" + ls +
                "?pay " + PAYLOAD_INFORMATION() + " ?ds.";
        return query;
    }


    //PC --------------------------------------------------------------
    @Override
    public String GET_PROPERTIES_FROM_PC(String pc) {
        String query = "<" + pc + "> ?p " + " []"; //UNRESOLVED_LITERAL_CLUSTER(); //TODO make list for stuff for Till
        return query;
    }


    @Override
    public String QUERY_DS_VIA_PC(String pc) {
        String query =  "?cse " + HAS_SUBJECT_EQUIVALENCE() + " "+ pc+ ".\n" +
                "?cse " + HAS_PAYLOAD_ELEMENT() + " ?pay.\n" +
                "?pay " + PAYLOAD_INFORMATION() + " ?ds.";
        return query;
    }

    @Override
    public String GET_HASH_VALUE_FROM_PC(String pc) {
        String result = pc.replace("<", "").replace(">", "");
        result = result.replace(CLASS_PROPERTY_CLUSTER(), "");
        return result;
    }

    @Override
    public String GET_DS_FROM_EMPTY_PROPERTIES_CLUSTER() {
        String query = "?cse " + HAS_SUBJECT_EQUIVALENCE() + " " + EMPTY_PROPERTIES_CLUSTER() + " .\n" +
                "?cse " + HAS_PAYLOAD_ELEMENT() + " ?pay.\n" +
                "?pay " + PAYLOAD_INFORMATION() + " ?ds.";

        return query;
    }



    @Override
    public String GET_DS_FROM_PROPERTIES(Set<String> properties) {

        String resultQuery = "";
        int i = 0;
        for (String s : properties) {
            resultQuery += "?node" + i + " " + GET_PROPERTY_LINK() + " <" + s + ">.\n";
            resultQuery += "?poc " + HAS_ATTRIBUTE() + " ?node" + i + ".\n";
            i++;

        }
        resultQuery +=
                "?cse " + HAS_SUBJECT_EQUIVALENCE() + " ?poc.\n" +
                        "?cse " + HAS_PAYLOAD_ELEMENT() + " ?pay.\n" +
                        "?pay " + PAYLOAD_INFORMATION() + " ?ds.";


        return resultQuery;
    }

    @Override
    public boolean IS_FILTER_PROPERTY(String x) {
        if (Arrays.stream(filterPropertyList).parallel().anyMatch(x::contains))
            return true;

        return false;
    }


    //POC --------------------------------------------------------------
    @Override
    public String QUERY_DS_FROM_NO_PROPERTY_OBJECT_CLUSTER() {
        String query = "?cse " + HAS_SUBJECT_EQUIVALENCE() + " " + NO_PROPERTY_OBJECT_CLUSTER() + " .\n" +
                "?cse " + HAS_PAYLOAD_ELEMENT() + " ?pay.\n" +
                "?pay " + PAYLOAD_INFORMATION() + " ?ds.";

        return query;
    }

    @Override
    public String QUERY_DS_FROM_PROPERTY_OBJECT_CLUSTER(String poc) {

        String query = "?cse " + HAS_SUBJECT_EQUIVALENCE() + " " + poc + " .\n" +
                "?cse " + HAS_PAYLOAD_ELEMENT() + " ?pay.\n" +
                "?pay " + PAYLOAD_INFORMATION() + " ?ds.";

        return query;

    }

    @Override
    public String GET_HASH_VALUE_FROM_POC(String poc) {
        String result = poc.replace("<", "").replace(">", "");
        result = result.replace(CLASS_PROPERTY_OBJECT_CLUSTER(), "");
        return result;
    }



    @Override
    public String GET_PROPERTY_OBJECT_CLUSTER() {

        String query = "?x" + " " + RDF_TYPE() + " " + CLASS_PROPERTY_OBJECT_CLUSTER() + ls;

        //add Filter param:
        return query;
    }



    @Override
    public String GET_PROPERTY_OBJECT_PAIRS(String poc) {
        String query = "<" + poc + ">" + HAS_ATTRIBUTE() + "?node.\n" +
                "?node " + GET_PROPERTY_LINK() + " ?prop.\n" +
                "?node " + GET_LINK_OBJECT() + " ?obj.";
        return query;
    }

    @Override
    public String GET_DS_FROM_PROPERTY_OBJECT_PAIRS(Set<Map<String, String>> propertyObjectPairs) {
        String poc = "?poc";
        String cse = "?cse";
        String pay = "?pay";
        String ds = "?ds";
        String ls = ". \n";
        String query = "";

        int i = 0;
        for (Map<String, String> m : propertyObjectPairs) {
            String node = "?node" + i;
            query += poc + " " + HAS_ATTRIBUTE() + " " + node + "" + ls;
            Collection<String> object = m.values();
            Collection<String> property = m.keySet();
            //ADD OC-URI
            if (object.size() > 0) {
                String uri = CREATE_OC_VIA_HASH(object.stream().findFirst().get());
                query += node + " " + GET_LINK_OBJECT() + " " + "<" + uri + ">" + ls;
            }  //currently these pairs should only have a 1:1 connection
            //ADD property
            if (property.size() > 0)
                query += node + " " + GET_PROPERTY_LINK() + " " + "<" + property.stream().findFirst().get() + ">" + ls; //currently these pairs should only have a 1:1 connection

            i++;
        }
        query += cse + " " + HAS_SUBJECT_EQUIVALENCE() + " " + poc + ls;
        query += cse + " " + HAS_PAYLOAD_ELEMENT() + " " + pay + ls;
        query += pay + " " + PAYLOAD_INFORMATION() + " " + ds;
        return query;
    }

    //OC --------------------------------------------------------------
    @Override
    public String GET_HASH_VALUE_FROM_OC(String oc) { //TODO
        String result = oc.replace("<", "").replace(">", "");
        result = result.replace(CLASS_OBJECT_CLUSTER, "");
        return result;
    }

    @Override
    public String CREATE_OC_VIA_HASH(String s) {
        String result = "http://www.fluid.informatik.uni-kiel.de/ontologies/2018/2/ObjectCluster" + s;
        return result;
    }


    @Override
    public String GET_DS_FROM_UNRESOLVED_LITERAL_CLUSTER() {
        //FIXME FALSCH
        String query = "?node \n" +
                GET_LINK_OBJECT() + "\n" +
                UNRESOLVED_LITERAL_CLUSTER() + ".\n" +
                "?cluster\n" +
                HAS_ATTRIBUTE() + "\n" +
                "?node.\n" +
                "?cse " + HAS_SUBJECT_EQUIVALENCE() + " ?cluster.\n" +
                "?cse " + HAS_PAYLOAD_ELEMENT() + " ?pay.\n" +
                "?pay " + PAYLOAD_INFORMATION() + " ?ds.";
        return query;
    }

    @Override
    public String GET_DS_FROM_EMPTY_LITERAL_CLUSTER() {
        String query = "?cse " + HAS_SUBJECT_EQUIVALENCE() + " " + EMPTY_LITERAL_CLUSTER() + " .\n" +
                "?cse " + HAS_PAYLOAD_ELEMENT() + " ?pay.\n" +
                "?pay " + PAYLOAD_INFORMATION() + " ?ds.";

        return query;
    }

    @Override
    public String GET_OC_QUERY(String tc) {
        String query = "<" + tc + ">" + HAS_ATTRIBUTE() + "?node" + ls;
        query += "?node " + GET_LINK_OBJECT() + " " + "?type";
        return query;
    }

    @Override
    public String GET_DS_FROM_TYPES(Set<String> types) {
        String typeQueryEval = "{\n";
        char var = 'a';
        for (String type : types) {

            typeQueryEval += "?tc " + HAS_ATTRIBUTE() + " ?" + var + " .\n";
            typeQueryEval += "?" + var + " " + GET_LINK_OBJECT() + " <" + type + ">" + " .\n";
            var++;

        }
        typeQueryEval += "?eqc " + HAS_SUBJECT_EQUIVALENCE() + " ?tc .\n";

        //get connected payload element
        typeQueryEval += "?eqc " + HAS_PAYLOAD_ELEMENT() + " ?pe .\n";

        //get connected data sources
        typeQueryEval += "?pe " + PAYLOAD_INFORMATION() + " ?ds .\n";

        typeQueryEval += "}\n";

        return typeQueryEval;

    }

    @Override
    public String QUERY_DS_VIA_OC(String tc) {
        String queryEval = "{ ?eqc " + HAS_SUBJECT_EQUIVALENCE() + " <" + tc + "> .\n";
        queryEval += "?eqc " + HAS_PAYLOAD_ELEMENT() + " ?pe .\n";
        queryEval += "?pe " + PAYLOAD_INFORMATION() + " ?ds .\n";

        queryEval += "}\n";

        return queryEval;
    }


    ////////////////////////////////////////////
    ////////////////////OLD/////////////////////
    ////////////////////////////////////////////


    @Override
    public String QUERY_DS_VIA_CLASSES(Set<String> classes) {
        if (classes.size() < 1)
            return "{<http://www.noexist.asd> a <http://nichtCLass>";
        String query = "";
        Iterator<String> iterator = classes.iterator();
        while (iterator.hasNext()) {
            String classi = iterator.next();
            query += "{?node " + GET_LINK_OBJECT() + " <" + classi + ">.\n";
        }
        query +=
                " ?cluster\n" +
                        HAS_ATTRIBUTE() + " ?node.\n" +
                        " ?eqc\n" +
                        HAS_SUBJECT_EQUIVALENCE() + " ?cluster.\n" +
                        "?eqc " + HAS_PAYLOAD_ELEMENT() + " ?dse.\n" +
                        " ?dse " + PAYLOAD_INFORMATION() + " ?ds}";
        return query;
    }

    @Override
    public String GET_EQC_FROM_CLASSES(Set<String> classes) {
        String query = "<http://wontwork.de> a <www.bratwurst>";
        if (classes.size() > 0) {

            query = "{";
            for (String s : classes) {
                query += "?node\n" + GET_LINK_OBJECT() +
                        " <" + s + ">.\n";
            }

            query += " ?cluster\n" +
                    HAS_ATTRIBUTE() +
                    " ?node.\n" +
                    " ?eqc\n" +
                    HAS_SUBJECT_EQUIVALENCE() +
                    " ?cluster.\n ?eqc" +
                    HAS_PAYLOAD_ELEMENT() +
                    " ?dse.\n" +
                    " ?dse " + PAYLOAD_INFORMATION() + " ?ds}";
        }

        return query;
    }

    @Override
    public String QUERY_DS_VIA_EQC(String eqc) {
        String query = "<" + eqc + ">" + HAS_PAYLOAD_ELEMENT() + " ?dse.\n" +
                "?dse " + PAYLOAD_INFORMATION() + " ?ds";

        return query;
    }
}
