package de.uni_kiel.evaluation.eval;


import de.uni_kiel.evaluation.connectors.Connection;
import de.uni_kiel.evaluation.connectors.Connector;
import de.uni_kiel.evaluation.utils.datastructs.EvalValueArray;
import de.uni_kiel.evaluation.utils.datastructs.SetSet;
import de.uni_kiel.evaluation.utils.datastructs.ValueArray;
import de.uni_kiel.schemex.implementation.schemex.required.writer.utils.WriterVocabulary;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import static de.uni_kiel.evaluation.connectors.Connection.DISTINCT;
import static de.uni_kiel.evaluation.connectors.Connection.QueryType.SELECT;
import static de.uni_kiel.schemex.utils.BasicUtils.printProgress;
import static de.uni_kiel.schemex.utils.Constants.RDF_TYPE;

/**
 * Created by Blume Till on 22.08.2016.
 */
public class EvalUnit {
    private static final int interval = 1500;
    //db stuff
    private Connection.DBConnection dbConnection;
    private final String url;
    private final String graphGold;
    private final String graphEval;

    //TODO: not needed?
    private ValueArray precision_predicates = new ValueArray();
    private ValueArray recall_predicates = new ValueArray();

    //eval stuff
    private EvalValueArray evalType = new EvalValueArray();
    private EvalValueArray evalTCSupTC = new EvalValueArray();
    private List<String> queriesTCSupTC = new LinkedList<>();
    private EvalValueArray evalTC = new EvalValueArray();
    private EvalValueArray evalEQC = new EvalValueArray();
    private EvalValueArray evalEQCaTC = new EvalValueArray();
    private List<String> queriesEQCaTC = new LinkedList<>();

    private EvalValueArray evalEQCSupEQC = new EvalValueArray();

    //optimizations
    private Set<String> typeClusterURIs = null;
    private Set<String> equiClassesURIs = null;


    private WriterVocabulary vocabulary;

    public EvalUnit(Connection.DBConnection dbConnection, String url, String graphGold, String graphEval,
                    WriterVocabulary vocabulary) {
        this.dbConnection = dbConnection;
        this.graphGold = graphGold;
        this.graphEval = graphEval;
        this.url = url;
        this.vocabulary = vocabulary;
    }

    public void evaluate() {
        Set<String> typeCluster = evalTCSupTC();
        evalTC();
        evalTypes(typeCluster);
        evalEQCaTC();
        evalEQC();
        //evalEQCSupEQC();
        evalTCSupTC.toFile("out/" + graphEval + "/TC_subTC.csv");
        evalTC.toFile("out/" + graphEval + "/TC.csv");
        evalType.toFile("out/" + graphEval + "/Types.csv");
        evalEQC.toFile("out/" + graphEval + "/EQC.csv");
        evalEQCaTC.toFile("out/" + graphEval + "/EQC_TC.csv");
        // evalEQCSupEQC.toFile("out/" + graphEval + "/EQC_subEQC.csv");


        //export queries
        Path simpleFile = Paths.get("SimpleQueries.txt");
        Path complexFile = Paths.get("ComplexQueries.txt");
        try {
            Files.write(simpleFile, queriesTCSupTC, Charset.forName("UTF-8"));
            Files.write(complexFile, queriesEQCaTC, Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Set<String> getTC_URIs() {
        if (typeClusterURIs == null) {
            Connector conGold = dbConnection.getConnector(url, graphGold);
            typeClusterURIs = queryDatasource(conGold, "?tc" + " <" + RDF_TYPE + "> <" +
                    vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TYPE) + "> .");
            System.out.println("Number Of TypeCluster: " + typeClusterURIs.size());
//            if(FILTER){
//                filter( typeClusterURIs, TC_NOTYPE + "|" + TC_UNRESOLVED);
//                System.out.println("Number Of Filtered TypeCluster: " + typeClusterURIs.size());
//            }
        }
        return typeClusterURIs;
    }

    public Set<String> getEQC_URIs() {
        if (equiClassesURIs == null) {
            Connector conGold = dbConnection.getConnector(url, graphGold);
            equiClassesURIs = queryDatasource(conGold, "?eqc" + " <" + RDF_TYPE + "> <" +
                    vocabulary.getEntry(WriterVocabulary.EQUIVALENCECLASS_TYPE) + "> .");
            System.out.println("Number Of EquivalenceClasses: " + equiClassesURIs.size());
//            String unresolvedTCQuery = "?eqc" + " " + type_RES + " " + EQC_RES + " ." +
//                    TC_UNRESOLVED_RES + " " + hasSubset_RES +  "?eqc .";
//
//            String noTypeTCQuery = "?eqc" + " " + type_RES + " " + EQC_RES + " ." +
//                    TC_NOTYPE_RES + " " + hasSubset_RES +  "?eqc .";

            //equiClassesURIs.removeAll(queryDatasource(conGold, unresolvedTCQuery));
            //equiClassesURIs.removeAll(queryDatasource(conGold, noTypeTCQuery));

//            System.out.println(equiClassesURIs.size());
        }
        return equiClassesURIs;
    }

    public SetSet getTC_TS() {
        Connector connector = dbConnection.getConnector(url, graphGold);
        SetSet setSet = new SetSet();
        for (String tc : getTC_URIs())
            setSet.add(queryDatasource(connector, "<" + tc + "> <" +
                    vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE) + "> ?c"));
        connector.close();
        return setSet;
    }

    /**
     * Evaluate according to original implementation from Mattias Konrad:
     * <p>
     * Get all type cluster by querying the connected types and
     * compare all the data sources connected to all the equivalent classes:
     * <p>
     * Example:     ?tc <hasClass> ClassA .
     * ?tc <hasClass> ClassB .
     * ?tc <hasSubset> ?eqc .
     * ?eqc <hasDataset> ?ds .
     * <p>
     * Returns a distinct set of types used
     */
    public Set<String> evalTCSupTC() {
        System.out.println("_______________");
        System.out.println("TC incl. Sub-TC");
        //getAll all the correct type cluster
        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        //Distinct set of types
        Set<String> types = new HashSet<>();

        int i = 1;
        int size = getTC_URIs().size();
        long start = System.currentTimeMillis();

        //iterate over all type cluster
        for (String tc : getTC_URIs()) {
            //debug
            long t = printProgress(i, size, interval, start);
            start = t > 0 ? t : start;

            //getAll corresponding typeset
            Set<String> typesGold = queryDatasource(conGold, "<" + tc + "> <" +
                    vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE) + "> ?c", "c");
            //add types to result set
            types.addAll(typesGold);
            /////build query

            //tc has to have all types
            String typeQueryGold = "{\n";
            String typeQueryEval = "{\n";
            for (String type : typesGold) {
                typeQueryGold += "?tc <" + vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE) +
                        "> <" + type + "> .\n";

                typeQueryEval += "?tc <" + vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TO_TYPE) +
                        "> <" + type + "> .\n";
            }
            //tc has to have a connected eqc
            typeQueryGold += "?tc <" + vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TO_EQC) + "> ?eqc .\n";
            typeQueryEval += "?tc <" + vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TO_EQC) + "> ?eqc .\n";

            //get connected payload element
            typeQueryGold += "?eqc <" + vocabulary.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET)
                    + "> ?pe .\n";
            typeQueryEval += "?eqc <" + vocabulary.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET)
                    + "> ?pe .\n";

            //get connected data sources
            typeQueryGold += "?pe <" + vocabulary.getEntry(WriterVocabulary.LINKSET_TO_CONTEXT)  + "> ?ds .\n";
            typeQueryEval += "?pe <" + vocabulary.getEntry(WriterVocabulary.LINKSET_TO_CONTEXT)  + "> ?ds .\n";

            typeQueryGold += "}\n";
            typeQueryEval += "}\n";
            //get all tc who have at least those types and compare the connected data sources
//            Comparator comp = queryDatasources(conGold, conEval, typeQueryGold, "ds");
            Set<String> setGold = queryDatasource(conGold, typeQueryGold, "ds");
            Set<String> setEval = queryDatasource(conEval, typeQueryEval, "ds");
            Comparator comp = new Comparator(setGold, setEval);
            //add to result lists
            evalTCSupTC.addResult(comp);
            i++;
            //Save query for export
            queriesTCSupTC.add(typeQueryEval);

//            if(comp.getMssing().size() > 0 || comp.getWrong().size() > 0){
//                System.out.println("GOLD QUERY:\n" + typeQueryGold);
//                System.out.println("EVAL QUERY:\n" + typeQueryEval);
//                System.out.println("GOLD DS: " + setGold);
//                System.out.println("EVAL DS: " + setEval);
//            }
//            if(comp.getMssing().size() > 0)
//                System.out.println("Missing: " + comp.getMssing());
//
//            if(comp.getWrong().size() > 0)
//                System.out.println("Wrong: " + comp.getWrong());
        }


        conEval.close();
        conGold.close();
        System.out.println("Precision;Recall;F1");
        System.out.println(evalTCSupTC.average());

        //return distinct set of types
        return types;
    }

    /**
     * Evaluate according to original implementation from Mattias Konrad:
     * <p>
     * For each TC (URI) get all connected EQCs and
     * compare the connected data sources
     */
    public void evalTC() {
        System.out.println("_______________");
        System.out.println("TC");

        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        int i = 1;
        int size = getTC_URIs().size();
        long start = System.currentTimeMillis();

        for (String tc : getTC_URIs()) {
            //TODO: debug
            if (tc.equals(vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_UNRESOLVED).replaceAll("<|>", ""))) {
                System.out.println("Yeah!");
                continue;
            }

            long t = printProgress(i, size, interval, start);
            start = t > 0 ? t : start;
            //get connected eqc
            String queryGold = "{ <" + tc + "> <" + vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TO_EQC) + "> ?eqc .\n";
            String queryEval = "{ <" + tc + "> <" + vocabulary.getEntry(WriterVocabulary.TYPECLUSTER_TO_EQC) + "> ?eqc .\n";;

            //get connected payload element
            queryGold += "?eqc <" + vocabulary.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET)
                    + "> ?pe .\n";
            queryEval += "?eqc <" + vocabulary.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET)
                    + "> ?pe .\n";

            //get connected data sources
            queryGold += "?pe <" + vocabulary.getEntry(WriterVocabulary.LINKSET_TO_CONTEXT)  + "> ?ds .\n";
            queryEval += "?pe <" + vocabulary.getEntry(WriterVocabulary.LINKSET_TO_CONTEXT)  + "> ?ds .\n";

            queryGold += "}\n";
            queryEval += "}\n";
//            Comparator comp = queryDatasources(conGold, conEval, queryGold, "ds");
            Set<String> setGold = queryDatasource(conGold, queryGold, "ds");
            Set<String> setEval = queryDatasource(conEval, queryEval, "ds");
            Comparator comp = new Comparator(setGold, setEval);

            evalTC.addResult(comp);
            i++;
//            if (comp.getMssing().size() > 0 || comp.getWrong().size() > 0) {
//                System.out.println("GOLD QUERY:\n" + queryGold);
//                System.out.println("EVAL QUERY:\n" + queryEval);
//                System.out.println("GOLD DS: " + setGold);
//                System.out.println("EVAL DS: " + setEval);
//            }
//            if (comp.getMssing().size() > 0)
//                System.out.println("Missing: " + comp.getMssing());
//
//            if (comp.getWrong().size() > 0)
//                System.out.println("Wrong: " + comp.getWrong());

        }
        conEval.close();
        conGold.close();

        System.out.println("Precision;Recall;F1");
        System.out.println(evalTC.average());


    }

    /**
     * Evaluate according to original implementation from Mattias Konrad
     * <p>
     * For each type seen, get all the connected type clusters and
     * compare all the data sources connected to all the equivalent classes:
     * <p>
     * Example:     ?tc <hasClass> ClassA .
     * ?tc <hasSubset> ?eqc .
     * ?eqc <hasDataset> ?ds .
     *
     * @param types
     */
    public void evalTypes(Set<String> types) {
//        System.out.println("_______________");
//        System.out.println("Types");
//        Connector conGold = dbConnection.getConnector(url, graphGold);
//        Connector conEval = dbConnection.getConnector(url, graphEval);
//
//        int i = 1;
//        int size = types.size();
//        long start = System.currentTimeMillis();
//
//        for (String type : types) {
//            long t = printProgress(i, size, interval, start);
//            start = t > 0 ? t : start;
//            String queryGold = "{ ?tc " + vocabularyConstantsGold.DATA_PROPERTY_HASOBJECT() + " <" + type + ">" + " .\n";
//            String queryEval;
//            if (vocabularyConstantsEval instanceof FLuIDVocabulary) {
//                queryEval = "{ ?tc " + vocabularyConstantsEval.DATA_PROPERTY_HASATTRIBUTE() + " ?a" + " .\n";
//                queryEval += "?a " + vocabularyConstantsEval.DATA_PROPERTY_HASOBJECT() + " <" + type + ">" + " .\n";
//
//            } else
//                queryEval = "{ ?tc " + vocabularyConstantsEval.DATA_PROPERTY_HASOBJECT() + " <" + type + ">" + " .\n";
//
//
//            //tc has to have a connected eqc
//            queryGold += "?tc " + vocabularyConstantsGold.OBJECT_PROPERTY_ISSUBJECTEQUIVALENCEOF() + " ?eqc .\n";
//            //TMP QUICKFIX: TODO REMOVE MEW
//            if (!(vocabularyConstantsEval instanceof SchemEXVocabulary))
//                queryEval += "?eqc " + vocabularyConstantsEval.OBJECT_PROPERTY_HASSUBJECTEQUIVALENCE() + " ?tc .\n";
//            else
//                queryEval += "?tc " + vocabularyConstantsEval.OBJECT_PROPERTY_ISSUBJECTEQUIVALENCEOF() + " ?eqc .\n";
//
//            //get connected data sources
//            queryGold += "?eqc " + vocabularyConstantsGold.OBJECT_PROPERTY_HASPAYLOADELEMENT() + " ?pe .\n";
//            queryEval += "?eqc " + vocabularyConstantsEval.OBJECT_PROPERTY_HASPAYLOADELEMENT() + " ?pe .\n";
//
//            queryGold += "?pe " + vocabularyConstantsGold.DATA_PROPERTY_PAYLOAD() + " ?ds .\n";
//            queryEval += "?pe " + vocabularyConstantsEval.DATA_PROPERTY_PAYLOAD() + " ?ds .\n";
//
//            queryGold += "}\n";
//            queryEval += "}\n";
//
////            if(t > 0)
////                System.out.println(query);
////            Comparator comp = queryDatasources(conGold, conEval, queryGold, "ds");
//            Set<String> setGold = queryDatasource(conGold, queryGold, "ds");
//            Set<String> setEval = queryDatasource(conEval, queryEval, "ds");
//            Comparator comp = new Comparator(setGold, setEval);
////            if(comp.precision() < 1.0)
////                System.out.println(query);
//
//            evalType.addResult(comp);
//            i++;
//
//            if (comp.getMssing().size() > 0 || comp.getWrong().size() > 0) {
//                System.out.println("GOLD QUERY:\n" + queryGold);
//                System.out.println("EVAL QUERY:\n" + queryEval);
//                System.out.println("GOLD DS: " + setGold);
//                System.out.println("EVAL DS: " + setEval);
//            }
//            if (comp.getMssing().size() > 0)
//                System.out.println("Missing: " + comp.getMssing());
//
//            if (comp.getWrong().size() > 0)
//                System.out.println("Wrong: " + comp.getWrong());
//        }
//        conEval.close();
//        conGold.close();
//
//        System.out.println("Precision;Recall;F1");
//        System.out.println(evalType.average());
    }

    /**
     * Evaluate according to original implementation from Mattias Konrad
     * <p>
     * For each EQC (URI) compare the connected data sources
     */
    public void evalEQC() {
        System.out.println("_______________");
        System.out.println("EQC");
        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);


        int i = 1;
        int size = getEQC_URIs().size();
        long start = System.currentTimeMillis();

        for (String eqc : getEQC_URIs()) {
            long t = printProgress(i, size, interval, start);
            start = t > 0 ? t : start;

            String eqcEval = eqc;


            //get connected payload element
            String queryGold = "<" + eqc + "> <" + vocabulary.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET)
                    + "> ?pe .\n";
            String queryEval = "<" + eqc + "> <" + vocabulary.getEntry(WriterVocabulary.EQUIVALENCECLASS_TO_LINKSET)
                    + "> ?pe .\n";

            //get connected data sources
            queryGold += "?pe <" + vocabulary.getEntry(WriterVocabulary.LINKSET_TO_CONTEXT) + "> ?ds .\n";
            queryEval += "?pe <" + vocabulary.getEntry(WriterVocabulary.LINKSET_TO_CONTEXT) + "> ?ds .\n";

//            Comparator comp = queryDatasources(conGold, conEval, , "ds");
            Set<String> setGold = queryDatasource(conGold, queryGold, "ds");
            Set<String> setEval = queryDatasource(conEval, queryEval, "ds");
            Comparator comp = new Comparator(setGold, setEval);

            evalEQC.addResult(comp);
            i++;
        }
        conEval.close();
        conGold.close();

        System.out.println("Precision;Recall;F1");
        System.out.println(evalEQC.average());
    }

    /**
     * Evaluate according to original implementation from Mattias Konrad
     * <p>
     * For each EQC (URI) compare the connected properties and their objects
     */
    public void evalEQCaTC() {
        System.out.println("_______________");
        System.out.println("EQC + TC");
        int unresolvedGold = 0;
        int unresolvedEval = 0;
        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        int i = 1;
        int size = getEQC_URIs().size();
        long start = System.currentTimeMillis();


        //iterate over all type cluster
        for (String eqc : getEQC_URIs()) {
            //debug
            long t = printProgress(i, size, interval, start);
            start = t > 0 ? t : start;
            //getAll corresponding properties and objects
            String queryGold = "<" + eqc + "> ?p ?o .\n";

            queryGold += "FILTER (!strstarts(str(?p), \"http://schemex.west.uni-koblenz.de\"))";


            Set<String> propertiesGold = queryDatasource(conGold, queryGold, "p", "o");
            //filter types TODO: should be done here?
            //filter(propertiesGold, type + ".*");
            //filter datasets
            //filter(propertiesGold, hasDataset + ".*");
            //filter entityCount TODO: fix in SchemEX
            //filter(propertiesGold, entityCount + ".*");
            //filter not resolvable ranges
            //unresolvedGold += filter(propertiesGold, ".*http://schemex.west.uni-koblenz.de/tcNotResolvable").size();
            //getAll corresponding properties and objects

            String eqcEval = eqc;
            String queryEval = "<" + eqcEval + "> ?p ?o .\n";
            queryEval += "FILTER (!strstarts(str(?p), \"http://schemex.west.uni-koblenz.de\"))";



            //queryDatasourceDiffVars
            Set<String> propertiesEval = queryDatasource(conEval, queryEval, "p", "o");
            //filter(propertiesEval, entityCount + ".*");
            //filter not resolvable ranges
            //unresolvedEval += filter(propertiesEval, ".*http://schemex.west.uni-koblenz.de/tcNotResolvable").size();
            Comparator comp = new Comparator(propertiesGold, propertiesEval);
            //add to result lists
            evalEQCaTC.addResult(comp);
            i++;


        }
        conGold.close();
        conEval.close();
        System.out.println("Unresolved Gold: " + unresolvedGold);
        System.out.println("Unresolved Eval: " + unresolvedEval);
        System.out.println("Precision;Recall;F1");
        System.out.println(evalEQCaTC.average());

    }

    /**
     * Newly added query type by Till Blume
     * <p>
     * FIXME: Very time consuming
     * <p>
     * Get all EQCs by querying the connected properties and
     * compare all the data sources connected to all the equivalent classes:
     * <p>
     * Example:     ?eqc propertyA [] .
     * ?eqc propertyB [] .
     * ?eqc <hasDataset> ?ds .
     * <p>
     * Returns a distinct set of types used
     */
    public void evalEQCSupEQC() {
//        System.out.println("_______________");
//        System.out.println("EQC incl. Sup-EQC");
//        int types = 0;
//        int counts = 0;
//        int datasets = 0;
//        int unresolved = 0;
//
//        int notFiltered = 0;
//        Connector conGold = dbConnection.getConnector(url, graphGold);
//        Connector conEval = dbConnection.getConnector(url, graphEval);
//
//        int i = 1;
//        int size = getEQC_URIs().size();
//        long start = System.currentTimeMillis();
//
//
//        //iterate over all type cluster
//        for (String eqc : getEQC_URIs()) {
//            //debug
//            long t = printProgress(i, size, interval, start);
//            start = t > 0 ? t : start;
//
//
//            //getAll
//            Set<Map<String, String>> resultSetGold = queryDatasourceDiffVars(conGold, "<" + eqc + "> ?p ?o .", "p", "o");
//
//            Map<String, String> propertyObjects = new HashMap<>();
//            Set<String> propertySet = new TreeSet<>();
//            resultSetGold.forEach(MAP -> {
//                if (!MAP.get("p").equals(vocabularyConstantsGold.RDF_TYPE().getIRI().toString())) {
//                    if (!MAP.get("p").startsWith("http://schemex.west.uni-koblenz.de/")) {
//                        propertyObjects.put(MAP.get("p"), MAP.get("o").replace("http://schemex.west.uni-koblenz.de/", FLuIDVocabulary.NS));
//                        propertySet.add(MAP.get("p"));
//                    }
//
//                }
//            });
//            //System.out.println(propertySet);
//            Set<String> subjectCluster = queryDatasource(conGold, "?tc" + vocabularyConstantsGold.OBJECT_PROPERTY_ISSUBJECTEQUIVALENCEOF() + "<" + eqc + "> .");
//            String scGold = subjectCluster.iterator().next();
//            String scEval = scGold;
//            if (!(vocabularyConstantsEval instanceof SchemEXVocabulary)) {
//                scEval = scEval.replaceAll("http://schemex.west.uni-koblenz.de/tc", vocabularyConstantsEval.CLASS_OBJECTCLUSTER().getIRI().toString());
//                scEval = scEval.replaceAll("NoTypes", "NoObjects");
//            }
//            String queryGold = "{ <" + scGold + ">" + vocabularyConstantsGold.OBJECT_PROPERTY_ISSUBJECTEQUIVALENCEOF() + " ?eqc .\n";
//            String queryEval = "{ <" + scEval + ">" + vocabularyConstantsEval.OBJECT_PROPERTY_ISSUBJECTEQUIVALENCEOF() + " ?eqc .\n";
//            char var = 'a';
//            String prefix = "";
//
//            for (Map.Entry<String, String> link : propertyObjects.entrySet()) {
////            for(String property : propertySet){
//                queryGold += " ?eqc <" + link.getKey() + ">" + " [] .\n";
//                //FIXME for proper evaluation, only cosmetic
//
//                if (!(vocabularyConstantsEval instanceof SchemEXVocabulary)) {
//                    queryEval += "?eqc " + vocabularyConstantsEval.OBJECT_PROPERTY_HASSUBJECTEQUIVALENCE() + " ?POC" + prefix + var + " .\n";
//                    queryEval += "?POC" + prefix + var + " " + vocabularyConstantsEval.DATA_PROPERTY_HASATTRIBUTE() + " ?" + prefix + var + " .\n";
//                    queryEval += "?" + prefix + var + " " + vocabularyConstantsEval.DATA_PROPERTY_HASPROPERTY() + " <" + link.getKey() + "> .\n";
//                    queryEval += "?" + prefix + var + " " + vocabularyConstantsEval.DATA_PROPERTY_HASOBJECT() + " <" + link.getValue() + "> .\n";
//                    if (var <= 'z') {
//                        var++;
//                    } else {
//                        var = 'a';
//                        prefix += "a";
//                    }
//                }
//
////            if(t > 0)
////                System.out.println(query);
////            Comparator comp = queryDatasources(conGold, conEval, queryGold, "ds");
////                Set<String> setGold = queryDatasource(conGold, queryGold, "ds");
////                Set<String> setEval = queryDatasource(conEval, queryEval, "ds");
////                Comparator comp = new Comparator(setGold, setEval);
////                evalEQCSupEQC.addResult(comp);
//
////                if(comp.getMssing().size() > 0 || comp.getWrong().size() > 0 ){
////                    System.out.println("GOLD QUERY:\n" + queryGold);
////                    System.out.println("EVAL QUERY:\n" + queryEval);
////                    System.out.println("GOLD DS: " + setGold);
////                    System.out.println("EVAL DS: " + setEval);
////                }
////                if(comp.getMssing().size() > 0)
////                    System.out.println("Missing: " + comp.getMssing());
////
////                if(comp.getWrong().size() > 0)
////                    System.out.println("Wrong: " + comp.getWrong());
//            }
//            //get connected data sources
//            queryGold += "?eqc " + vocabularyConstantsGold.OBJECT_PROPERTY_HASPAYLOADELEMENT() + " ?pe .\n";
//            queryEval += "?eqc " + vocabularyConstantsEval.OBJECT_PROPERTY_HASPAYLOADELEMENT() + " ?pe .\n";
//
//            queryGold += "?pe " + vocabularyConstantsGold.DATA_PROPERTY_PAYLOAD() + " ?ds .\n";
//            queryEval += "?pe " + vocabularyConstantsEval.DATA_PROPERTY_PAYLOAD() + " ?ds .\n";
//
//            queryGold += "}\n";
//            queryEval += "}\n";
//
//            queriesEQCaTC.add(queryEval);
//            //build property query
//            //optimize queries (shorten restrictions and distribute workload to threads)
////            EvalMaster evalMaster = new EvalMaster(dbConnection, url, graphGold, graphEval, 2);
////            evalMaster.evaluateLongPredicateQuery(propertySet, "eqc", conGold.getMaxPredicates());
//
//
//            //add to result lists
////            evalEQCSupEQC.addResult(comp);
//            i++;
//        }
//        conGold.close();
//        conEval.close();
//
//        System.out.println("Precision;Recall;F1");
//        System.out.println(evalEQCSupEQC.average());

    }

    //////////////////////////////////////////////
    //////////////      HELPER      //////////////
    //////////////////////////////////////////////

    /**
     * @param connection
     * @param qBody
     * @param vars
     * @return
     */
    public static Set<String> queryDatasource(Connector connection, String qBody, String... vars) {
        return connection.executeQuery(SELECT, DISTINCT, vars, qBody);
    }

    public static Set<Map<String, String>> queryDatasourceDiffVars(Connector connection, String qBody, String... vars) {
        return connection.executeQueryDiffVars(SELECT, DISTINCT, vars, qBody);
    }

    /**
     * Executes a distinct select SPARQL-Query on both connectors
     * returning all variables used in the given body or specified by
     * optional parameter vars
     *
     * @param conGold
     * @param conEval
     * @param qBody
     * @param vars
     * @return
     */
//    public Comparator queryDatasources(Connector conGold, Connector conEval, String qBody, String... vars) {
//        Set<String> setGold = queryDatasource(conGold, qBody, vars);
//        Set<String> setEval = queryDatasource(conEval, qBody, vars);
//        return new Comparator(setGold, setEval);
//    }


}
