package de.uni_kiel.evaluation.eval;


import de.uni_kiel.evaluation.connectors.Connection;
import de.uni_kiel.evaluation.connectors.Connector;
import de.uni_kiel.evaluation.utils.VariablesGenerator;
import de.uni_kiel.evaluation.utils.datastructs.EvalValueArray;
import de.uni_kiel.evaluation.utils.datastructs.SetSet;
import de.uni_kiel.evaluation.utils.datastructs.ValueArray;
import de.uni_kiel.evaluation.vocabularies.FLuIDVocabulary;
import de.uni_kiel.evaluation.vocabularies.SchemEXVocabulary;
import de.uni_kiel.evaluation.vocabularies.VocabularyConstants;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static de.uni_kiel.evaluation.connectors.Connection.DISTINCT;
import static de.uni_kiel.evaluation.connectors.Connection.QueryType.SELECT;

/**
 * Created by Blume Till on 22.08.2016.
 */
public class EvalUnitExperimental {

    private Set<String> propertyObjectClusterURIs;
    private Set<String> propertyClusterURIs;

    private Set<String> CSEURIs;

    //SUP stands for SUPER MEANING DOING THE COMPLEX EVALUATION
    public enum EvalType {
        OC, SUP_OC, PC, SUP_PC, POC, SUP_POC, CSE, SUP_CSE
    }

    private static final int interval = 1500;
    private final Set<EvalType> evalOpt;
    private final boolean debug;

    //db stuff
    private Connection.DBConnection dbConnection;
    private final String url;
    private final String graphGold;
    private final String graphEval;

    //TODO: not needed?
    private ValueArray precision_predicates = new ValueArray();
    private ValueArray recall_predicates = new ValueArray();

    //implementation.eval stuff
    private EvalValueArray evalPCHash = new EvalValueArray();
    private EvalValueArray evalCSEHash = new EvalValueArray();
    private EvalValueArray evalPOCHash = new EvalValueArray();

    private EvalValueArray evalType = new EvalValueArray();
    private EvalValueArray evalTCSupTC = new EvalValueArray();
    private EvalValueArray evalOC = new EvalValueArray();
    private EvalValueArray evalEQC = new EvalValueArray();
    private EvalValueArray evalEQCaTC = new EvalValueArray();
    private EvalValueArray evalPC = new EvalValueArray();
    private EvalValueArray evalOCHash = new EvalValueArray();
    private EvalValueArray evalPOC = new EvalValueArray();
    private EvalValueArray evalCSE = new EvalValueArray();

    //optimizations
    private Set<String> typeClusterURIs;
    private Set<String> equiClassesURIs;


    private VocabularyConstants vocabularyConstantsGold;
    private VocabularyConstants vocabularyConstantsEval;
    private Set<String> typeClusterURIsEval;
    private Set<String> pocURIsEval;
    private Set<String> cseClassesURIs;
    private Connector conGold;
    private Connector conEval;


    public EvalUnitExperimental(de.uni_kiel.evaluation.connectors.Connection.DBConnection dbConnection, String url, String graphGold, VocabularyConstants vocabularyConstantsGold, String graphEval,
                                VocabularyConstants vocabularyConstantsEval, Set<EvalType> evalOptions, boolean debug) {
        this.dbConnection = dbConnection;
        this.graphGold = graphGold;
        this.graphEval = graphEval;
        this.url = url;
        this.vocabularyConstantsGold = vocabularyConstantsGold;
        this.vocabularyConstantsEval = vocabularyConstantsEval;
        this.evalOpt = evalOptions;
        this.debug = debug;
    }

    public void evaluate() {
        //evalTCOld();
        // evalOCViaHashValue();
        // new eval Queries
        if (evalOpt.contains(EvalType.SUP_OC) || evalOpt.isEmpty()) {
            evalOC_SupOC();
            evalOC.toFile("out/" + graphEval + "/SUP_OC.csv");
        }

        if (evalOpt.contains(EvalType.OC) || evalOpt.isEmpty()) {
            evalOCViaHashValue(); //TODO: @Marius: OC -> exact matching of URIs, SUP_OC -> extract all objects + build query
            evalOCHash.toFile("out/" + graphEval + "/OC.csv");
        }

        if (evalOpt.contains(EvalType.SUP_POC) || evalOpt.isEmpty()) {
            evalPOC();
            evalPOC.toFile("out/" + graphEval + "/SUP_POC.csv");
        }

        if (evalOpt.contains(EvalType.POC) || evalOpt.isEmpty()) {
            evalPOCViaHashValue();
            evalPOCHash.toFile("out/" + graphEval + "/POC.csv");
        }

        if (evalOpt.contains(EvalType.SUP_PC) || evalOpt.isEmpty()) {
            evalPC();
            evalPC.toFile("out/" + graphEval + "/SUP_PC.csv");
        }

        if (evalOpt.contains(EvalType.PC) || evalOpt.isEmpty()) {
            evalPCviaHashValue();
            evalPCHash.toFile("out/" + graphEval + "/PC.csv");
        }


        if (evalOpt.contains(EvalType.SUP_CSE) || evalOpt.isEmpty()) {
            evalCSE();
            evalCSE.toFile("out/" + graphEval + "/SUP_CSE.csv");
        }

        if (evalOpt.contains(EvalType.CSE) || evalOpt.isEmpty()) {
            evalCSEViaHashValue();
            evalCSEHash.toFile("out/" + graphEval + "/CSE.csv");
        }

    }
    //evalEQC einfach runterproggen, dass es funktioniert hash wert vergleiche !!! genau so für fluid

    /**
     * This function evaluates the type complex schema elements
     * // there needs to a function which can be recursively called, which gets the next row of elements:
     * // either cse, poc, oc, tc
     * // --> cse: get the next row again
     * // --> poc: return poc query
     * // --> oc : return oc query
     * // --> tc : return tc query
     * // !!<!>!! but here the problem is that we first get the cse from the gold graph and we need to connect them to
     * //         the eval graph. Till mentioned this can later be done via the hash value at the end of the URI.
     * //         If that doesn't work we need to do this with identifying attributes. Basically get a identifying
     * //         attribute tree from the gold graph, and with that create the eval cse query.
     * //
     * <p>
     * <p>
     * // This propably needs some kind of modular query builder for cse
     * //--- propably in a for loop which adds whenever the gold element finds an element, a constraint is added to the eval
     * // query as well
     */

    public void evalCSE() {
        System.out.println("_______________");
        System.out.println("evalCSE");

        conGold = dbConnection.getConnector(url, graphGold);
        conEval = dbConnection.getConnector(url, graphEval);

        // in this query only get the prime cse (those which have no other cse above them --> filter query catching this pattern)
        String cseQuery = vocabularyConstantsGold.GET_PRIME_COMPLEX_SCHEMA_ELEMENTS();

        // for (String eqc : getEQC_URIs()) {
        for (String cse : getURIs_GOLD(cseQuery, cseClassesURIs)) {
            String evalPrimeCse = "?" + VariablesGenerator.getInstance().getVariableName("primecse");
            Map<String, String> resultMap = evalCSERecursion(cse, evalPrimeCse);
            String queryEval = resultMap.get("eval");
            queryEval += vocabularyConstantsEval.CSE_CONSTRAINT_DS(evalPrimeCse);

            String queryGold = resultMap.get("gold"); // technically you could directly take the ds from the cse
            queryGold += vocabularyConstantsGold.CSE_CONSTRAINT_DS(cse);

            eval(queryGold, queryEval, conGold, conEval, evalCSE, debug);


        }
        conGold.close();
        conEval.close();
        System.out.println(evalCSE.size());
        System.out.println("Precision;Recall;F1");
        System.out.println(evalCSE.average());


    }

    /**
     * The idea is to recursively call this function, to build a query in a cumulative way.
     *
     * @return Map key:QueryConstraint: "eval":EvalConstraints, "gold":GoldConstraints
     */
    public Map<String, String> evalCSERecursion(String cseNodeGold, String cseNodeEval) {
        Map<String, String> constraintsGoldEval = new HashMap<>();
        String queryConstraintGold = "";
        String queryConstraintEval = "";

        Set<String> pcSet = queryDatasource(conGold, vocabularyConstantsGold.GET_PC_FROM_CSE(cseNodeGold), "c");
        for (String s : pcSet) {
            //add constraint to the current node
            // GET ALL THE PROPERTIES OF THE PROPERTY CLUSTER
            Set<String> properties = queryDatasource(conGold, vocabularyConstantsGold.GET_PROPERTIES_FROM_PC(s), "p");

            //SHOULD BE IMPLEMENTED FOR FLuID
            queryConstraintGold += vocabularyConstantsGold.CSE_CONSTRAINT_PC(cseNodeGold, properties);
            queryConstraintEval += vocabularyConstantsEval.CSE_CONSTRAINT_PC(cseNodeEval, properties);

        }


        Set<String> ocSet = queryDatasource(conGold, vocabularyConstantsGold.GET_OC_FROM_CSE(cseNodeGold), "c");

        for (String s : ocSet) {
            //GET ALL THE HASHVALUES this should work

            //add constraint to the current node
            if (s.equals(vocabularyConstantsGold.UNRESOLVED_LITERAL_CLUSTER().
                    replace("<", "").replace(">", ""))) {
                queryConstraintGold += vocabularyConstantsGold.CSE_CONSTRAINT_OC_UNRESOLVED_LITERAL_CLUSTER(cseNodeGold);
                queryConstraintEval += vocabularyConstantsEval.CSE_CONSTRAINT_OC_UNRESOLVED_LITERAL_CLUSTER(cseNodeEval);


            } else if (s.equals(vocabularyConstantsGold.EMPTY_LITERAL_CLUSTER().
                    replace("<", "").replace(">", ""))) {
                queryConstraintGold += vocabularyConstantsGold.CSE_CONSTRAINT_OC_EMPTY_LITERAL_CLUSTER(cseNodeGold);
                queryConstraintEval += vocabularyConstantsEval.CSE_CONSTRAINT_OC_EMPTY_LITERAL_CLUSTER(cseNodeEval);


            } else {
                queryConstraintGold += vocabularyConstantsGold.CSE_CONSTRAINT_OC(cseNodeGold, vocabularyConstantsGold.GET_HASH_VALUE_FROM_OC(s));
                queryConstraintEval += vocabularyConstantsEval.CSE_CONSTRAINT_OC(cseNodeEval, vocabularyConstantsGold.GET_HASH_VALUE_FROM_OC(s));
            }


        }

        Set<String> pocSet = queryDatasource(conGold, vocabularyConstantsGold.GET_POC_FROM_CSE(cseNodeGold), "c");

        for (String s : pocSet) {
            //GET ALL THE PROPERTY OBJECT PAIRS with ONLY HASHVALUE AS OBJECT @see evalPOC
            Set<Map<String, String>> propertyObjectPairsOrig = new HashSet<>();
            //TODO make sure this is correct apparently all properties have an object, catch empty and unresolved and stuff oc
            if (s.equals(vocabularyConstantsGold.NO_PROPERTY_OBJECT_CLUSTER().
                    replace("<", "").replace(">", ""))) {

                queryConstraintGold += vocabularyConstantsGold.CSE_CONSTRAINT_NO_POC(cseNodeGold);
                queryConstraintEval += vocabularyConstantsEval.CSE_CONSTRAINT_NO_POC(cseNodeEval);


            } else {
                propertyObjectPairsOrig.addAll(queryDatasourceDiffVars(conGold, vocabularyConstantsGold.
                        GET_PROPERTY_OBJECT_PAIRS(s), "prop", "obj"));//i assume that there are only 1:1 connections

                //This data
                Set<Map<String, String>> propertyObjectPairsWithOnlyHashObj = new HashSet<>();


                createPOCPairs(propertyObjectPairsOrig, propertyObjectPairsWithOnlyHashObj);

                if (propertyObjectPairsWithOnlyHashObj.size() == 0) {
//                    System.out.println("No Property-Object Pairs");
//                    System.out.println(vocabularyConstantsGold.GET_PROPERTY_OBJECT_PAIRS(s));
                    continue;
                }


                queryConstraintGold += vocabularyConstantsGold.CSE_CONSTRAINT_POC(cseNodeGold, propertyObjectPairsWithOnlyHashObj);
                queryConstraintEval += vocabularyConstantsEval.CSE_CONSTRAINT_POC(cseNodeEval, propertyObjectPairsWithOnlyHashObj);
            }

        }


        Set<String> cseSet = queryDatasource(conGold, vocabularyConstantsGold.GET_CSE_FROM_CSE(cseNodeGold), "c");
        // get all complexSchemaElements (maybe check wether the cse was already visited
        // Problem here is that all are already in the queue from evalCSE which iterates over all cse
        //
        for (String s : cseSet) {
            String varEval = VariablesGenerator.getInstance().getVariableName("cse");
            //Maybe just link we are a unique variable aka ?cse123 to the schema elements below it
            queryConstraintGold += vocabularyConstantsGold.CSE_CONSTRAINT_CSE(cseNodeGold, s);
            queryConstraintEval += vocabularyConstantsEval.CSE_CONSTRAINT_CSE(cseNodeEval, varEval);

            //

            //and check next node
            Map<String, String> result = evalCSERecursion(s, varEval);

            queryConstraintGold += result.get("gold");
            queryConstraintEval += result.get("eval");
            //recursive function call

        }

        constraintsGoldEval.put("eval", queryConstraintEval);
        constraintsGoldEval.put("gold", queryConstraintGold);


        return constraintsGoldEval;

    }

    private void createPOCPairs(Set<Map<String, String>> propertyObjectPairsOrig, Set<Map<String, String>> propertyObjectPairsWithOnlyHashObj) {
        for (Map<String, String> pair : propertyObjectPairsOrig) {
            HashMap<String, String> hashMap = new HashMap<>();
            String prop = pair.get("prop");
            String obj = vocabularyConstantsGold.GET_HASH_VALUE_FROM_OC(pair.get("obj"));

            if (("<" + prop + ">").equals(vocabularyConstantsGold.RDF_TYPE()) || vocabularyConstantsGold.IS_FILTER_PROPERTY(prop)) {
                continue;
            }
            //check to which oc the property is connected to
            if (obj.equals(vocabularyConstantsGold.EMPTY_LITERAL_CLUSTER())) {
                obj = vocabularyConstantsEval.EMPTY_LITERAL_CLUSTER();
                hashMap.put(pair.get("prop"), obj);
            } else if (obj.equals(vocabularyConstantsGold.UNRESOLVED_LITERAL_CLUSTER())) {
                obj = vocabularyConstantsEval.UNRESOLVED_LITERAL_CLUSTER();
                hashMap.put(pair.get("prop"), obj);
            } else {
                hashMap.put(pair.get("prop"), vocabularyConstantsGold.GET_HASH_VALUE_FROM_OC(obj));

            }

            propertyObjectPairsWithOnlyHashObj.add(hashMap);
        }
    }


    /**
     * This function is used to store a result of one comparison into a EvalValueArray and display some statistics if
     * the result isn't perfect.
     *
     * @param goldQueryDS Query which queries for datasources in the gold graph.
     * @param evalQueryDS Query which queries for datasources in the eval graph.
     * @param conGold     Connection to the gold graph.
     * @param conEval     Connection to the eval graph.
     * @param evalArray   EvalValueArray into which the result is to be stored.
     */
    public void eval(String goldQueryDS, String evalQueryDS, Connector conGold, Connector conEval, EvalValueArray evalArray, Boolean debug) {
        Set<String> setGold = queryDatasource(conGold, goldQueryDS, "ds");
        Set<String> setEval = queryDatasource(conEval, evalQueryDS, "ds");
        Comparator comparator = new Comparator(setGold, setEval);

        evalArray.addResult(comparator);

        if (debug && (comparator.getMssing().size() > 0 || comparator.getWrong().size() > 0)) {
            System.out.println("GOLD QUERY:\n" + goldQueryDS);
            System.out.println("EVAL QUERY:\n" + evalQueryDS + "\n");
            System.out.println("GOLD DS: " + setGold);
            System.out.println("EVAL DS: " + setEval);
            if (comparator.getMssing().size() > 0)
                System.out.println("Missing: " + comparator.getMssing());

            if (comparator.getWrong().size() > 0)
                System.out.println("Wrong: " + comparator.getWrong());
            System.out.println("------------------------------------------------------\n");
        }
    }

    /**
     * This evaluation function works in the following way:
     * 1. Get all the property cluster from the Gold Graph
     * 2. For each property cluster
     * 1. get the attached properties
     * 2. filter unwanted properties
     * 3. create a gold query based on the remaining properties to find the related datasources
     * 4. create a eval query based on the remaining properties to find the related datasources
     * 5. query the datasources of eval and gold
     * 6. compare them (missing;wrong;precision;recall;f1-measure)
     */
    public void evalPC() {
        System.out.println("_______________");
        System.out.println("evalPC");

        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);


        String pcQuery = "?x" + " " + vocabularyConstantsGold.RDF_TYPE() + " " + vocabularyConstantsGold.CLASS_PROPERTY_CLUSTER();
        // for (String eqc : getEQC_URIs()) {
        for (String pc : getURIs_GOLD(pcQuery, equiClassesURIs)) {
            //debug
            if (pc.equals(vocabularyConstantsGold.EMPTY_PROPERTIES_CLUSTER().replace("<", "").replace(">", ""))) {
                continue; //TODO TIll
            }


            // make this into the vocabulary
            Set<String> propertySet = queryDatasource(conGold, vocabularyConstantsGold.GET_PROPERTIES_FROM_PC(pc), "p");
            Set<String> removeSet = new HashSet<>();
            //this part filters rdf_type and whatever is defined in the gold vocabulary
            propertySet.forEach(X -> {
                if (("<" + X + ">").equals(vocabularyConstantsGold.RDF_TYPE()) || vocabularyConstantsGold.IS_FILTER_PROPERTY(X))
                    removeSet.add(X);
            });
            propertySet.removeAll(removeSet);


            String queryEval = vocabularyConstantsEval.GET_DS_FROM_PROPERTIES(propertySet);

            String queryGold = vocabularyConstantsGold.GET_DS_FROM_PROPERTIES(propertySet);


            eval(queryGold, queryEval, conGold, conEval, evalPC, debug);


        }
        conGold.close();
        conEval.close();
        System.out.println(evalPC.size());

        System.out.println("Precision;Recall;F1");
        System.out.println(evalPC.average());

    }

    /**
     * This evaluation function works in the following way:
     * 1. Get all the property object cluster from the Gold Graph (for schemex all eqc)
     * 2. For each property object cluster
     * 1. get the attached properties object pairs (for schemex this means getting the p/o pairs with a valid o)???
     * 2. create a gold query based on the remaining properties, objects to find the related datasources
     * 3. query the datasources of eval and gold
     * 4. compare them (missing;wrong;precision;recall; f1-measure)
     * !!! OK ROLL BACK SCHEMEX POC IS a LINK PROP TO AN OC cse (?p ?o) --> POC where ?o is valid right?
     */
    public void evalPOC() {
        System.out.println("_______________");
        System.out.println("evalPOC");

        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        //????
        String query = "?x" + " " + vocabularyConstantsGold.RDF_TYPE() + " " + vocabularyConstantsGold.CLASS_PROPERTY_OBJECT_CLUSTER();
        query = vocabularyConstantsGold.GET_PROPERTY_OBJECT_CLUSTER();

        for (String poc : getURIs_GOLD(query, pocURIsEval)) {
            String queryEval = "";
            String queryGold = "";
            if (poc.equals(vocabularyConstantsGold.NO_PROPERTY_OBJECT_CLUSTER().
                    replace("<", "").replace(">", ""))) {

                queryEval = vocabularyConstantsEval.QUERY_DS_FROM_NO_PROPERTY_OBJECT_CLUSTER();
                queryGold = vocabularyConstantsEval.QUERY_DS_FROM_NO_PROPERTY_OBJECT_CLUSTER();
            } else {
                Set<Map<String, String>> propertyObjectPairsOrig = new HashSet<>();
                //TODO make sure this is correct apparently all properties have an object, catch empty and unresolved and stuff oc
                // add the moment the query only gets the pairs which have types attached
                propertyObjectPairsOrig.addAll(queryDatasourceDiffVars(conGold, vocabularyConstantsGold.GET_PROPERTY_OBJECT_PAIRS(poc), "prop", "obj")); // i assume that there are only 1:1 connections

                Set<Map<String, String>> propertyObjectPairsWithOnlyHashObj = new HashSet<>();


                createPOCPairs(propertyObjectPairsOrig, propertyObjectPairsWithOnlyHashObj);

                if (propertyObjectPairsWithOnlyHashObj.size() == 0) {
//                    System.out.println("No Property-Object Pairs");
//                    System.out.println(vocabularyConstantsGold.GET_PROPERTY_OBJECT_PAIRS(poc));
                    continue;
                }

                queryEval = vocabularyConstantsEval.GET_DS_FROM_PROPERTY_OBJECT_PAIRS(propertyObjectPairsWithOnlyHashObj);

                queryGold = vocabularyConstantsGold.GET_DS_FROM_PROPERTY_OBJECT_PAIRS(propertyObjectPairsWithOnlyHashObj);
            }

//           > System.out.println("Eval\n"+ queryEval);
//            System.out.println("Gold\n"+ queryGold);

            eval(queryGold, queryEval, conGold, conEval, evalPOC, debug);


        }


        conEval.close();
        conGold.close();
        System.out.println(evalPOC.size());
        System.out.println("Precision;Recall;F1");
        System.out.println(evalPOC.average());


    }


    /**
     * This evaluation function works in the following way:
     * 1. Get all the object cluster from the Gold Graph
     * 2. For each  object cluster
     * 1. get the attached types
     * 2. create a gold query based on the remaining types to find the related datasources
     * 3. query the datasources of eval and gold
     * 4. compare them (missing;wrong;precision;recall; f1-measure)
     */
    public void evalOC_SupOC() {
        System.out.println("_______________");
        System.out.println("evalOC_SupOC (old TC_supTC query)");

        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        //OC specific query
        String query = "?x" + " " + vocabularyConstantsGold.RDF_TYPE() + " " + vocabularyConstantsGold.CLASS_OBJECT_CLUSTER();
        for (String oc : getURIs_GOLD(query, typeClusterURIs)) {
            String queryGold;
            String queryEval;

            //handle specific cases for special objects
            if (oc.equals(vocabularyConstantsGold.UNRESOLVED_LITERAL_CLUSTER().
                    replace("<", "").replace(">", ""))) {
                queryGold = vocabularyConstantsGold.GET_DS_FROM_UNRESOLVED_LITERAL_CLUSTER();
                queryEval = vocabularyConstantsEval.GET_DS_FROM_UNRESOLVED_LITERAL_CLUSTER();

            } else if (oc.equals(vocabularyConstantsGold.EMPTY_LITERAL_CLUSTER().
                    replace("<", "").replace(">", ""))) {
                queryGold = vocabularyConstantsGold.GET_DS_FROM_EMPTY_LITERAL_CLUSTER();
                queryEval = vocabularyConstantsEval.GET_DS_FROM_EMPTY_LITERAL_CLUSTER();
            } else {
                //Default Case:
                //todo
                Set<String> types = queryDatasource(conGold, vocabularyConstantsGold.GET_OC_QUERY(oc), "type");
                if (types.size() == 0)
                    continue;
                queryGold = vocabularyConstantsGold.GET_DS_FROM_TYPES(types);
                queryEval = vocabularyConstantsEval.GET_DS_FROM_TYPES(types);
            }
            eval(queryGold, queryEval, conGold, conEval, evalOC, debug);
        }

        conEval.close();
        conGold.close();

        System.out.println(evalOC.size());
        System.out.println("Precision;Recall;F1");
        System.out.println(evalOC.average());
    }

    /**
     * The Types in this case are the identifying variables maybe those should be returned.
     */
    public void evalOCViaHashValue() {
        System.out.println("_______________");
        System.out.println("evalOCViaHashValue (old TC query)");

        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        String query = "?x" + " " + vocabularyConstantsGold.RDF_TYPE() + " " + vocabularyConstantsGold.CLASS_OBJECT_CLUSTER();
        for (String oc : getURIs_GOLD(query, typeClusterURIs)) {
            String queryGold;
            String queryEval;


            //TODO: @Marius: this is basically all the same query
            if (oc.equals(vocabularyConstantsGold.UNRESOLVED_LITERAL_CLUSTER().
                    replace("<", "").replace(">", ""))) {
                queryGold = vocabularyConstantsGold.GET_DS_FROM_UNRESOLVED_LITERAL_CLUSTER();
                queryEval = vocabularyConstantsEval.GET_DS_FROM_UNRESOLVED_LITERAL_CLUSTER();
            } else if (oc.equals(vocabularyConstantsGold.EMPTY_LITERAL_CLUSTER().
                    replace("<", "").replace(">", ""))) {
                queryGold = vocabularyConstantsGold.GET_DS_FROM_EMPTY_LITERAL_CLUSTER();
                queryEval = vocabularyConstantsEval.GET_DS_FROM_EMPTY_LITERAL_CLUSTER();
            } else {
                queryGold = vocabularyConstantsGold.QUERY_DS_VIA_OC(oc);
                queryEval = vocabularyConstantsEval.QUERY_DS_VIA_OC(vocabularyConstantsEval.
                        CREATE_OC_VIA_HASH(vocabularyConstantsGold.GET_HASH_VALUE_FROM_OC(oc)));
            }
            eval(queryGold, queryEval, conGold, conEval, evalOCHash, debug);

        }

        conEval.close();
        conGold.close();

        System.out.println(evalOCHash.size());
        System.out.println("Precision;Recall;F1");
        System.out.println(evalOCHash.average());
    }

    /**
     * The Types in this case are the identifying variables maybe those should be returned.
     */
    public void evalPOCViaHashValue() {
        System.out.println("_______________");
        System.out.println("evalPOC via hash value");

        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        String query = vocabularyConstantsGold.GET_PROPERTY_OBJECT_CLUSTER();
        for (String poc : getURIs_GOLD(query, propertyObjectClusterURIs)) {
            String queryGold;
            String queryEval;

            if (poc.equals(vocabularyConstantsGold.NO_PROPERTY_OBJECT_CLUSTER())) {
                queryGold = vocabularyConstantsGold.QUERY_DS_FROM_NO_PROPERTY_OBJECT_CLUSTER();
                queryEval = vocabularyConstantsEval.QUERY_DS_FROM_NO_PROPERTY_OBJECT_CLUSTER();
            } else {
                queryGold = vocabularyConstantsGold.QUERY_DS_FROM_PROPERTY_OBJECT_CLUSTER(poc);
                queryEval = vocabularyConstantsEval.QUERY_DS_FROM_PROPERTY_OBJECT_CLUSTER((vocabularyConstantsEval.
                        CREATE_OC_VIA_HASH(vocabularyConstantsGold.GET_HASH_VALUE_FROM_POC(poc))));
            }
            eval(queryGold, queryEval, conGold, conEval, evalPOCHash, debug);
        }

        conEval.close();
        conGold.close();

        System.out.println(evalPOCHash.size());
        System.out.println("Precision;Recall;F1");
        System.out.println(evalPOCHash.average());

    }

    /**
     * The Types in this case are the identifying variables maybe those should be returned.
     */
    public void evalPCviaHashValue() {
        System.out.println("_______________");
        System.out.println("evalPC via hash value");

        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        //for (String oc : getOC_URIsGold()) {
        String query = "?x" + " " + vocabularyConstantsGold.RDF_TYPE() + " " + vocabularyConstantsGold.CLASS_PROPERTY_CLUSTER();
        for (String pc : getURIs_GOLD(query, propertyClusterURIs)) {
            String queryGold;
            String queryEval;

            if (pc.equals(vocabularyConstantsGold.EMPTY_PROPERTIES_CLUSTER().
                    replace("<", "").replace(">", ""))) {
                queryGold = vocabularyConstantsGold.GET_DS_FROM_EMPTY_PROPERTIES_CLUSTER();
                queryEval = vocabularyConstantsEval.GET_DS_FROM_EMPTY_PROPERTIES_CLUSTER();


            } else {
                queryGold = vocabularyConstantsGold.QUERY_DS_VIA_PC(pc);
                queryEval = vocabularyConstantsEval.QUERY_DS_VIA_PC(vocabularyConstantsEval.
                        CREATE_OC_VIA_HASH(vocabularyConstantsGold.GET_HASH_VALUE_FROM_PC(pc)));
            }
            eval(queryGold, queryEval, conGold, conEval, evalPCHash, debug);

        }

        conEval.close();
        conGold.close();

        System.out.println(evalPCHash.size());
        System.out.println("Precision;Recall;F1");
        System.out.println(evalPCHash.average());
    }

    /**
     * The Types in this case are the identifying variables maybe those should be returned.
     */
    public void evalCSEViaHashValue() {
        System.out.println("_______________");
        System.out.println("evalCSE via hash value (old EQC)");

        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        //for (String oc : getOC_URIsGold()) {
        String query = "?x" + " " + vocabularyConstantsGold.RDF_TYPE() + " " + vocabularyConstantsGold.CLASS_COMPLEX_SCHEMA_ELEMENT();
        for (String cse : getURIs_GOLD(query, CSEURIs)) {
            String queryGold;
            String queryEval;
            queryGold = vocabularyConstantsGold.QUERY_DS_VIA_CSE(cse);
            queryEval = vocabularyConstantsEval.QUERY_DS_VIA_CSE(vocabularyConstantsEval.
                    CREATE_CSE_VIA_HASH(vocabularyConstantsGold.GET_HASH_VALUE_FROM_CSE(cse)));

            eval(queryGold, queryEval, conGold, conEval, evalCSEHash, debug);
        }

        conEval.close();
        conGold.close();

        System.out.println(evalCSEHash.size());
        System.out.println("Precision;Recall;F1");
        System.out.println(evalCSEHash.average());

    }

    /**
     * Starts a query which returns a specfified ?x in the query (this maybe can be parametrized).
     *
     * @param query  Input SPARQL-query containing a ?x
     * @param uriSet The URI-set the results URIs are saved into.
     * @return result set
     */
    private Set<String> getURIs_GOLD(String query, Set<String> uriSet) {
        if (uriSet == null || uriSet.size() == 0) {
            Connector connector = dbConnection.getConnector(url, graphGold);
            uriSet = queryDatasource(connector, query, "x");
        }
        return uriSet;
    }


    public SetSet getTC_TS() {
        Connector connector = dbConnection.getConnector(url, graphGold);
        SetSet setSet = new SetSet();
        for (String tc : getOC_URIsGold())
            setSet.add(queryDatasource(connector, "<" + tc + "> " + vocabularyConstantsGold.HAS_ATTRIBUTE() + " ?c"));
        connector.close();
        return setSet;
    }

    public Set<String> getOC_URIsGold() {
        if (typeClusterURIs == null) {
            Connector conGold = dbConnection.getConnector(url, graphGold);
            typeClusterURIs = queryDatasource(conGold, "?tc" + " " + vocabularyConstantsGold.RDF_TYPE() + " " + vocabularyConstantsGold.CLASS_OBJECT_CLUSTER());
            System.out.println("typeClusterURIs.size" + typeClusterURIs.size());
            //filter(typeClusterURIs, TC_NOTYPE + "|" + TC_UNRESOLVED);
            System.out.println("typeClusterURIs.size" + typeClusterURIs.size());
        }
        return typeClusterURIs;
    }


    //////////////////////////////////////////////
    //////////////      HELPER      //////////////
    //////////////////////////////////////////////

    /**
     * @param connection
     * @param qBody
     * @param vars
     * @return
     */
    public static Set<String> queryDatasource(Connector connection, String qBody, String... vars) {
        return connection.executeQuery(SELECT, DISTINCT, vars, qBody);
    }

    public static Set<Map<String, String>> queryDatasourceDiffVars(Connector connection, String qBody, String... vars) {
        return connection.executeQueryDiffVars(SELECT, DISTINCT, vars, qBody);
    }


    public static long printProgress(int i, int max, int interval, long start) {
        if (i % interval == 0) {
            long stop = System.currentTimeMillis();
            System.out.format("Progress: %08d / %08d RQ/s: %.2f\n", i, max,
                    ((double) interval / ((double) ((stop - start) / 1000))));
            return stop;
        } else
            return -1;
    }

    /////////////////////////////////////////
    //////////////  KOMMENTAR @ TIll //////////////////
    /////////////////////////////////////////


    public void compatibilityCheck() {
        //annahme1: goldstandard ist schemex
        //annahme2: in der eval Connection ist SchemEX modelliert via FLUID siehe whiteboard bild
        //annahme3: diese Funktion ist zum statischem einmalüberprüfen
        //nichts schönes oder fanciges
        //1. evalTC <==> evalOC_SupOC
        //2. evalEQC mit POC

    }
    /////////////////////////////////////////
    //////////////  UNUSED //////////////////
    /////////////////////////////////////////

    /**
     * Evaluate according to original implementation from Mattias Konrad
     * <p>
     * For each EQC (URI) compare the connected data sources
     */
    public void evalEQCOLD() {
        System.out.println("_______________");
        System.out.println("EQC-OLD");
        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);


        int i = 1;
        int size = getEQC_URIs().size();
        long start = System.currentTimeMillis();

        for (String eqc : getEQC_URIs()) {
            long t = printProgress(i, size, interval, start);
            start = t > 0 ? t : start;

            String eqcEval = eqc;
            if (!(vocabularyConstantsEval instanceof SchemEXVocabulary)) {
                eqcEval = eqc.replaceAll("http://schemex\\.west\\.uni-koblenz\\.de/eq", vocabularyConstantsEval.CLASS_COMPLEX_SCHEMA_ELEMENT().toString().replaceAll("<|>", ""));
            }

//            System.out.println("GOLD: " + eqc);
//            System.out.println("EVAL: " + eqcEval);

            String queryGold = "<" + eqc + "> " + vocabularyConstantsGold.HAS_PAYLOAD_ELEMENT() + " ?pe . " +
                    "?pe " + vocabularyConstantsGold.PAYLOAD_INFORMATION() + " ?ds .\n";

            String queryEval = "<" + eqcEval + "> " + vocabularyConstantsEval.HAS_PAYLOAD_ELEMENT() + " ?pe . " +
                    "?pe " + vocabularyConstantsEval.PAYLOAD_INFORMATION() + " ?ds .\n";
//            Comparator comp = queryDatasources(conGold, conEval, , "ds");
            Set<String> setGold = queryDatasource(conGold, queryGold, "ds");
            Set<String> setEval = queryDatasource(conEval, queryEval, "ds");
            Comparator comp = new Comparator(setGold, setEval);
            if (comp.getMssing().size() > 0 || comp.getWrong().size() > 0) {
                System.out.println("GOLD QUERY:\n" + queryGold);
                System.out.println("EVAL QUERY:\n" + queryEval);
                System.out.println("GOLD DS: " + setGold);
                System.out.println("EVAL DS: " + setEval);
            }

            evalEQC.addResult(comp);
            i++;
        }
        conEval.close();
        conGold.close();

        System.out.println("Precision;Recall;F1");
        System.out.println(evalEQC.average());
    }


    /**
     * Evaluate according to original implementation from Mattias Konrad
     * <p>
     * For each EQC (URI) compare the connected data sources
     */
    public void evalEQC() {
        System.out.println("_______________");
        System.out.println("EQC");
        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);
        int i = 1;
        int size = getEQC_URIs().size();
        long start = System.currentTimeMillis();
        // for each eqc here get all the stuff which makes it eqc --> probably the class
        // then get the eqc from fluid corresponding to the stuff
        // then compare ds
        for (String eqc : getEQC_URIs()) {
            long t = printProgress(i, size, interval, start);
            start = t > 0 ? t : start;
            //here get the stuff that makes them equal
            //classes
            Set<String> classes = getClassFromEQC(eqc, graphGold);
            //objects

            //properties
            if (classes.size() < 1)
                continue;

            Set<String> eqcEvalSet = queryDatasource(conEval, vocabularyConstantsEval.GET_EQC_FROM_CLASSES(classes), "eqc");
            if (eqcEvalSet.size() < 1)
                continue;

            String queryGold = vocabularyConstantsGold.QUERY_DS_VIA_CLASSES(classes);
            String queryEval = vocabularyConstantsEval.QUERY_DS_VIA_CLASSES(classes);

//            Comparator comp = queryDatasources(conGold, conEval, , "ds");
            Set<String> setGold = queryDatasource(conGold, queryGold, "ds");
            Set<String> setEval = queryDatasource(conEval, queryEval, "ds");
            Comparator comp = new Comparator(setGold, setEval);

            if (comp.getMssing().size() > 0 || comp.getWrong().size() > 0) {
                System.out.println("GOLD QUERY:\n" + queryGold);
                System.out.println("EVAL QUERY:\n" + queryEval);
                System.out.println("GOLD DS: " + setGold);
                System.out.println("EVAL DS: " + setEval);
            }

            evalEQC.addResult(comp);
            i++;
        }
        conEval.close();
        conGold.close();


        System.out.println("Precision;Recall;F1");
        System.out.println(evalEQC.average());
    }

    /**
     * Evaluate according to original implementation from Mattias Konrad
     * <p>
     * For each EQC (URI) compare the connected properties and their objects
     */
    public void evalEQCaTC() {
        System.out.println("_______________");
        System.out.println("EQC + TC");
        int unresolvedGold = 0;
        int unresolvedEval = 0;
        Connector conGold = dbConnection.getConnector(url, graphGold);
        Connector conEval = dbConnection.getConnector(url, graphEval);

        int i = 1;
        int size = getEQC_URIs().size();
        long start = System.currentTimeMillis();


        //iterate over all type cluster
        for (String eqc : getEQC_URIs()) {
            //debug
            long t = printProgress(i, size, interval, start);
            start = t > 0 ? t : start;
            //getAll corresponding properties and objects
            String queryGold = "<" + eqc + "> ?p ?o .\n";
            if (vocabularyConstantsEval instanceof SchemEXVocabulary)
                queryGold += "FILTER (!strstarts(str(?p), \"http://west.uni-koblenz.de\"))";
            else if (vocabularyConstantsEval instanceof FLuIDVocabulary)
                queryGold += "FILTER (!strstarts(str(?p), \"http://www.fluid.informatik.un\"))";
            else
                queryGold += "FILTER (!strstarts(str(?p), \"http://www.psyko.informatik.un\"))";

            Set<String> propertiesGold = queryDatasource(conGold, queryGold, "p", "o");
            //filter types TODO: should be done here?
            //filter(propertiesGold, type + ".*");
            //filter datasets
            //filter(propertiesGold, hasDataset + ".*");
            //filter entityCount TODO: fix in SchemEX
            //filter(propertiesGold, entityCount + ".*");
            //filter not resolvable ranges
            //unresolvedGold += filter(propertiesGold, ".*http://west.uni-koblenz.de/tcNotResolvable").size();
            //getAll corresponding properties and objects

            String eqcEval = eqc;
            if (!(vocabularyConstantsEval instanceof SchemEXVocabulary))
                eqcEval = eqc.replaceAll("http://west.uni-koblenz.de/eq", vocabularyConstantsEval.CLASS_COMPLEX_SCHEMA_ELEMENT().toString().replaceAll("<|>", ""));


            String queryEval = "<" + eqcEval + "> ?p ?o .\n";
            if (vocabularyConstantsEval instanceof SchemEXVocabulary)
                queryEval += "FILTER (!strstarts(str(?p), \"http://west.uni-koblenz.de\"))";
            else if (vocabularyConstantsEval instanceof FLuIDVocabulary)
                queryEval += "FILTER (!strstarts(str(?p), \"http://www.fluid.informatik.un\"))";

            else
                queryEval += "FILTER (!strstarts(str(?p), \"http://www.psyko.informatik.un\"))";


            //queryDatasourceDiffVars
            Set<String> propertiesEval = queryDatasource(conEval, queryEval, "p", "o");
            //filter(propertiesEval, entityCount + ".*");
            //filter not resolvable ranges
            //unresolvedEval += filter(propertiesEval, ".*http://west.uni-koblenz.de/tcNotResolvable").size();
            Comparator comp = new Comparator(propertiesGold, propertiesEval);
            //add to result lists
            evalEQCaTC.addResult(comp);
            i++;
        }
        conGold.close();
        conEval.close();

        System.out.println("Unresolved Gold: " + unresolvedGold);
        System.out.println("Unresolved Eval: " + unresolvedEval);
        System.out.println("Precision;Recall;F1");
        System.out.println(evalEQCaTC.average());

    }

    public Set<String> getTC_URIsEval(String typeClusterQuery) {
        if (typeClusterURIsEval == null) {
            Connector conEval = dbConnection.getConnector(url, graphEval);
            typeClusterURIsEval = queryDatasource(conEval, typeClusterQuery, "tc");

        }
        return typeClusterURIsEval;
    }


    public Set<String> getEQC_URIs() {
        if (equiClassesURIs == null) {
            Connector conGold = dbConnection.getConnector(url, graphGold);
            equiClassesURIs = queryDatasource(conGold, "?eqc" + " " + vocabularyConstantsGold.RDF_TYPE() + " " + vocabularyConstantsGold.CLASS_COMPLEX_SCHEMA_ELEMENT());

        }
        return equiClassesURIs;
    }

    public Set<String> getClassFromEQC(String eqc, String graph) {
        Connector connector = dbConnection.getConnector(url, graph);
        Set<String> set = new HashSet<String>();

        set.addAll(queryDatasource(connector, "?cl <http://schemex.west.uni-koblenz.de/hasClass> ?class.\n" +
                "  ?cl <http://schemex.west.uni-koblenz.de/hasSubset><" + eqc + ">", "class"));


        return set;
    }

}
