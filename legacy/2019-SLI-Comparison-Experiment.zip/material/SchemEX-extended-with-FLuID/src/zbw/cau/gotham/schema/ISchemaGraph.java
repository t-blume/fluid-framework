package zbw.cau.gotham.schema;

import java.util.HashMap;
import java.util.List;

public interface ISchemaGraph {
    HashMap<String, PropertyNode> getSchemaPropertyHashMap();
    HashMap<String, TypeNode> getSchemaTypeHashMap();

    PropertyNode getPropertyNode(String property);

    void addPropertyNode(String property, PropertyNode propertyNode);

    int getNumberOfPropertyNodes();

    TypeNode getTypeNode(String type);

    void addTypeNode(String type, TypeNode typeNode);

    int getNumberOfTypeNodes();

}
