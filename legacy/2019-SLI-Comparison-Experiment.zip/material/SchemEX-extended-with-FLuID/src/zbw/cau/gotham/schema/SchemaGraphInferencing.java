package zbw.cau.gotham.schema;


import de.uni_kiel.schemex.common.IInstanceElement;
import de.uni_kiel.schemex.common.IQuint;
import de.uni_kiel.schemex.utils.Constants;
import de.uni_kiel.schemex.utils.LRUCache;

import java.io.PrintStream;
import java.util.*;

import static de.uni_kiel.schemex.utils.Constants.RDF_TYPE;

/**
 * TODO: INCLUDE INCOMING PROPERTIES
 *
 * @author Blume Till
 */
public class SchemaGraphInferencing {


    public ISchemaGraph getSchemaGraph() {
        return schemaGraph;
    }

    public void setSchemaGraph(ISchemaGraph schemaGraph) {
        this.schemaGraph = schemaGraph;
    }

    ISchemaGraph schemaGraph;

    private LRUCache<String, Set<String>> recursivePropertyCache;
    private LRUCache<String, Set<String>> recursiveTypeCache;

    private final int cacheSize;

    boolean trackStatistics = true;
    //statistics
    private int cacheFlushes = 0;
    private List<Integer> superPropertiesAdded = new LinkedList<>();
    private List<Integer> superTypesAdded = new LinkedList<>();


    private int cacheHits = 0;

    public SchemaGraphInferencing() {
        this(5000, null);
    }

    public SchemaGraphInferencing(int cacheSize) {
        this(cacheSize, null);
    }

    public SchemaGraphInferencing(String folder) {
        this(5000, folder);
    }

    public SchemaGraphInferencing(int cacheSize, String folder) {
        if (folder == null)
            schemaGraph = new InMemorySchemaGraph();
        else
            schemaGraph = new FileSchemaGraph(folder);

        this.cacheSize = cacheSize;
        recursivePropertyCache = new LRUCache<>(cacheSize, 0.75f);
        recursiveTypeCache = new LRUCache<>(cacheSize, 0.75f);

    }

    public void printStatistics(PrintStream printStream){
        printStatistics(printStream, new HashMap<>(), new HashMap<>());
    }

    public void printStatistics(PrintStream printStream, HashMap<String, Integer> propertyStats, HashMap<String, Integer> typeStats) {
        long maxInferrablePropertiesIdv = 0L;
        long minInferrablePropertiesIdv = Long.MAX_VALUE;
        LinkedList<Long> inferrablePropertiesIdv = new LinkedList<>();

        long totalInferrableProperties = 0L;
        long propertyEdges = 0L;

        long totalPropertiesWithNoInferrableInformation = 0L;
        long totalPropertiesWithInferrableInformation = 0L;

        long maxInferrableTypesIdv = 0L;
        long minInferrableTypesIdv = Long.MAX_VALUE;
        LinkedList<Long>  inferrableTypesIdv = new LinkedList<>();

        long totalInferrableTypes = 0L;
        long typeEdges = 0L;
        long domainEdges = 0L;
        long rangeEdges = 0L;

        long totalTypesWithNoInferrableInformation = 0L;
        long totalTypesWithInferrableInformation = 0L;

        System.out.println("Calculating statistics...");
        //get max/min/avg/std path length
        for(PropertyNode propertyNode : schemaGraph.getSchemaPropertyHashMap().values()){
            long tmpSuperProps = propertyNode.getSubPropertyOf().size();
            propertyEdges += tmpSuperProps;
            long tmpDomainTypes = propertyNode.getDomain().size();
            domainEdges += tmpDomainTypes;
            long tmpRangeTypes = propertyNode.getRange().size();
            rangeEdges += tmpRangeTypes;

            long tmpInferTypes = tmpDomainTypes + tmpRangeTypes;

            if(tmpSuperProps > maxInferrablePropertiesIdv)
                maxInferrablePropertiesIdv = tmpSuperProps;
            if(tmpSuperProps < minInferrablePropertiesIdv)
                minInferrablePropertiesIdv = tmpSuperProps;

            if(tmpInferTypes > maxInferrableTypesIdv)
                maxInferrableTypesIdv = tmpInferTypes;
            if(tmpInferTypes < minInferrableTypesIdv)
                minInferrableTypesIdv = tmpInferTypes;

            inferrablePropertiesIdv.add(tmpSuperProps);
            inferrableTypesIdv.add(tmpInferTypes);
        }


        for(Map.Entry<String, Integer> propertyUse : propertyStats.entrySet()){
            if(propertyUse.getKey().equals("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"))
                continue;

            PropertyNode propertyNode = schemaGraph.getPropertyNode(propertyUse.getKey());
            if(propertyNode == null){
                totalPropertiesWithNoInferrableInformation += propertyUse.getValue();
            }else{
                totalPropertiesWithInferrableInformation += propertyUse.getValue();
                long tmpSuperProps = propertyNode.getSubPropertyOf() == null ? 0 : propertyNode.getSubPropertyOf().size();
                long tmpDomainTypes = propertyNode.getDomain() == null ? 0 : propertyNode.getDomain().size();
                long tmpRangeTypes = propertyNode.getRange() == null ? 0 : propertyNode.getRange().size();

                long tmpInferTypes = tmpDomainTypes + tmpRangeTypes;

                //this is globally for the whole dataset
                totalInferrableProperties += tmpSuperProps * propertyUse.getValue();
                totalInferrableTypes += tmpInferTypes * propertyUse.getValue();
            }
        }

        for(TypeNode typeNode : schemaGraph.getSchemaTypeHashMap().values()){
            long tmpInferTypes = typeNode.getSubClassOf().size();
            typeEdges += tmpInferTypes;

            if(tmpInferTypes > maxInferrableTypesIdv)
                maxInferrableTypesIdv = tmpInferTypes;
            if(tmpInferTypes < minInferrableTypesIdv)
                minInferrableTypesIdv = tmpInferTypes;

            inferrableTypesIdv.add(tmpInferTypes);
        }

        for(Map.Entry<String, Integer> typeUse : typeStats.entrySet()){
            TypeNode typeNode = schemaGraph.getTypeNode(typeUse.getKey());
            if(typeNode == null){
                totalTypesWithNoInferrableInformation += typeUse.getValue();
            }else{
                totalTypesWithInferrableInformation += typeUse.getValue();
                long tmpSuperTypes = typeNode.getSubClassOf().size();

                //this is globally for the whole dataset
                totalInferrableTypes += tmpSuperTypes * typeUse.getValue();
            }
        }

        long sum1 = 0;
        for(long i : inferrablePropertiesIdv)
            sum1 += i;

        long sum2 = 0;
        for(long i : inferrableTypesIdv)
            sum2 += i;

        double avgInferrableProperties = (double) sum1/(double) schemaGraph.getNumberOfPropertyNodes();
        double avgInferrableTypes = (double) sum2/(double) (schemaGraph.getNumberOfTypeNodes() + schemaGraph.getNumberOfPropertyNodes());

        double standardDeviationProperties = 0.0;
        for(long value : inferrablePropertiesIdv)
            standardDeviationProperties += Math.pow((double) value - avgInferrableProperties, 2);

        standardDeviationProperties = (standardDeviationProperties/ (double) inferrablePropertiesIdv.size());

        double standardDeviationTypes = 0.0;
        for(long value : inferrableTypesIdv) {
            standardDeviationTypes += Math.pow((double) value - avgInferrableTypes, 2);
        }

        standardDeviationTypes = (standardDeviationTypes/ (double) inferrableTypesIdv.size());

        printStream.println("==== Schema Graph Statistics ====");
        printStream.println("Property vertices: " + schemaGraph.getNumberOfPropertyNodes());
        printStream.println("Type vertices: " + schemaGraph.getNumberOfTypeNodes());
        printStream.println("subPropertyEdges: " + propertyEdges);
        printStream.println("subTypeEdges: " + typeEdges);
        printStream.println("domainEdges: " + domainEdges);
        printStream.println("rangeEdges: " + rangeEdges);
        printStream.println("|V| = " + (schemaGraph.getNumberOfPropertyNodes() + schemaGraph.getNumberOfTypeNodes()) );
        printStream.println("|E| = " + (propertyEdges + typeEdges + domainEdges + rangeEdges));
        printStream.println("___________");
        printStream.println("Min InferrableProperties: " + minInferrablePropertiesIdv);
        printStream.println("Max InferrableProperties: " + maxInferrablePropertiesIdv);
        printStream.println("Avg InferrableProperties: " + avgInferrableProperties);
        printStream.println("Standard Deviation: " + standardDeviationProperties);
        printStream.println("___________");
        printStream.println("Min InferrableTypes: " + minInferrableTypesIdv);
        printStream.println("Max InferrableTypes: " + maxInferrableTypesIdv);
        printStream.println("Avg InferrableTypes: " + avgInferrableTypes);
        printStream.println("Standard Deviation: " + standardDeviationTypes);
        printStream.println("----------------------------------------");
        printStream.println("Inference Stats  (for Dataset):");
        printStream.println("Total Inferenced Properties: " + totalInferrableProperties);
        printStream.println("Total Inferenced Types: " + totalInferrableTypes);
        printStream.println("Total properties Without Inferrable Information: "+  totalPropertiesWithNoInferrableInformation);
        printStream.println("Total properties with Inferrable Information: "+  totalPropertiesWithInferrableInformation);
        printStream.println("Total totalTypes Without Inferrable Information: "+  totalTypesWithNoInferrableInformation);
        printStream.println("Total totalTypes with Inferrable Information: "+  totalTypesWithInferrableInformation);
        printStream.println("========================================");

        printStream.println("Checksum: " + (totalPropertiesWithNoInferrableInformation + totalPropertiesWithInferrableInformation +
                totalTypesWithNoInferrableInformation + totalTypesWithInferrableInformation) );

//
//        //printStream.println("Property Inferences: " + superPropertiesAdded.size());
//
//        int totalPropsInferred = 0;
//        for (Integer x : superPropertiesAdded)
//            totalPropsInferred += x;
//
//        //printStream.println("Total Properties Inferred: " + totalPropsInferred);
//        //printStream.println("Average Properties Inferred: " + (double) totalPropsInferred / (double) superPropertiesAdded.size());
//
//        printStream.println("Type count: " + schemaGraph.getNumberOfTypeNodes());
//        //printStream.println("Type Inferences: " + superTypesAdded.size());
//
//        int totalTypesInferred = 0;
//        for (Integer x : superTypesAdded)
//            totalTypesInferred += x;
//
//        printStream.println("Total Types Inferred: " + totalTypesInferred);
//        printStream.println("Average Types Inferred: " + (double) totalTypesInferred / (double) superTypesAdded.size());
//
//        printStream.println("== Cache-stats ==");
//        printStream.println("Cache Hits: " + cacheHits);
//        printStream.println("Cache flushes: " + cacheFlushes);
//        printStream.println("--------------------------");

    }

    /**
     * Return a set of inferable TypeInformation for the given instance
     * To ensure maximal inference, infer all properties before calling
     * this method
     *
     * @param instance
     * @return
     */
    public Set<String> inferSubjectTypes(IInstanceElement instance) {
        if (instance == null)
            return null;

        Set<String> tmpTypes = new HashSet<>();
        //outgoing quints
        for (IQuint quint : instance.getOutgoingQuints()) {
            //add types directly
            if (quint.getPredicate().toString().equals(RDF_TYPE))
                tmpTypes.add(quint.getObject().toString());
            else {
                PropertyNode tmpNode = schemaGraph.getPropertyNode(quint.getPredicate().toString());
                if (tmpNode != null) {
                    //if we have domain information, add them as types
                    //TODO: Invalid use of domain/range check? e.g. inferred type is no type?
                    tmpTypes.addAll(tmpNode.getDomain());
                }
            }
        }
        //TODO: incoming properties
        return inferTypesFromTypeGraph(tmpTypes);
    }


    /**
     * Return a set of inferrable properties for the given instance
     *
     * @param instance
     * @return
     */
    public HashMap<String, Set<String>> inferProperties(IInstanceElement instance) {
        if (instance == null)
            return null;

        Set<String> instanceProperties = new HashSet<>();
        for (IQuint quint : instance.getOutgoingQuints()) {
            //add non-type properties
            if (!quint.getPredicate().toString().equals(RDF_TYPE))
                instanceProperties.add(quint.getPredicate().toString());
        }

        HashMap<String, Set<String>> inferrableProperties = new HashMap<>();
        //use type graph to infer additional types based on all currently known types
        instanceProperties.forEach(PROP -> {
            Set<String> superProperties;
            Set<String> newProps = getPropertyCache(PROP);
            if (newProps == null) {
                PropertyNode tmp = schemaGraph.getPropertyNode(PROP);
                //if present, add all connected SuperProperties
                if (tmp != null && !(superProperties = tmp.getSubPropertyOf()).isEmpty()) {
                    newProps = superProperties;
                    if (trackStatistics)
                        superPropertiesAdded.add(newProps.size());
                    addPropertyCache(PROP, newProps);
                }

            }
            if (newProps != null)
                inferrableProperties.put(PROP, newProps);
        });
        return inferrableProperties;
    }

    /**
     * Return a set of inferable TypeInformation about the object
     * for the given statement
     *
     * @param quint
     * @return
     */
    public Set<String> inferObjectTypes(IQuint quint) {
        if (quint == null)
            return null;
        //get range information
        PropertyNode tmp = schemaGraph.getPropertyNode(quint.getPredicate().toString());
        if (tmp != null) {
            Set<String> tmpTypes = tmp.getRange();
            return inferTypesFromTypeGraph(tmpTypes);
        } else
            return new HashSet<>();
    }


    /**
     * Add a RDFS statement to SchemaGraph.
     *
     * @param schemaStatement
     * @return
     */

    public boolean add(IQuint schemaStatement) {
        if (schemaStatement == null)
            return false;

        clearCache(); //cache possible not up to date //FIXME make efficient
        switch (schemaStatement.getPredicate().toString()) {
            case Constants.RDFS_DOMAIN: {
                //Inferable Knowledge: A Instance having the subject of this
                //statement as property, has also the object of this statement as type
                //create entry

                //if object-property does not exist, create it
                schemaGraph.addPropertyNode(schemaStatement.getObject().toString(),
                        new PropertyNode(schemaStatement.getObject().toString()));

                //if subject-property does not exist, create it
                schemaGraph.addPropertyNode(schemaStatement.getSubject().toString(),
                        new PropertyNode(schemaStatement.getSubject().toString()));

                //create link between them both
                schemaGraph.getPropertyNode(schemaStatement.getSubject().toString()).addDomain(
                        schemaGraph.getPropertyNode(schemaStatement.getObject().toString()));

                return true;
            }
            case Constants.RDFS_RANGE: {
                //Inferable Knowledge: A Instance having the subject of this
                //statement as property, the corresponding object TypeCluster also
                //has the object of this statement as type

                //if object-property does not exist, create it
                schemaGraph.addPropertyNode(schemaStatement.getObject().toString(),
                        new PropertyNode(schemaStatement.getObject().toString()));

                //if subject-property does not exist, create it
                schemaGraph.addPropertyNode(schemaStatement.getSubject().toString(),
                        new PropertyNode(schemaStatement.getSubject().toString()));

                //create link between them both
                schemaGraph.getPropertyNode(schemaStatement.getSubject().toString()).addRange(
                        schemaGraph.getPropertyNode(schemaStatement.getObject().toString()));

                return true;
            }
            case Constants.RDFS_SUBCLASSOF: {
                //Inferable Knowledge: A Instance having the subject of this
                //statement as type, has also the object of this statement as type

                //if object-property does not exist, create it
                schemaGraph.addTypeNode(schemaStatement.getObject().toString(),
                        new TypeNode(schemaStatement.getObject().toString()));

                //if subject-property does not exist, create it
                schemaGraph.addTypeNode(schemaStatement.getSubject().toString(),
                        new TypeNode(schemaStatement.getSubject().toString()));

                //create link between them both
                schemaGraph.getTypeNode(schemaStatement.getSubject().toString()).addSubClassOf(
                        schemaGraph.getTypeNode(schemaStatement.getObject().toString()));

                return true;
            }
            case Constants.RDFS_SUBPROPERTYOF: {
                //Inferable Knowledge: A Instance having the subject of this
                //statement as property, has also the object of this statement as property

                //if object-property does not exist, create it
                schemaGraph.addPropertyNode(schemaStatement.getObject().toString(),
                        new PropertyNode(schemaStatement.getObject().toString()));

                //if subject-property does not exist, create it
                schemaGraph.addPropertyNode(schemaStatement.getSubject().toString(),
                        new PropertyNode(schemaStatement.getSubject().toString()));

                //create link between them both
                schemaGraph.getPropertyNode(schemaStatement.getSubject().toString()).addSubPropertyOf(
                        schemaGraph.getPropertyNode(schemaStatement.getObject().toString()));

                return true;
            }
            default: {
                System.out.println("Ups: " + schemaStatement.getPredicate().toString());
                return false;
            }
        }
    }


    private Set<String> getPropertyCache(String term) {
        Set<String> newTerms = recursivePropertyCache.get(term);
        if (trackStatistics && newTerms != null)
            cacheHits++;

        return newTerms;
    }

    private Set<String> getTypeCache(String term) {
        Set<String> newTerms = recursiveTypeCache.get(term);
        if (trackStatistics && newTerms != null)
            cacheHits++;

        return newTerms;
    }

    private void addPropertyCache(String term, Set<String> terms) {
        recursivePropertyCache.put(term, terms);
    }

    private void addTypeCache(String term, Set<String> terms) {
        recursiveTypeCache.put(term, terms);
    }

    private void clearCache() {
        if (recursivePropertyCache.size() > 0 || recursiveTypeCache.size() > 0) {
            recursivePropertyCache = new LRUCache<>(cacheSize, 0.75f);
            recursiveTypeCache = new LRUCache<>(cacheSize, 0.75f);
            cacheFlushes++;
        }
    }

    private Set<String> inferTypesFromTypeGraph(Set<String> types) {
        Set<String> allTypes = new HashSet<>();
        //use type graph to infer additional types based on all currently known types
        types.forEach(TYPE -> {
            Set<String> newTypes = getTypeCache(TYPE);
            if (newTypes == null) {
                TypeNode tmp = schemaGraph.getTypeNode(TYPE);
                //if present, add all connected SuperClasses
                if (tmp != null) {
                    newTypes = tmp.getSubClassOf();
                    if (trackStatistics)
                        superTypesAdded.add(newTypes.size());
                    addTypeCache(TYPE, newTypes);
                }
            }
            if (newTypes != null)
                allTypes.addAll(newTypes);
            //add type itself anyway
            allTypes.add(TYPE);
        });
        return allTypes;
    }


}
